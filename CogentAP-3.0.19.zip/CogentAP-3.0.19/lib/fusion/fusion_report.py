#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to generate summary files and report from STAR fusion outputs
# This script receives the output folder from STAR fusion as input
#
# -----------------------------------------------------------------------------
import argparse
import os
from collections import defaultdict
import sys
import pathlib
import re
import pandas as pd
import glob

DESCRIPTION = """Generate summary matrix files and reports from STAR fusion outputs."""

###
# Script information
###

# script info
SCRIPT_NAME = "fusion_report.py"
VERSION = "3.0.19"

###
# Parse and define arguments
###


def _parse_command_line_args(sys_argv):
    """Takes in command line parameters and parses them for use

    Args:
        sys_argv: command line input

    Returns:
        args (list) : input argument values
    """
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    required = parser.add_argument_group("required arguments")

    required.add_argument(
        "-i",
        "--input_dir",
        dest="input_dir",
        help="Full path to directory containing STAR Fusion outputs.",
        required=True,
    )

    required.add_argument(
        "-o",
        "--output_dir",
        dest="output_dir",
        help="Full path to output directory to store matrices.",
        required=True,
    )

    args, unknown = parser.parse_known_args(sys_argv)
    return args

def get_barcode(sample_name):
    if re.match(r"(.*)[ACGTN]{12,16}(.*)", sample_name):
        if re.match(r".*_L00\d(_trimmed)?$", sample_name):
            curr_barcode = sample_name.split("_")[-3]
        else:
            curr_barcode = sample_name.split("_")[-2]
    else:
        curr_barcode = sample_name.replace("_trimmed", "")
    return curr_barcode

# ---------- main ---------- #
def main(sys_argv):
    args = _parse_command_line_args(sys_argv)

    # get list of star fusion result folders
    master_dir = args.input_dir
    out_dir = args.output_dir

    #ubfolder_names = os.listdir(master_dir)
    fusion_result_files = os.path.join(master_dir, "*_fusion_predictions.abridged.tsv")
    fusion_results_list = glob.glob(fusion_result_files, recursive=True)

    # get barcode from folder name
    #subfolder_names = [f for f in subfolder_names if not f.startswith(".")]
    #barcode_list = [i.replace("fusion_out_", "") for i in subfolder_names]
    #final_barcode_list = [get_barcode(x) for x in barcode_list]
    barcode_list = [i.split("/")[-1].replace("_fusion_predictions.abridged.tsv", "") for i in fusion_results_list]
    final_barcode_list = [get_barcode(x) for x in barcode_list]
    # initialize dictionaries for fusion and gene matrices
    junction_dict = defaultdict(dict)
    spanning_dict = defaultdict(dict)


    # loop through the fusion predictions file for each sample
    for result_file in fusion_results_list:
        sample_name = result_file.split("/")[-1].replace("_fusion_predictions.abridged.tsv", "")
        curr_barcode = get_barcode(sample_name)

        with open(result_file) as result:
            lines = result.readlines()
            for line in lines:
                li = line.strip()
                if not li.startswith("#"):
                    # get junction and spanning counts and save to dictionary
                    fusion_genes = li.split("\t")[0]
                    junction_ct = li.split("\t")[1]
                    spanning_ct = li.split("\t")[2]
                    junction_dict[fusion_genes][curr_barcode] = junction_ct
                    spanning_dict[fusion_genes][curr_barcode] = spanning_ct


    pathlib.Path(os.path.join(args.input_dir, out_dir)).mkdir(
        parents=True, exist_ok=True
    )

    # writing out the junction matrix file
    junction_matrix_file = os.path.join(out_dir, "star_junction_matrix.csv")
    with open(junction_matrix_file, "a") as f:
        print("GeneFusion", end=",", file=f)
        print(",".join(final_barcode_list), end="", file=f)
        for gene in junction_dict:
            print("", file=f)
            print(gene, end="", file=f)
            for barcode in final_barcode_list:
                if barcode in junction_dict[gene]:
                    print(',', end="", file=f)
                    print(junction_dict[gene][barcode], end="", file=f)
                else:
                    print(',', end="", file=f)
                    print(0.0, end="", file=f)
        print("\n", file=f)

    # writing out the spanning matrix file
    spanning_matrix_file = os.path.join(out_dir, "star_spanning_matrix.csv")
    with open(spanning_matrix_file, "a") as f:
        print("GeneFusion", end=",", file=f)
        print(",".join(final_barcode_list), end="", file=f)
        for gene in spanning_dict:
            print("", file=f)
            print(gene, end="", file=f)
            for barcode in final_barcode_list:
                if barcode in spanning_dict[gene]:
                    print(',', end="", file=f)
                    print(spanning_dict[gene][barcode], end="", file=f)
                else:
                    print(',', end="", file=f)
                    print(0.0, end="", file=f)
        print("\n", file=f)

if __name__ == "__main__":
    main(sys.argv[1:])
