class OrderedSet:
    def __init__(self, *args):
        self._set = set()
        self._list = []
        for iterable in args:
            for item in iterable:
                self.add(item)

    def add(self, item):
        if item not in self._set:
            self._set.add(item)
            self._list.append(item)

    def issuperset(self, other):
        return self._set.issuperset(other)

    def union(self, other):
        return self._set.union(other)

    def __eq__(self, other):
        return self._set == other

    def __ne__(self, value: object) -> bool:
        return self._set != value

    def __lt__(self, value: object) -> bool:
        return self._set < value

    def __le__(self, value: object) -> bool:
        return self._set <= value

    def __gt__(self, value: object) -> bool:
        return self._set > value

    def __ge__(self, value: object) -> bool:
        return self._set >= value

    def __iter__(self):
        return iter(self._list)

    def __contains__(self, item):
        return item in self._set

    def __len__(self):
        return len(self._set)

    def __repr__(self):
        return f"{self.__class__.__name__}({self._list})"
