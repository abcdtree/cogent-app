#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Classes to load configs from installed directories.
# local_config.csv is abolished by CogentAP v1.0.
# This class reads files/directories insted.
#

from genericpath import isfile
import os
import glob
import json
import sys

from typing import Dict

class Config:
	"""
	Class to load local_config.csv like values from directories.
	Fixed values are stored to the dictionary and check if those paths are exists.
	Because of the rule about dictionary's key, user cannot use ':' for genome name.
	"""

	# ---------------------------------
	# region: Constants
	# CONDA_ENV = 'CogentAP_tools'
	# EXT_DIR = 'ext'
	# GENOME_DIR = 'genomes'
	# GENOME_PREFERENCES = 'genome_pref.json'
	EXPERIMENT_FILE = 'experiments.json'
	# GENOME_CONFIG_KEY = 'genome:'
	# GENOME_CONFIG_DELIMITER = ':'

	# STAR_INDEX_NAME = 'star_index'
	# RSEM_INDEX_NAME = 'rsem_index'
	# FUSION_INDEX_NAME = 'fusion_index'
	# endregion
	# ---------------------------------

	def __init__(self, script_start_path: str, config_dir: str):
		self.__base_path = os.path.join(os.path.dirname(script_start_path), '..')	# set above directory
		self.__config_dir = config_dir												# set config files directory path

	# def load_config(self):
	# 	"""Load config like values

	# 	Returns:
	# 		[type] -- Loaded values
	# 	"""

	# 	values = {}

	# 	# create required path
	# 	values['python3_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/python3')]
	# 	values['perl_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/perl')]
	# 	values['star_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/STAR')]
	# 	values['cutadapt_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/cutadapt')]
	# 	values['featureCounts_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/featureCounts')]
	# 	values['rscript_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/Rscript')]
	# 	values['bamtobed_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/bamToBed')]
	# 	values['samtools_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/samtools')]
	# 	values['unpigz_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/unpigz')]
	# 	values['seqtk_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/seqtk')]
	# 	values['ribopicker_loc'] = [os.path.join(self.__base_path, self.EXT_DIR, 'ribopicker-standalone-0.4.3/ribopicker.pl')]
	# 	values['rsem_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/rsem-calculate-expression')]
	# 	values['rsem_reference_loc'] = [os.path.join(self.__base_path, self.CONDA_ENV, 'bin/rsem-prepare-reference')]
	# 	values['genefusion_loc'] = [os.path.join(self.__base_path, self.EXT_DIR, 'STAR-Fusion-v1.10.0/STAR-Fusion')]
	# 	values['trust4_loc'] = [os.path.join(self.__base_path, self.EXT_DIR, 'TRUST4-1.0.4/run-trust4')]

	# 	# check path exists
	# 	for key, path in values.items():
	# 		if not os.path.exists(path[0]):
	# 			print('%s is not installed correctly.' % (key.split('_')[0]), file=sys.stderr)
	# 			return None

	# 	# find genomes
	# 	genome_dir = os.path.join(self.__base_path, self.GENOME_DIR)
	# 	if not os.path.exists(genome_dir):
	# 		print('Error: Genomes are not installed.', file=sys.stderr)
	# 		return None

	# 	values['genomedir_loc'] = [genome_dir]

	# 	genomes = os.listdir(genome_dir)
	# 	for genome_name in genomes:
	# 		target_path = os.path.join(genome_dir, genome_name) + '/'

	# 		# Look for mitochondria.gtf file in genome directory first
	# 		mito_gtf = os.path.join(target_path, 'mitochondria.gtf')
	# 		if not os.path.isfile(mito_gtf):
	# 			mito_gtf = None

	# 		# Look for gtf file in genome directory
	# 		files = glob.glob(target_path + '*.gtf')
	# 		if not mito_gtf is None:
	# 			files.remove(mito_gtf)							# Remove mito gtf from search target

	# 		if len(files) == 0:
	# 			print('Error: No GTF is found for %s' % (genome_name), file=sys.stderr)
	# 			return None
	# 		elif len(files) > 1:
	# 			print('Error: Two or more GTF are found for %s' % (genome_name), file=sys.stderr)
	# 			return None

	# 		# Look for genome preferences
	# 		pref_json = os.path.join(target_path, self.GENOME_PREFERENCES)
	# 		if not isfile(pref_json):
	# 			print('Error: Genome preferences does not exist for %s' % (genome_name), file=sys.stderr)
	# 			return None

	# 		genome_pref = None
	# 		with open(pref_json, 'r') as f:
	# 			genome_pref = json.load(f)

	# 		values[self.GENOME_CONFIG_KEY + genome_name] = [target_path, files[0], mito_gtf, genome_pref]

	# 	return values

	def get_experiments(self) -> Dict[str, str]:

		data = None
		with open(os.path.join(self.__config_dir, self.EXPERIMENT_FILE), 'r') as f:
			data = json.load(f)

		return data
