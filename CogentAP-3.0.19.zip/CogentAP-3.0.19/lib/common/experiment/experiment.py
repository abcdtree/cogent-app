#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Abstract class to define required contents for experiment
#
# Required:
# 	-

from abc import ABCMeta, abstractmethod
from typing import Dict, List, Set, Tuple, Union

from common.util.const import (
    AnalysisType,
    DebugMode,
    NormalizeMethod,
    ReadMode,
    StrandedMode,
    UssMode,
)
from demux.barcode_reader import BarcodeReader


class Experiment(metaclass=ABCMeta):
    # ---------------------------------
    # region: Abstract Property (to be implemented in each class)
    @property
    @abstractmethod
    def name(self) -> str:
        """Experiment type name

        Returns:
                str: Experiment type name
        """
        ...

    @property
    @abstractmethod
    def read_mode(self) -> ReadMode:
        """Read mode to define which read (R1, R2) or both are input, kept and analyzed.

        Returns:
                ReadMode: Read mode
        """
        ...

    @property
    @abstractmethod
    def check_revcomp(self) -> bool:
        """Whether check reverse complement about barcodes

        Returns:
                bool: True if check
        """
        ...

    @property
    @abstractmethod
    def dual_index_barcode(self) -> bool:
        """Whether dual index barcode is used like full-length chemistry

        Returns:
                bool: True if dual index
        """
        ...

    @property
    @abstractmethod
    def umi_length(self) -> Union[int, None]:
        """UMI length to be cut out

        Returns:
                Union[int, None]: Number of UMI length. None if UMI is disabled.
        """
        ...

    @property
    @abstractmethod
    def is_use_uss(self) -> bool:
        """Flag to use uss for collaption

        Returns:
                bool: True if use
        """
        ...

    @property
    @abstractmethod
    def uss_mode(self) -> UssMode:
        """Mode for USS collaption. This option will be ignored when is_use_uss = False.

        Returns:
                UssMode: [description]
        """
        ...

    @property
    @abstractmethod
    def stranded_mode(self) -> StrandedMode:
        """Mode to specify stranded

        Returns:
                StrandedMode: None, forward or reverse
        """
        ...

    @property
    @abstractmethod
    def norm_method(self) -> NormalizeMethod:
        """Normalize method for CogentDS analysis (cpm, tpm or fpkm is acceptable)

        Returns:
                NormalizeMethod: Method type to normalize
        """
        ...

    @property
    @abstractmethod
    def support_analysis(self) -> List[AnalysisType]:
        """Analysis that this experiment type supports (e.g. gene, transcript, fusion or immune)

        Returns:
                List[AnalysisType]: Analysis types
        """
        ...

    @property
    @abstractmethod
    def main_result_prefix(self) -> Union[str, None]:
        """Use this property only when 2 or more genematrix (and stats.csv) generated from analyze and want to create RDA file from CogentDS.
                Only for SSv4+UMI for now.

        Returns:
                str: name to search (e.g. _all). '_genematrix.csv' and '_stats.csv' will be automatically added.
        """
        ...

    # endregion: Abstract Property
    # ---------------------------------

    # ---------------------------------
    # region: Implemented Property
    @property
    def is_paired(self) -> bool:
        return self.read_mode == ReadMode.PAIRED

    @property
    def is_use_umi(self) -> bool:
        return not self.umi_length is None

    @property
    def is_stranded(self) -> bool:
        return self.stranded_mode is not StrandedMode.NONE

    @property
    def is_support_gene(self) -> bool:
        return AnalysisType.GENE in self.support_analysis

    @property
    def is_support_transcript(self) -> bool:
        return AnalysisType.TRANSCRIPT in self.support_analysis

    @property
    def is_support_fusion(self) -> bool:
        return AnalysisType.FUSION in self.support_analysis

    @property
    def is_support_immune(self) -> bool:
        return AnalysisType.IMMUNE in self.support_analysis

    # endregion: Implemented Property
    # ---------------------------------

    # ---------------------------------
    # region: Implemented method
    def initialize(self, config_dir: str):
        """Overwrite this function to initialize class if necessary.

        Args:
                config_dir (str): Path to config directory
        """
        return  # Do nothing

    # endregion: Implemented method
    # ---------------------------------

    # ---------------------------------
    # region: Abstract Method

    @abstractmethod
    def get_background_info(
        self, repository_path: str, input_bcs: Set[str], input_index_pos: int
    ) -> Tuple[Set[str], Union[str, None], Union[str, None], int]:
        """Get barcodes or hamming distance references

        Returns:
                Dict[str, Union[str, None]]: Dictionary contains 'bc_map', 'hh1' and 'hh2'. Each key corresponds a file path.
        """
        ...

    @abstractmethod
    def get_barcode(
        self, read1, read2, barcode_length: int, umi_length: int
    ) -> Tuple[str, str]:
        """Get barcode string and UMI string from a read.

        Args:
                read1 (Sequence object from dnaio): Read1 information including tag, read and quality
                read2 (Sequence object from dnaio): Read2 information including tag, read and quality
                barcode_length (int): Barcode length
                umi_length (int): UMI length

        Returns:
                Tuple[str, str]: Barcode and UMI
        """
        ...

    @abstractmethod
    def extend_barcode_list(
        self, barcode_reader: BarcodeReader, user_map_files: Union[List[str], None]
    ) -> bool:
        """Extend original barcode list by defined internal barcodes.
                It means concatenating internal barcodes to each barcode in the list.

                This function is useful for SCI-seq chemistry. Otherwise do nothing.

        Args:
                barcode_reader BarcodeReader: Barcode list from barcode reader.
        """
        ...

    @abstractmethod
    def process_read_on_demux(
        self, read1, read2, barcode: str, barcode_length: int, umi: str
    ):
        """Function to process reads on demultiplexing part

        Args:
                read1 (Sequence object from dnaio): Read1
                read2 (Sequence object from dnaio): Read2
                barcode (str): Barcode string
                barcode_length (int): Barcode length
                umi (str): UMI string
        """
        ...

    # endregion: Abstract method
    # ---------------------------------
