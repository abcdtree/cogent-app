#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to specify Plate-based seq (Full Length)
#
# SMART-Seq® Single Cell PLUS Kit (Cat. Nos. R400750, R400751)
# SMART-Seq® v4 PLUS Kit (Cat. Nos. R400752, R400753)
# SMART-Seq® HT PLUS Kit (Cat. Nos. R400748, R400749)
#

from os import path
from typing import Dict, List, Tuple, Union, cast, Set
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import (
    AnalysisType,
    DebugMode,
    NormalizeMethod,
    ReadMode,
    StrandedMode,
    UssMode,
)
from demux.barcode_reader import BarcodeReader


class SmartSeqFLA(Experiment):
    # ---------------------------------
    # region: Property
    @property
    def name(self) -> str:
        return "smartseq_fla"

    @property
    def read_mode(self) -> ReadMode:
        return ReadMode.PAIRED

    @property
    def check_revcomp(self) -> bool:
        return True

    @property
    def dual_index_barcode(self) -> bool:
        return True

    @property
    def umi_length(self) -> Union[int, None]:
        return None

    @property
    def stranded_mode(self) -> StrandedMode:
        return StrandedMode.NONE

    @property
    def is_use_uss(self) -> bool:
        return False

    @property
    def uss_mode(self) -> UssMode:
        return UssMode.NONE

    @property
    def norm_method(self) -> NormalizeMethod:
        return NormalizeMethod.CPM

    @property
    def support_analysis(self) -> List[AnalysisType]:
        return [
            AnalysisType.GENE,
            AnalysisType.TRANSCRIPT,
            AnalysisType.FUSION,
            AnalysisType.IMMUNE,
        ]

    @property
    def main_result_prefix(self) -> Union[str, None]:
        return None

    # endregion: Property
    # ---------------------------------

    # ---------------------------------
    # region: Methods
    def get_background_info(
        self, repository_path: str, input_bcs: Set[str], input_index_pos: int
    ) -> Tuple[Set[str], Union[str, None], Union[str, None], int]:
        return (input_bcs, None, None, input_index_pos)

    def extend_barcode_list(
        self, barcode_reader: BarcodeReader, user_map_files: Union[List[str], None]
    ) -> bool:
        return True  # Do nothing

    def get_barcode(
        self, read1, read2, barcode_length: int, umi_length: int
    ) -> Tuple[str, str]:
        barcode = "".join(filter(str.isalpha, read1.name.split()[1].split(":")[-1]))
        return (barcode, "NA")

    def process_read_on_demux(
        self, read1, read2, barcode: str, barcode_length: int, umi: str
    ):
        tmp = read1.name.split()
        tmp[0] += "".join(["_", barcode])
        read1.name = " ".join(tmp)

        tmp = read2.name.split()
        tmp[0] += "".join(["_", barcode])
        read2.name = " ".join(tmp)

    # endregion: Methods
    # ---------------------------------
