#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to specify SCI-seq (Stranded, in development)
#
# Required:
# 	-

from os import path
from typing import Dict, List, Set, Tuple, Union, cast
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import (
    AnalysisType,
    DebugMode,
    NormalizeMethod,
    ReadMode,
    StrandedMode,
    UssMode,
)
from demux.barcode_reader import BarcodeReader
from demux.barcode_map_reader import BarcodeMapReader


class ShastaTotalRNA(Experiment):
    # ---------------------------------
    # region : Constants
    INTERNAL_BARCODE_LEN = 8  # Length of internal barcode (beginning of read1)
    # endregion
    # ---------------------------------

    def __init__(self) -> None:
        super().__init__()

        self.__internal_bc_ref_file = (
            None  # Reference file of internal barcodes (barcode1 in protocol.)
        )

    # ---------------------------------
    # region: Property
    @property
    def name(self) -> str:
        return "shasta_total_rna"

    @property
    def read_mode(self) -> ReadMode:
        return ReadMode.PAIRED

    @property
    def check_revcomp(self) -> bool:
        return True

    @property
    def dual_index_barcode(self) -> bool:
        return True

    @property
    def umi_length(self) -> Union[int, None]:
        return None

    @property
    def stranded_mode(self) -> StrandedMode:
        return StrandedMode.REVERSE

    @property
    def is_use_uss(self) -> bool:
        return False

    @property
    def uss_mode(self) -> UssMode:
        return UssMode.BOTH

    @property
    def norm_method(self) -> NormalizeMethod:
        return NormalizeMethod.CPM

    @property
    def support_analysis(self) -> List[AnalysisType]:
        return [
            AnalysisType.GENE,
            AnalysisType.TRANSCRIPT,
            AnalysisType.FUSION,
            AnalysisType.IMMUNE,
        ]

    @property
    def main_result_prefix(self) -> Union[str, None]:
        return None

    # endregion: Property
    # ---------------------------------

    # ---------------------------------
    # region: Methods
    def initialize(self, config_dir: str):
        # Set default map file for internal barcodes
        self.__internal_bc_ref_file = path.join(
            config_dir, "barcode_maps", "barcode_map_sci_stranded_v1.csv"
        )

    def get_background_info(
        self, repository_path: str, input_bcs: Set[str], input_index_pos: int
    ) -> Tuple[Set[str], Union[str, None], Union[str, None], int]:
        return (input_bcs, None, None, input_index_pos)

    def extend_barcode_list(
        self, barcode_reader: BarcodeReader, user_map_files: Union[List[str], None]
    ) -> bool:
        map_file = None

        # Check user input internal barcodes
        if user_map_files is None:
            Logger.info_logger("Use built-in barcode map file for barcode1.")
            map_file = self.__internal_bc_ref_file
        else:
            Logger.info_logger("Use user input barcode map file for barcode1.")
            if len(user_map_files) == 1:
                map_file = user_map_files[0]  # use the first item in the list
            else:
                Logger.error_logger(
                    "Unexpected number of barcode map files. One map file can be input for this experiment."
                )

        if map_file is None:
            Logger.error_logger("No map file for barcode1 detected.")
            return False

        # Load internal barcode
        map_reader = BarcodeMapReader(map_file)
        if not map_reader.read():
            Logger.error_logger("Failed to load user input barcode map file.")
            return False

        new_bc_info = {}
        for bc1, name1 in barcode_reader.sample_hash.items():
            for bc2, name2 in map_reader.barcode_dist.items():
                new_bc_info[bc1 + bc2] = "_".join([name1, name2])

        barcode_reader.update_sample_hash(new_bc_info)

        return True

    def get_barcode(
        self, read1, read2, barcode_length: int, umi_length: int
    ) -> Tuple[str, str]:
        # Get barcode from tag
        barcode = "".join(filter(str.isalpha, read1.name.split()[1].split(":")[-1]))

        # Get barcode from read2 (8 bases)
        internal_bc = read2.sequence[0 : self.INTERNAL_BARCODE_LEN]
        barcode = barcode + internal_bc

        return (barcode, "NA")

    def process_read_on_demux(
        self, read1, read2, barcode: str, barcode_length: int, umi: str
    ):
        # Process Read1
        tmp = read1.name.split()
        tmp[0] += "_" + barcode
        read1.name = " ".join(tmp)

        # Process Read2
        tmp = read2.name.split()
        tmp[0] += "_" + barcode
        read2.name = " ".join(tmp)

        # Trim internal barcode
        read2.sequence = read2.sequence[self.INTERNAL_BARCODE_LEN :]
        read2.qualities = read2.qualities[self.INTERNAL_BARCODE_LEN :]

        # # trim r2 to remove umi from 5' end
        # # further trim to remove N6 following UMI
        # read2.sequence = read2.sequence[(len(umi) + 6):]
        # read2.qualities = read2.qualities[(len(umi) + 6):]

    # endregion: Methods
    # ---------------------------------
