import gzip
import os
import subprocess
from collections import Counter, defaultdict
from datetime import datetime
from os import path, unlink
from typing import Set

import dnaio
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.ordered_set import OrderedSet
from common.util.util import elapsed_time, run_system_cmd

# -----------------------------------------------------------------------------
# region : CONSTANT
KEYWORD_SHORT = "Short"
KEYWORD_UNSELECT = "Unselected"
KEYWORD_UNDETERMINED = "Undetermined"
# endregion
# -----------------------------------------------------------------------------


class BarcodeSelector:
    def __init__(
        self,
        select_number: int,
        check_limit: int,
        min_reads: int,
        experiment: Experiment,
        umi_len: int,
        hh1,
        hh2,
        idx,
        bcs_chip,
        mismatch: int,
        sample_hash,
        work_dir: str,
        prefix: str,
        seqtk_path: str,
        get_bc_func,
        rev1=False,
        rev2=False,
        base_bc_len=-1,
    ):
        self.__select_number = select_number
        self.__check_limit = check_limit
        self.__min_reads = min_reads
        self.__experiment = experiment
        self.__umi_len = umi_len
        self.__hh1 = hh1
        self.__hh2 = hh2
        self.__idx = idx
        self.__bcs_chip = bcs_chip
        self.__mismatch = mismatch
        self.__sample_hash = sample_hash
        self.__work_dir = work_dir
        self.__prefix = prefix
        self.__seqtk_path = seqtk_path
        self.__get_bc_func = get_bc_func
        self.__rev1 = rev1
        self.__rev2 = rev2
        self.__base_bc_len = base_bc_len

    def select_barcodes(
        self,
        r1_fastq: str,
        r2_fastq: str,
        barcodes: OrderedSet,
        random_picking: bool,
        dry_run: bool,
    ) -> Set[str]:
        Logger.info_both("Start selecting barcode")
        st = datetime.now()

        Logger.info_both(
            f"Target number of selecting barcodes = {self.__select_number}"
        )
        Logger.info_both(f"Minimum number of reads per barcode = {self.__min_reads}")
        Logger.info_both(f"Number of reads for checking = {self.__check_limit}")

        # estimate compression level
        compression_level = self.__estimate_compression_level(r1_fastq)
        est_total_reads = self.__estimate_total_reads(r1_fastq, compression_level)

        # Random picking of input fastq
        use_fastq_r1 = r1_fastq
        use_fastq_r2 = r2_fastq
        if random_picking:
            Logger.info_both("Start random picking of input reads.")
            st_pick = datetime.now()

            use_fastq_r1 = f"{self.__work_dir}/temp_R1.fastq"
            use_fastq_r2 = f"{self.__work_dir}/temp_R2.fastq"
            run_system_cmd(
                f"{self.__seqtk_path} sample {r1_fastq} {self.__check_limit}",
                stdout_file=use_fastq_r1,
            )
            run_system_cmd(
                f"{self.__seqtk_path} sample {r2_fastq} {self.__check_limit}",
                stdout_file=use_fastq_r2,
            )

            Logger.info_both(
                f"Completed random picking. Elapsed time: {elapsed_time(st_pick)}"
            )
        else:
            # Normal picking with head
            Logger.info_both("Start normal picking from FASTQ heads (fast).")

        # Prepare barcode counter
        barcode_len = self.__base_bc_len
        if barcode_len == -1:
            barcode_len = len(list(barcodes)[0])
        counter = Counter()
        und_dict = defaultdict(int)

        # Read FASTQ files anc count barcodes
        read_count = 0
        with dnaio.open(use_fastq_r1, use_fastq_r2, mode="r") as reader:  # type: ignore
            for r1, r2 in reader:  # type: ignore
                # Get barcodes from reads
                barcode, umi = self.__get_bc_func(
                    r1,
                    r2,
                    self.__experiment,
                    barcode_len,
                    self.__umi_len,
                    self.__hh1,
                    self.__hh2,
                    self.__idx,
                    self.__bcs_chip,
                    self.__mismatch,
                    self.__rev1,
                    self.__rev2,
                )

                if barcode in barcodes:  # When included in the initial barcodes list
                    counter.update({barcode: 1})
                elif barcode in self.__bcs_chip:
                    und_dict[KEYWORD_UNSELECT] += 1
                elif barcode == "short":
                    und_dict[KEYWORD_SHORT] += 1
                else:
                    und_dict[KEYWORD_UNDETERMINED] += 1

                # Normal picking
                read_count += 1
                if read_count >= self.__check_limit:
                    break

        # Calculate final estimated barcoded reads
        weight = est_total_reads / self.__check_limit
        for key in counter:
            counter[key] = int(counter[key] * weight)

        for key in und_dict:
            und_dict[key] = int(und_dict[key] * weight)

        # Output estimated result
        if dry_run:
            Logger.info_both("Output estimated counts for dry run.")
            with open(
                os.path.join(
                    self.__work_dir, self.__prefix + "_" + "counts_all.estimated.csv"
                ),
                "w",
                newline="",
            ) as w:
                for key, value in counter.items():
                    w.write(",".join([key, self.__sample_hash[key], str(value)]) + "\n")

                w.write(
                    ",".join(
                        [KEYWORD_SHORT, "Non_sample", str(und_dict[KEYWORD_SHORT])]
                    )
                    + "\n"
                )
                w.write(
                    ",".join(
                        [
                            KEYWORD_UNSELECT,
                            "Non_sample",
                            str(und_dict[KEYWORD_UNSELECT]),
                        ]
                    )
                    + "\n"
                )
                w.write(
                    ",".join(
                        [
                            KEYWORD_UNDETERMINED,
                            "Non_sample",
                            str(und_dict[KEYWORD_UNDETERMINED]),
                        ]
                    )
                    + "\n"
                )

        # Filter out barcodes
        selected_barcodes = OrderedSet()
        for bc_count in counter.most_common(self.__select_number):  # type: ignore
            if bc_count[1] >= self.__min_reads:
                selected_barcodes.add(bc_count[0])

        Logger.info_both(f"Selected barcodes = {len(selected_barcodes)}")
        Logger.info_both(f"End selecting barcode. Elapsed time: {elapsed_time(st)}")

        # Random picking
        if random_picking:
            if path.isfile(use_fastq_r1):
                unlink(use_fastq_r1)

            if path.isfile(use_fastq_r2):
                unlink(use_fastq_r2)

        return selected_barcodes

    def __estimate_compression_level(
        self, fastq: str, check_bytes: int = 1024 * 1024
    ) -> int:
        Logger.info_both("Start estimation of gzip compression level.")

        # read bytes for checking
        base_str = subprocess.run(  # decompress head
            f"head -c {str(check_bytes)} {fastq} | gzip -d -",
            check=False,
            capture_output=True,
            text=True,
            shell=True,
        ).stdout

        # estimate compression level
        size_diff = [0] * 10  # for level 0 to 9
        for level in range(0, 10):
            compressed = gzip.compress(
                bytes(base_str, encoding="utf-8"), compresslevel=level
            )  # compress
            size_diff[level] = abs(
                len(compressed) - check_bytes
            )  # calculate bytes diff

        est_compression_level = size_diff.index(min(size_diff))

        Logger.info_both(f"Estimated compression level = {str(est_compression_level)}")

        return est_compression_level

    def __estimate_total_reads(self, fastq: str, compression_level: int) -> int:
        Logger.info_both("Start estimation of number of total reads.")
        st = datetime.now()

        # --- get input file size ---
        file_stat = os.stat(fastq)
        Logger.info_both(f"Get FASTQ file size = {file_stat.st_size} bytes.")

        # --- read first n reads ---
        read_count = 0
        check_bytes = bytearray()
        with dnaio.open(fastq, mode="r") as reader:  # type: ignore
            for record in reader:  # type: ignore
                check_bytes += bytearray(bytes(record.name + "\n", encoding="utf-8"))  # type: ignore
                check_bytes += bytearray(bytes(record.sequence + "\n", encoding="utf-8"))  # type: ignore
                check_bytes += bytearray(bytes("+\n", encoding="utf-8"))
                check_bytes += bytearray(bytes(record.qualities + "\n", encoding="utf-8"))  # type: ignore

                read_count += 1
                if read_count >= self.__check_limit:
                    break

        # --- Compression ---
        compressed = gzip.compress(bytes(check_bytes), compresslevel=compression_level)
        Logger.info_both(f"Bytes after compression = {len(compressed)}")

        # --- Calculate number of total reads ---
        est_reads = int((file_stat.st_size / len(compressed)) * self.__check_limit)

        Logger.info_both(
            f"Estimated number of reads = {est_reads}. Elapsed time: {elapsed_time(st)}"
        )

        return est_reads
