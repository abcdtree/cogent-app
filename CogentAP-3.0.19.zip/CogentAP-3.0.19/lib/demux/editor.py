import gzip
import warnings

UNWRITTEN_DATA_WARNING = Warning(
    "Some data chunks were not written to disk "
    "before the demux editor was closed.")

class Editor:
    """The job of the editor is to receive chunks of data in any order and write them in order to a file,
    either a standard file or a gzip file.

    Running in "hpc_mode" allows the editor to keep the file open between writes, which
    may improve performance. There may be many editors running in parallel, each writing to
    a different file, so hpc_mode can cause a "Too many open files" error if ulimit is not
    set high enough.
    """

    def __init__(
        self,
        out_file,
        mode="ab",
        hpc_mode: bool = False,
        gzip: bool = False,
        compression_level: int = 4,
    ):
        self._write_pointer = 0
        self._chunks = dict()  # (index, data)
        self._out_file = out_file
        self._mode = mode
        self._hpc_mode = hpc_mode
        self._gzip = gzip
        self._compression_level = compression_level
        self._out_file_stream = None
        if hpc_mode:
            self._out_file_stream = self._open_file()

    def write(self, chunk, index):
        if len(chunk) == 0:
            self._chunks[index] = None
        else:
            self._chunks[index] = chunk

        if self._write_pointer in self._chunks:
            # If a chunk is available for the current write position, write it
            # to file along with any other consecutive chunks available. Otherwise
            # do nothing, we must wait for the chunk at the current write position.
            if self._hpc_mode:
                self._write_chunks_to_file(self._out_file_stream)
            else:
                with self._open_file() as o:
                    self._write_chunks_to_file(o)

    def _write_chunks_to_file(self, out_file_stream):
        # Exit loop when the next chunk is not yet available.
        while self._write_pointer in self._chunks:
            if not self._chunks[self._write_pointer] is None:
                out_file_stream.write(self._chunks[self._write_pointer])
            del self._chunks[self._write_pointer]
            self._write_pointer += 1

    def _open_file(self):
        if self._gzip:
            return gzip.open(
                self._out_file, mode=self._mode, compresslevel=self._compression_level
            )
        return open(self._out_file, mode=self._mode)

    def done(self):
        return len(self._chunks) == 0

    def close(self):
        if self._out_file_stream is not None:
            self._out_file_stream.close()
            self._out_file_stream = None
        if not self.done():
            warnings.warn(UNWRITTEN_DATA_WARNING)

    def __del__(self):
        self.close()
