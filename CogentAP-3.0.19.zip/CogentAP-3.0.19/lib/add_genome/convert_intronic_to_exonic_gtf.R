library(GenomicRanges)
library(rtracklayer)
library(dplyr)

args <- commandArgs(trailingOnly = TRUE)

file = args[1]
outfile = args[2]

introns = rtracklayer::import(file)

introns_df = data.frame(introns)

#introns_df = introns_df %>% dplyr::filter(gene_biotype == 'protein_coding')

final_df = c()
intronsdf_trans = introns_df
intronsdf_trans$type = "transcript"
genes = unique(introns_df$gene_id)

for(f in 1:length(genes)) {
	intronsdf_trans_gene = intronsdf_trans %>% dplyr::filter(gene_id == genes[f])
	start_stops = c(intronsdf_trans_gene$start, intronsdf_trans_gene$end)
	start_stops = sort(start_stops,decreasing = F)
	intronsdf_trans_gene$start = start_stops[1]
	intronsdf_trans_gene$end = start_stops[length(start_stops)]
	intronsdf_trans_gene$width = intronsdf_trans_gene$end - intronsdf_trans_gene$start
	trans_name = paste0(genes[f], '_', "Intronic_Transcript")
	intronsdf_trans_gene$transcript_id = trans_name
	intronsdf_trans_gene$exon_id = NA
	intronsdf_trans_gene_exon = intronsdf_trans_gene
	intronsdf_trans_gene_exon$type = "exon"
	exon_name = paste0(genes[f], '_', "Intronic_Exonic")
	intronsdf_trans_gene_exon$exon_id = exon_name
	intronsdf_trans_gene = unique(intronsdf_trans_gene)
	intronsdf_trans_gene_exon = unique(intronsdf_trans_gene_exon)
	final_df = rbind(final_df, intronsdf_trans_gene)
	final_df = rbind(final_df, intronsdf_trans_gene_exon)
	str = paste0("processed", '-', genes[f], '-', f)
	message(str)
}
rtracklayer::export(final_df, outfile)
