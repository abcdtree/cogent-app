########## Load Libraries ############################
message('Loading Libraries..')
library(dplyr)
library(optparse)
library(data.table)
######################################################

################# Set Arguments to be passed ############
message('Reading Users arguments..')
option_list = list(
	make_option("--gene_transcript_Map", type="character", default=NULL, help="Gene Transcript Map from GTF including introns", metavar="character"),
  	make_option("--salmon_transcriptCounts", type="character", default=NULL, help="Transcript counts across cells; Intron Transcripts should be present", metavar="character"),
  	make_option("--outPath", type="character", default=NULL, help="Path to folder to write results", metavar="character"),
    make_option("--umiOnly", type="character", default=NULL, help="Denote whether the input is from an UMI only analysis", metavar="character")
);

opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);
#######################################################

####### check required files ######
if(is.null(opt$gene_transcript_Map)) {
	print_help(opt_parser)
  	stop("Gene-Transcript Map is required")
}

if(is.null(opt$salmon_transcriptCounts)) {
	print_help(opt_parser)
  	stop("Salmon Transcript Matrix is required")
}

if(is.null(opt$outPath)) {
	print_help(opt_parser)
  	stop("Path to file dest. is required")
} else {
	dir.create(opt$outPath)
}
#######################################


####### execution ############
gtf_trans_select = read.table(opt$gene_transcript_Map, sep = "\t", header = T, row.names = 1, check.names = F)
colnames(gtf_trans_select) = c("transcript_id", "GeneID")
genes = unique(gtf_trans_select$GeneID)
transcripts = unique(gtf_trans_select$transcript_id)
transcripts_intronicExon = grep('Intronic_Transcript', transcripts, value = T)
if(length(transcripts_intronicExon) == 0) {
	stop('Intron scpecific transcripts not found. Fatal Error!')
} else {
	transcripts_exonOnly = transcripts[! transcripts %in% transcripts_intronicExon]
	trans_counts = fread(file = opt$salmon_transcriptCounts, data.table = F, verbose = F, check.names = FALSE) ## read the file using fread
}

if(!is.null(trans_counts)) {
	rownames(trans_counts) = trans_counts[,1]
	trans_counts[,1] = NULL
	trans_counts_all_transcripts = trans_counts[transcripts,]
	trans_counts_exonOnly = trans_counts[transcripts_exonOnly,]
	trans_counts_exonOnly_copy = trans_counts_exonOnly
	gtf_trans_select_exonOnly = gtf_trans_select[transcripts_exonOnly,]
	trans_counts_all_transcripts$GeneID = gtf_trans_select$GeneID
	trans_counts_exonOnly$GeneID = gtf_trans_select_exonOnly$GeneID
	
	message('read counts matrix.. initializing summarization of counts for genes at two levels')

	message('Summarizing gene counts for intron + exons.. please wait.')
	geneCounts_intron_plus_exons_df <- trans_counts_all_transcripts %>% group_by(GeneID) %>% summarise(across(where(is.numeric), sum)) %>% as.data.frame()

	message('Summarizing gene counts for exons Only.. please wait.')
	geneCounts_exonOnly_df <- trans_counts_exonOnly %>% group_by(GeneID) %>% summarise(across(where(is.numeric), sum)) %>% as.data.frame()

	message('initializing checks for gene matrices')

	geneCounts_intron_plus_exons_df_copy = geneCounts_intron_plus_exons_df
	geneCounts_exonOnly_df_copy = geneCounts_exonOnly_df
	rownames(geneCounts_intron_plus_exons_df_copy) = geneCounts_intron_plus_exons_df_copy$GeneID
	geneCounts_intron_plus_exons_df_copy[,1] = NULL
	rownames(geneCounts_exonOnly_df_copy) = geneCounts_exonOnly_df_copy$GeneID
	geneCounts_exonOnly_df_copy[,1] = NULL
	geneCounts_intron_plus_exons_df_copy$AverageCounts_Intron_plus_exon = as.numeric(rowMeans(geneCounts_intron_plus_exons_df_copy))
	geneCounts_exonOnly_df_copy$AverageCounts_exonOnly = as.numeric(rowMeans(geneCounts_exonOnly_df_copy))

	diff = cbind(rownames(geneCounts_exonOnly_df_copy), as.numeric((geneCounts_intron_plus_exons_df_copy$AverageCounts_Intron_plus_exon - geneCounts_exonOnly_df_copy$AverageCounts_exonOnly)))

	diff = data.frame(diff)
	colnames(diff) = c("genes", "Difference_Intron_plus_exon_vs_exonOnly")
	diff$Difference_Intron_plus_exon_vs_exonOnly = as.numeric(diff$Difference_Intron_plus_exon_vs_exonOnly)

	diff = arrange(diff, Difference_Intron_plus_exon_vs_exonOnly)

	diff_neg = diff %>% dplyr::filter(Difference_Intron_plus_exon_vs_exonOnly < 0)
	if(nrow(diff_neg) > 0) {
		stop('Gene quantification is not appropriate. Please check your transcript counts')
	} else {
        if(opt$umiOnly == 'false'){
            outfile_intron_plus_exons = paste0(opt$outPath, "/", "analyze_incl_introns_genematrix.csv")
            outfile_exons = paste0(opt$outPath, "/", "analyze_gene_matrix.csv")
            outfile_transcripts = paste0(opt$outPath, "/", "analyze_transcript_matrix.csv")
        } else {
            outfile_intron_plus_exons = paste0(opt$outPath, "/", "analyze_incl_introns_genematrix_umis.csv")
            outfile_exons = paste0(opt$outPath, "/", "analyze_gene_matrix_umis.csv")
            outfile_transcripts = paste0(opt$outPath, "/", "analyze_transcript_matrix_umis.csv")
        }
        message('Gene Level quantification is ready.. writing files')
		trans_counts_exonOnly_copy_df_use = data.frame(trans_counts_exonOnly_copy)
		trans_counts_exonOnly_copy_df_use$TranscriptID = rownames(trans_counts_exonOnly_copy_df_use)
		transmat_cols = colnames(trans_counts_exonOnly_copy_df_use)
		transmat_cols_use = transmat_cols[! transmat_cols %in% 'TranscriptID']
		trans_counts_exonOnly_copy_df_use = trans_counts_exonOnly_copy_df_use %>% dplyr::select(TranscriptID, transmat_cols_use)
        write.csv(geneCounts_intron_plus_exons_df, outfile_intron_plus_exons, quote = F, row.names = F)
        write.csv(geneCounts_exonOnly_df, outfile_exons, quote = F, row.names = F)
        message('Transcript Level quantification is ready.. writing file')
        write.csv(trans_counts_exonOnly_copy_df_use, outfile_transcripts, quote = F, row.names = F)
        message('done!')
	}
}
