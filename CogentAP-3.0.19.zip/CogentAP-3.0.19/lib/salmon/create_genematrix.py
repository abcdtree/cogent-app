#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to generate reformat gene/transcript matrix file created by salmon
# This script receives the output file from salmon quantmerge as input
#
# -----------------------------------------------------------------------------
import os
import re
import sys
import argparse
import pathlib
import pandas as pd
import glob

DESCRIPTION = """Create gene/transcript matrix file output from salmon results."""

###
# Script information
###

# script info
SCRIPT_NAME = "create_genematrix.py"
VERSION = "3.0.19"

###
# Parse and define arguments
###


def _parse_command_line_args(sys_argv):
    """Takes in command line parameters and parses them for use

    Args:
        sys_argv: command line input

    Returns:
        args (list) : input argument values
    """
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    required = parser.add_argument_group("required arguments")

    required.add_argument(
        "-i",
        "--input_dir",
        dest="input_dir",
        help="Full path to output file from salmon quantmerge",
        required=True,
    )

    required.add_argument(
        "-t",
        "--type",
        dest="type",
        help="File type - one of genes/transcripts/introns.",
        required=True,
    )

    required.add_argument(
        "-o",
        "--output_file",
        dest="output_file",
        help="Name of the result file to be created",
        required=True,
    )

    args, unknown = parser.parse_known_args(sys_argv)
    return args


def main(sys_argv):
    args = _parse_command_line_args(sys_argv)

    input_dir = args.input_dir
    type = args.type
    outfile_name = args.output_file
    neg_index = 0
    col_replace_text = "_trimmed"

    # correct for umi-specific text in folder names
    if "umis" in outfile_name:
        neg_index = 1
        col_replace_text = "_trimmed_umionly"

    header_start = ""

    header_start = "TranscriptID"
    result_file = "quant.sf"

    salmon_result_files = os.path.join(input_dir, "*_" + result_file)

    # get barcode from folder name
    #subfolder_names = [f for f in subfolder_names if not f.startswith(".")]
    #subfolder_names.sort()

    salmon_results_list = glob.glob(salmon_result_files, recursive=True)

    sample_id = ''
    i = 0
    fields = []
    count_list = []
    gene_name_list = []
    sample_list = []

    # read the output files in
    for current_file in salmon_results_list:
        #current_file = os.path.join(input_dir, folder, result_file)
        sample_name = current_file.split("/")[-1].replace("_" + result_file, "")
        if re.match(r'(.*)[ACGTN]{12,16}(.*)', sample_name):
            if re.match(r'.*_L00\d(_trimmed)?$', sample_name):
                sample_id = sample_name.split("_")[-3 - neg_index]
            else:
                sample_id = sample_name.split("_")[-2 - neg_index]
        else:
            sample_id = sample_name.replace(col_replace_text, "")

        # save the gene names from the first csv file
        if i == 0:
            fields = ['Name', 'NumReads']
            temp_df = pd.read_csv(current_file, header=0, usecols=fields, sep='\t')
            gene_name_list = temp_df.Name.tolist()
            count_list.append(temp_df.NumReads.tolist())
            sample_list.append(sample_id)
            i = 1
        else:
            fields = ['NumReads']
            temp_df = pd.read_csv(current_file, header=0, usecols=fields, sep='\t')
            count_list.append(temp_df.NumReads.tolist())
            sample_list.append(sample_id)

    gene_df = pd.DataFrame(count_list)
    gene_df = gene_df.transpose()
    gene_df.columns = sample_list

    # sort column order by barcode name
    gene_df.sort_index(axis=1, inplace=True)
    gene_df.reset_index(drop=True)

    gene_df.insert(loc=0, column=header_start, value=gene_name_list)
    gene_df.reset_index(drop=True)

    # write the output file
    gene_df.to_csv(
        outfile_name, encoding="utf-8", index=False
    )


if __name__ == "__main__":
    main(sys.argv[1:])
