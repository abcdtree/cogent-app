#!/usr/bin/env python3

import argparse
import os
import subprocess
import sys

COGENT_INSTALL_ROOT = os.path.dirname(__file__)
COGENT_NF = os.path.join(COGENT_INSTALL_ROOT, "main.nf")


def _get_version():
    with open(os.path.join(COGENT_INSTALL_ROOT, "VERSION")) as f:
        version = f.read().strip()
        return f"Cogent NGS Analaysis Pipeline {version}\nTakara Bio USA"


class Cogent(object):
    def __init__(self, cmd, is_preview):
        self.cmd = cmd
        self.is_preview = is_preview
        if not is_preview:
            self._validate_dependencies()

    def _validate_dependencies(self):
        if cmd[0] == "nextflow":
            try:
                p = subprocess.Popen(
                    ["nextflow", "info"], stdout=subprocess.PIPE, stderr=subprocess.PIPE
                )
            except FileNotFoundError:
                print(
                    'The "nextflow" executable is required but was not found on the path. '
                    "Please ensure nextflow is installed.",
                    file=sys.stderr,
                )
                sys.exit(1)

            rc = p.wait()
            if rc != 0:
                print(
                    'There was a problem executing the "nextflow" command. '
                    "Please ensure that nextflow is installed and working.",
                    file=sys.stderr,
                )
                sys.exit(rc)

    def run(self):
        if is_preview:
            print(" ".join(self.cmd))
            return

        env = os.environ.copy()
        env['NXF_ENABLE_VIRTUAL_THREADS'] = 'false'
        p = subprocess.Popen(self.cmd, env=env)
        rc = p.wait()
        if rc != 0:
            print(
                (f'\n\nThe command "{" ".join(cmd)}" failed with returncode {rc}.'),
                file=sys.stderr,
            )
            sys.exit(rc)


class NextflowCommandBuilder(object):
    def __init__(self, args):
        self.args = args
        self.cmd = []
        self.is_preview = args.pop("preview", False)
        self.resume = args.pop("resume", False)

    def get_command(self):
        if self.cmd:
            return self.cmd, self.is_preview

        self.cmd = ["nextflow", "run", COGENT_NF]

        # The submenu processor will remove any submenu and command args
        # from self.args and add the coresponding args to the nextflow command
        # e.g. self.args "["rna", "analyze"] will append "["--analysis", "analyze"]
        # # to the nextflow command.
        submenu_processors = {
            "rna": self._process_rna_submenu,
            "dna": self._process_dna_submenu,
        }
        process_submenu = submenu_processors[self.args.pop("submenu")]
        process_submenu()

        # All remaining args are passed through to Nextflow. Various types
        # are supported -- see _add_args.
        self._add_args()

        if self.resume:
            self.cmd.append("-resume")

        return self.cmd, self.is_preview

    def _add_args(self):
        for arg, value in self.args.items():
            if value is None:
                # This is an optional arg that was not used.
                continue
            elif value is True:
                # This is a flag that be set with no argument.
                self.cmd.append(f"--{arg}")
            elif value is False:
                # This is a flag that will NOT be set.
                continue
            elif isinstance(value, list):
                # This arg allows multiple values, each of which can
                # be set by reusing the arg name, e.g. "--arg1 val1 --arg1 val2"
                # will produce a value of ["val1", "val2"] for argument arg1
                for eachvalue in value:
                    self.cmd.extend([f"--{arg}", eachvalue])
            else:
                # Set one value. String type is required, so other types
                # (like integers) must be cast as strings
                self.cmd.extend([f"--{arg}", str(value)])

    def _process_rna_submenu(self):
        command_processors = {
            "demux": self._process_demux_command,
            "analyze": self._process_analyze_command,
            "demux_and_analyze": self._process_demux_and_analyze_command,
            "postprocess": self._process_postprocess_command,
            "add_genome": self._process_add_genome_command,
        }
        process_command = command_processors[self.args.pop("command")]
        process_command()

    def _process_demux_command(self):
        self.cmd.extend(["--analysis", "demux"])

    def _process_analyze_command(self):
        self.cmd.extend(["--analysis", "analyze"])

    def _process_demux_and_analyze_command(self):
        self.cmd.extend(["--analysis", "demux_and_analyze"])
        self.cmd.extend(["--demux_mode", "copy"])

    def _process_postprocess_command(self):
        postprocess_processors = {
            "immune": self._process_immune_postprocess,
            "fusion": self._process_fusion_postprocess,
        }
        processor_command = postprocess_processors[self.args.pop("postprocess")]
        processor_command()

    def _process_add_genome_command(self):
        genome = self.args.pop("genome")
        genome_config_path = os.path.join(
            COGENT_INSTALL_ROOT, "config", "genome_sources", f"{genome}.config"
        )
        self.cmd.extend(["--analysis", "add_genome", "-c", genome_config_path])

    def _process_immune_postprocess(self):
        self.cmd.extend(["--analysis", "run_immune_analysis"])

    def _process_fusion_postprocess(self):
        self.cmd.extend(["--analysis", "run_fusion_analysis"])

    DNA_MENU_MESSAGE = (
        "This submenu contains tools for processing DNA-Seq data.\nComing soon. See "
        "https://www.takarabio.com/learning-centers/automation-systems/latest-technologies-for-ngs-library-prep"
    )

    def _process_dna_submenu(self):
        print(self.DNA_MENU_MESSAGE)
        sys.exit(0)


class CogentParser(object):
    GENOMES = ["hg38", "mm39"]

    # Format choices like "{hg38,mm39}" for help menus
    GENOME_CHOICES_STR = f"{{{','.join(GENOMES)}}}"

    RNA_DEMUX_EXPERIMENT_TYPES = [
        "stranded",
        "stranded_umi",
        "smartseq_fla",
        "smartseq_fla_umi",
        "icell8_fla",
        "smartseq_pro",
        "shasta_total_rna",
    ]

    RNA_ANALYZE_EXPERIMENT_TYPES = [
        "stranded",
        "stranded_umi",
        "smartseq_fla",
        "smartseq_fla_umi",
        "icell8_fla",
        "smartseq_pro",
    ]

    @classmethod
    def _add_arg_output_dir(cls, subparser):
        subparser.add_argument(
            "-o",
            "--output_dir",
            required=True,
            help="Name of output directory to store results.",
        )

    @classmethod
    def _add_arg_input_dir(cls, subparser):
        subparser.add_argument(
            "-i",
            "--input_dir",
            required=True,
            help="Directory contains results from demux command. "
            "The directory must contain FASTQ files after demultiplexing.",
        )

    @classmethod
    def _add_arg_demux_experiment_type(cls, subparser):
        subparser.add_argument(
            "-t",
            "--type_of_experiment",
            choices=cls.RNA_DEMUX_EXPERIMENT_TYPES,
            required=True,
            type=str.lower,
            help="Experimental protocol used.",
        )
    @classmethod
    def _add_arg_analyze_experiment_type(cls, subparser):
        subparser.add_argument(
            "-t",
            "--type_of_experiment",
            choices=cls.RNA_ANALYZE_EXPERIMENT_TYPES,
            required=True,
            type=str.lower,
            help="Experimental protocol used.",
        )

    @classmethod
    def _add_arg_input_dir_from_analyze(cls, subparser):
        subparser.add_argument(
            "-i",
            "--input_dir",
            required=True,
            help="Directory contains results from analyze command. The directory must contain genematrix and *_stats.csv.",
        )

    @classmethod
    def _add_arg_fastqc(cls, subparser):
        subparser.add_argument(
            "--fastqc",
            action="store_true",
            help="Run FASTQC to create quality reports for FASTQ files.",
        )

    @classmethod
    def _add_arg_genome(cls, subparser):
        # use metavar to display suggestions without restricting choices for custom genomes
        subparser.add_argument(
            "-g",
            "--genome",
            required=True,
            action="store",
            metavar=cls.GENOME_CHOICES_STR,
            help="Select a supported genome or provide the name of a custom genome that you installed.",
        ),

    @classmethod
    def _add_arg_genome_dir(cls, subparser):
        subparser.add_argument(
            "-G",
            "--genome_dir",
            action="store",
            help="Directory where genome and index files were installed by add_genome. [Default: $COGENT_ROOT/genomes]",
        )

    @classmethod
    def _configure_add_genome(cls, subparser_adder, rna=True):
        description = """
        Download and index a genome. This is required before running Cogent analysis.
        Human (grch38) and mouse (mm39) genomes are supported and can be downloaded from
        public sources. Too install another custom genome, create a new config file in
        $COGENT_ROOT/config/genome_sources/.
        """
        subparser = subparser_adder.add_parser(
            "add_genome",
            help="Download and index a genome with preferred STAR parameters.",
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        subparser.add_argument(
            "-g",
            "--genome",
            metavar=cls.GENOME_CHOICES_STR,
            action="store",
            required=True,
            help="Select from supported genomes or provide a name for your custom genome",
        )
        subparser.add_argument(
            "-G",
            "--genome_dir",
            action="store",
            help="Directory to store genome and index files. [Default: $COGENT_ROOT/genomes]",
        )
        if rna:
            subparser.add_argument(
                "--fusion",
                action="store_true",
                help="Download and index fusion transcripts with Salmon.",
            )

        cls._add_universal_args(subparser)

    @classmethod
    def _add_args_for_demux_workflow(
        cls, subparser, run_with_analyze=False
    ):
        """Configuration shared by demux and demux_and_analyze"""

        subparser.add_argument(
            "-f",
            "--fastq1",
            required=True,
            help="Input Read1 (R1) FASTQ file.",
        )
        subparser.add_argument(
            "-p",
            "--fastq2",
            required=True,
            help="Input Read2 (R2) FASTQ file.",
        )
        cls._add_arg_demux_experiment_type(subparser)
        cls._add_arg_output_dir(subparser)
        subparser.add_argument(
            "-b",
            "--barcodes_file",
            action="store",
            required=True,
            help="Well List file from Takara's CellSelect Software (Recommended), "
            "or another custom file containing only barcodes that were selected for sequencing.",
        )
        subparser.add_argument(
            # Barcodes file used to calculate background contamination from unselected barcodes.
            # This file is built-in for standard protocols but can be customized
            # for rare cases where a custom chip or barcode set is used.
            "-w",
            "--all_well_barcodes_file",
            help=argparse.SUPPRESS,
        )
        cls._add_arg_fastqc(subparser)
        subparser.add_argument(
            "-m",
            "--mismatch",
            choices=[0, 1],
            required=False,
            type=int,
            help="Number of allowed mismatched bases per barcode.",
        )
        subparser.add_argument(
            "-u",
            "--umi_length",
            action="store",
            required=False,
            help="Overwrite UMI length. By default, length is automatically determined by experiment type.",
        )
        subparser.add_argument(
            "-n",
            "--n_processes",
            action="store",
            required=False,
            help="Number of demultiplexing processes to spawn during execution.",
        )
        subparser.add_argument(
            "--n_writers",
            action="store",
            required=False,
            help="Number of demultiplexing writing processes to spawn during execution.",
        )
        if not run_with_analyze:
            subparser.add_argument(
                "--no_gz",
                action="store_true",
                help="Do not compress (gzip) output FASTQ files.",
            )
        subparser.add_argument(
            "--undetermined_fq",
            action="store_true",
            help="Save Undetermined/Unselected/Short reads to Undetermined FASTQ files.",
        )
        subparser.add_argument(
            "--i7_rc",
            choices=["Auto", "True", "False"],
            type=str,
            required=False,
            help='Reverse-complement I7 Index (Full Length protocol only). Enter "Auto" to detect and auto-correct the '
            "reverse complementation of I5/I7 indices by certain Illumina sequencers. Otherwise manually override with "
            '"True" or "False").',
        )
        subparser.add_argument(
            "--i5_rc",
            choices=["Auto", "True", "False"],
            type=str,
            required=False,
            help='See help section for "--i7_rc".',
        )
        subparser.add_argument(
            "--read_buffer",
            action="store",
            required=False,
            type=float,
            help="Buffer size of data sent to each demultiplexing (worker) process in GB.",
        )
        subparser.add_argument(
            "--hpc",
            action="store_true",
            help="Work as high performance computing mode. To use this option, changing file descriptors (ulimit -n) "
            "as unlimited is recommended.",
        )
        subparser.add_argument(
            "--prog",
            action="store",
            type=int,
            required=False,
            help="Number of reads to process before updating status in log file.",
        )
        subparser.add_argument(
            "--no_split_fastqs",
            action="store_true",
            help="Output merged FASTQ file(s). Barcodes are written into read names and merged into "
            "large FASTQ file. By default output into barcode-level FASTQ files.",
        )
        subparser.add_argument(
            "--use_barcodes",
            type=int,
            required=False,
            help="Limit number of barcodes to this value.",
        )
        subparser.add_argument(
            "--check_reads",
            type=int,
            required=False,
            help="Use this number of reads to estimate read counts during barcode selection.",
        )
        subparser.add_argument(
            "--min_reads",
            type=int,
            required=False,
            help="Discard barcodes with estimated read count lower than this number.",
        )
        subparser.add_argument(
            "--random_pick",
            action="store_true",
            help="Pick random reads during barcode selection, rather than anazlyzing the first N read pairs.",
        )
        subparser.add_argument(
            "--dry_run",
            action="store_true",
            help="Output estimated counts of all barcodes, but do not write demultiplexed FASTQs.",
        )
        subparser.add_argument(
            # "Barcodes map file. Defaults to standard map."
            "--bcs_map",
            help=argparse.SUPPRESS,
        )

    @classmethod
    def _configure_demux_subparser(cls, subparser_adder):
        description = """
            Script to de-multiplex barcoded reads from sequence data stored in
            FASTQ files. User options are designed to simplify de-multiplexing
            for experiments derived from Takara protocols. Barcode (and optionally
            UMI) sequences are extracted and stored in the read name. Users may
            specify whether the resulting de-multiplexed data are merged, or split
            into individual barcode-level files."""
        subparser = subparser_adder.add_parser(
            "demux",
            help="De-multiplex barcoded reads from sequence data stored in FASTQ files.",
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        cls._add_args_for_demux_workflow(subparser)
        cls._add_universal_args(subparser)

    @classmethod
    def _add_universal_args(cls, subparser):
        subparser.add_argument(
            "--resume",
            action="store_true",
            help="Resume a previous pipeline run with the same inputs",
        )

        subparser.add_argument(
            "--preview",
            action="store_true",
            help="Print nextflow command without executing it.",
        )

    @classmethod
    def _add_args_for_analysis_workflow(
        cls, subparser, run_with_demux=False
    ):
        """Configuration shared by analyze and demux_and_analyze"""

        cls._add_arg_genome(subparser)
        cls._add_arg_genome_dir(subparser)
        # Exclude flags that are redundant with analyze in "demux_and_analyze" command.
        if not run_with_demux:
            cls._add_arg_output_dir(subparser)
            cls._add_arg_input_dir(subparser)
            cls._add_arg_fastqc(subparser)
            cls._add_arg_analyze_experiment_type(subparser)

        subparser.add_argument(
            "--immune", action="store_true", help="Generate immune profiling matrix."
        )
        subparser.add_argument(
            "--fusion", action="store_true", help="Generate gene fusion matrix."
        )
        subparser.add_argument(
            "--skip_ribodepletion",
            action="store_true",
            help="Skip in silico removal of ribosomal RNA.",
        )
        subparser.add_argument(
            "--keep_bam",
            action="store_true",
            help="Save genome and transcriptome BAM files from STAR.",
        )

    @classmethod
    def _configure_analyze_subparser(cls, subparser_adder):
        description = """
            Script to perform counting analysis for exons and genes by fastq input data.
            The input to this script are files output by Cogent demux.
            The fastq files are expected to contain the barcode info in the read name.
            Optionally it can also contain UMI info following the BC.
            The modules currently included are:
                - Trimming (cutadapt)
                - Alignment (STAR)
                - Counting (featureCounts)
                - Summarization (TBUSA)
                - Reporting (TBUSA, CogentDS)"""
        subparser = subparser_adder.add_parser(
            "analyze",
            help="Perform counting analysis for exons and genes by fastq input data.",
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        cls._add_args_for_analysis_workflow(subparser)
        cls._add_universal_args(subparser)

    @classmethod
    def _configure_demux_and_analyze_subparser(
        cls, subparser_adder, experiment_types=None
    ):
        description = """
        This command is a convenience to execute both the "demux" and "analyze" commands with a single
        command. Inputs are the same as for the "demux" command, FASTQ files containing barcoded reads.
        Outputs are the same as for the "analyze" command, including gene and transcript counts and
        aligned reads."""

        subparser = subparser_adder.add_parser(
            "demux_and_analyze",
            help="Demultiplex barcoded reads and perform counting analysis.",
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        cls._add_args_for_demux_workflow(
            subparser, run_with_analyze=True)
        cls._add_args_for_analysis_workflow(
            subparser, run_with_demux=True)
        cls._add_universal_args(subparser)

    @classmethod
    def _configure_immune_postprocess(cls, subparser_adder):
        description = """
        A command for perfoming immune-profiling on split fastqs.
        The input to this script are files output by Cogent demux.
        The fastq files are expected to contain the barcode info in the read name.
        The modules currently included are:
            -- read assembly & clonotype identification (Trust4)"""

        help = "Perform immune profiling analysis by results from demux and analyze command."
        subparser = subparser_adder.add_parser(
            "immune",
            help=help,
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        cls._add_arg_input_dir_from_analyze(subparser)
        cls._add_arg_output_dir(subparser)
        cls._add_arg_genome(subparser)
        cls._add_arg_genome_dir(subparser)
        cls._add_universal_args(subparser)

    @classmethod
    def _configure_fusion_postprocess(cls, subparser_adder):
        description = """
        A command to perform gene fusion detection analysis.
        The input to this command is result directory from analyze command.
        The directory is expected to contain junction information files (.Chimeric.out.junction) and stats.csv
        This analysis ignores UMI even if UMI enabled experiment type is specified."""

        help = "Perform gene fusion detection analysis by results from analyze command."
        subparser = subparser_adder.add_parser(
            "fusion",
            help=help,
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        cls._add_arg_input_dir_from_analyze(subparser)
        cls._add_arg_output_dir(subparser)
        cls._add_arg_genome(subparser)
        cls._add_arg_genome_dir(subparser)
        cls._add_universal_args(subparser)

    @classmethod
    def _configure_postprocess_rna_analysis(cls, parser_adder):
        description = """
        Additional analysis options that may be run run after "analyze" is completed."""
        help = description
        parser = parser_adder.add_parser(
            "postprocess",
            help=help,
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        subparser_adder = parser.add_subparsers(dest="postprocess")
        subparser_adder.required = (
            True  # Force parser error if called with no postprocess command
        )
        cls._configure_immune_postprocess(subparser_adder)
        cls._configure_fusion_postprocess(subparser_adder)

    @classmethod
    def _configure_rna_parser(cls, parser):
        subparser_adder = parser.add_subparsers(dest="command")
        subparser_adder.required = True  # Force parser error if called with no command
        cls._configure_demux_subparser(
            subparser_adder
        )
        cls._configure_analyze_subparser(
            subparser_adder
        )
        # cls._configure_demux_and_analyze_subparser(
        #     subparser_adder
        # )
        cls._configure_postprocess_rna_analysis(subparser_adder)
        cls._configure_add_genome(subparser_adder)
        return parser

    @classmethod
    def _configure_dna_parser(cls, parser):
        # no-op
        return parser

    @classmethod
    def get_parser(cls):
        description = """
        Tools for procoessing DNA and RNA sequencing data produced with Takara Bio kits and platforms.
        See detailed help for each of the submenus below."""

        parser = argparse.ArgumentParser(
            "cogent",
            description=description,
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        parser.add_argument("-v", "--version", action="version", version=_get_version())
        subparser_adder = parser.add_subparsers(dest="submenu")
        subparser_adder.required = True  # Force parser error if called with no submenu
        cls._configure_rna_parser(
            subparser_adder.add_parser(
                "rna",
                help="RNA analysis tools",
                description="""This submenu contains tools for processing RNA-Seq data.""",
                formatter_class=argparse.RawDescriptionHelpFormatter,
            )
        )
        cls._configure_dna_parser(
            subparser_adder.add_parser(
                "dna",
                help="DNA analysis tools",
                description=NextflowCommandBuilder.DNA_MENU_MESSAGE,
                formatter_class=argparse.RawDescriptionHelpFormatter,
            )
        )
        return parser

    @classmethod
    def parse_args(cls):
        return vars(cls.get_parser().parse_args())


if __name__ == "__main__":
    args = CogentParser.parse_args()
    cmd, is_preview = NextflowCommandBuilder(args).get_command()
    Cogent(cmd, is_preview).run()
