#!/usr/bin/env python3

import os
import subprocess
import sys
import tempfile
import unittest

# These tests are configured to validate the NextFlow commands produced by the CLI
# using "--preview" mode. To execute the full workflows, set PREVIEW_ONLY = False.
PREVIEW_ONLY = True

COGENT_ROOT = os.path.realpath(os.path.join(os.path.dirname(__file__), ".."))
COGENT_EXECUTABLE = os.path.join(COGENT_ROOT, "cogent")

EXPECTED_VERSION = "3.0.19"

RNA_ANALYSIS_TYPES = [
    "stranded",
    "stranded_UMI",
    "smartseq_fla",
    "smartseq_fla_umi",
    "icell8_fla",
]


class ArgValidator:
    """Base class for argument validators.
    ArgValidators are used for checking expected args in the NextFlow commands produced by the CLI.
    They can simply check against an expected value or implemenet more complex validations like
    checking if a file exists or if the arg contains an expected substring. A MultiValidator
    can be used to combine multiple validators.
    """

    pass


class StringValidator(ArgValidator):
    """Checks if value matches expected string."""

    def __init__(self, expected_value):
        assert isinstance(expected_value, (str, int, float))
        # Numbers are converted to strings so we can compare them to the args in the NextFlow command.
        self.expected_value = str(expected_value)

    def validate(self, arg, error_list):
        is_valid = arg == self.expected_value
        if not is_valid:
            error_list.append(f"Expected value {self.expected_value} but got {arg}.")
        return is_valid


class FileExistsValidator(ArgValidator):
    """Checks if value is the name of an existing file."""

    def validate(self, arg, error_list):
        is_valid = os.path.exists(arg)
        if not is_valid:
            error_list.append(f"File {arg} does not exist.")
        return is_valid


class StringContainsValidator(ArgValidator):
    """Checks if value contains an expected substring."""

    def __init__(self, pattern):
        self.pattern = pattern

    def validate(self, arg, error_list):
        is_valid = self.pattern in arg
        if not is_valid:
            error_list.append(f"Expected value {self.pattern} not found in {arg}.")
        return is_valid


class MultiValidator(ArgValidator):
    """Combines multiple validators."""

    def __init__(self, validators):
        self.validators = []
        for validator in validators:
            if isinstance(validator, (str, int, float)):
                # For convenience, we allow strings and numbers in place of a StringValidator.
                # We convert them to a StringValidator here.
                self.validators.append(StringValidator(validator))
            else:
                # If not a string, we expect an instance of ArgValidator.
                assert isinstance(validator, ArgValidator)
                self.validators.append(validator)

    def validate(self, arg, error_list):
        return all(validator.validate(arg, error_list) for validator in self.validators)


class Validator:
    """The "Validator" class is used to validate a list of expected args in a NextFlow command,
    using one or more ArgValidators for each argument.
    """

    def __init__(self, arg_validators):
        # We expect a list with one validator for each argument in the NextFlow command.
        self.arg_validators = []
        for validator in arg_validators:
            if isinstance(validator, (str, int, float)):
                # For convenience, we allow strings and numbers in place of a StringValidator.
                # We convert them to a StringValidator here.
                self.arg_validators.append(StringValidator(validator))
            elif isinstance(validator, list):
                # If a list is provided, we treat it as a list of validators and convert it to a MultiValidator.
                self.arg_validators.append(MultiValidator(validator))
            else:
                # Otherwise the validator provided by the test case should already be a
                # subclass of ArgValidator
                assert isinstance(validator, ArgValidator)
                self.arg_validators.append(validator)
        self.errors = []

    def validate(self, nextflow_command):
        args = nextflow_command.split(" ")
        if len(args) > len(self.arg_validators):
            self.errors.append(
                f"Too many arguments in NextFlow command, or test case is missing ArgValidators: {nextflow_command}"
            )
            return False
        if len(args) < len(self.arg_validators):
            self.errors.append(
                f"Not enough arguments in NextFlow command, or test case has too many ArgValidators: {nextflow_command}"
            )
            return False
        return all(
            validator.validate(arg, self.errors)
            for validator, arg in zip(self.arg_validators, args)
        )


class BaseCliTestCase(unittest.TestCase):
    # test_cases should be overridden in the child class.
    test_cases = {
        # "test_case_name": (
        #     ["list", "of", "cogent", "cli", "args"],
        #     Validator(["expected", "values", "or", ArgValidator, "for", "args", "in", "nextflow", "command"]),
        # ),
    }

    def test_all_test_cases(self):
        """Run all test cases and validate the NextFlow commands produced by the CLI."""
        for test_case, (cmd, validator) in self.test_cases.items():
            self._run_and_check(cmd, validator, test_case)

    def _run(self, cli_command):
        p = subprocess.Popen(
            [COGENT_EXECUTABLE] + [str(a) for a in cli_command],
            stderr=subprocess.PIPE,
            stdout=subprocess.PIPE,
        )
        out, err = p.communicate()
        rc = p.wait()
        return rc, out.decode().strip(), err.decode().strip()

    def _run_as_preview(self, cli_command):
        return self._run(cli_command + ["--preview"])

    def _run_and_check(self, cmd, validator, test_case):
        rc, command_preview, err = self._run_as_preview(cmd)
        self.assertEqual(
            rc,
            0,
            f"Test case {test_case} failed with nonzero returncode {rc} and error:\n{err}",
        )
        self.assertTrue(
            validator.validate(command_preview),
            f"Test case {test_case} preview command failed validation with errors:\n{validator.errors}",
        )
        if not PREVIEW_ONLY:
            """Run the full NextFlow workflow if PREVIEW_ONLY is False."""
            rc, out, err = self._run(cmd)
            self.assertEqual(
                rc,
                0,
                f"Test case {test_case} failed with nonzero returncode {rc} and output:\n{out}\n{err}",
            )


class TestCli_Version(BaseCliTestCase):
    def test_version(self):
        rc, out, err = self._run(["--version"])
        self.assertEqual(rc, 0)
        self.assertIn(EXPECTED_VERSION, out)
        self.assertEqual(err, "")


class TestCli_Help(BaseCliTestCase):
    def test_help(self):
        rc, out, err = self._run(["--help"])
        self.assertEqual(rc, 0)
        self.assertIn(
            "Tools for procoessing DNA and RNA sequencing data produced with Takara Bio kits and platforms",
            out,
        )
        self.assertEqual(err, "")


class TestCli_Rna_AddGenome(BaseCliTestCase):
    GENOME_DIR = os.path.join(os.path.expanduser("~"), "genomes")
    GENOME = "hg38"

    test_cases = {
        "rna_add_genome_required_options_only": (
            ["rna", "add_genome", "--genome", GENOME],
            Validator(
                [
                    "nextflow",
                    "run",
                    [FileExistsValidator(), StringContainsValidator("main.nf")],
                    "--analysis",
                    "add_genome",
                    "-c",
                    [
                        FileExistsValidator(),
                        StringContainsValidator(f"{GENOME}.config"),
                    ],
                ]
            ),
        ),
        "rna_add_genome_all_options": (
            ["rna", "add_genome", "-g", GENOME, "--genome_dir", GENOME_DIR, "--fusion"],
            Validator(
                [
                    "nextflow",
                    "run",
                    [FileExistsValidator(), StringContainsValidator("main.nf")],
                    "--analysis",
                    "add_genome",
                    "-c",
                    [
                        FileExistsValidator(),
                        StringContainsValidator(f"{GENOME}.config"),
                    ],
                    "--genome_dir",
                    GENOME_DIR,
                    "--fusion",
                ]
            ),
        ),
    }

    def test_neg_add_genome_missing_required_arg_genome(self):
        rc, out, err = self._run_as_preview(["rna", "add_genome"])
        self.assertEqual(rc, 2)
        self.assertIn("error: the following arguments are required: -g/--genome", err)


class TestCli_Rna_Demux(BaseCliTestCase):
    FASTQ1 = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "test_FL_R1.fastq.gz",
    )
    FASTQ2 = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "test_FL_R2.fastq.gz",
    )
    TYPE_OF_EXPERIMENT = "icell8_fla"
    BARCODES_FILE = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "99999_CogentAP_test_selected_WellList.TXT",
    )

    ALL_WELL_BARCODES_FILE = BARCODES_FILE

    DEFAULT_MISMATCH = 1
    DEFAULT_N_PROCESSES = 15
    DEFAULT_N_WRITERS = 8
    DEFAULT_I7_RC = "Auto"
    DEFAULT_I5_RC = "Auto"
    DEFAULT_READ_BUFFER = 0.01
    DEFAULT_PROG = 10000000
    DEFAULT_USE_BARCODES = 10000
    DEFAULT_CHECK_READS = 10000000
    DEFAULT_MIN_READS = 1000

    MISMATCH = 0
    N_PROCESSES = 4
    N_WRITERS = 2
    I7_RC = "True"
    I5_RC = "True"
    READ_BUFFER = 0.1
    PROG = 1000000
    USE_BARCODES = 7000
    CHECK_READS = 7000000
    MIN_READS = 700
    UMI_LENGTH = 12

    def setUp(self):
        self.OUTPUT_DIR = tempfile.TemporaryDirectory()
        self.test_cases = {
            "rna_demux_required_options_only": (
                [
                    "rna",
                    "demux",
                    "--fastq1",
                    self.FASTQ1,
                    "--fastq2",
                    self.FASTQ2,
                    "--type_of_experiment",
                    self.TYPE_OF_EXPERIMENT,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--barcodes_file",
                    self.BARCODES_FILE,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "demux",
                        "--fastq1",
                        self.FASTQ1,
                        "--fastq2",
                        self.FASTQ2,
                        "--type_of_experiment",
                        self.TYPE_OF_EXPERIMENT,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--barcodes_file",
                        self.BARCODES_FILE,
                        "--mismatch",
                        self.DEFAULT_MISMATCH,
                        "--n_processes",
                        self.DEFAULT_N_PROCESSES,
                        "--n_writers",
                        self.DEFAULT_N_WRITERS,
                        "--i7_rc",
                        self.DEFAULT_I7_RC,
                        "--i5_rc",
                        self.DEFAULT_I5_RC,
                        "--read_buffer",
                        self.DEFAULT_READ_BUFFER,
                        "--prog",
                        self.DEFAULT_PROG,
                        "--use_barcodes",
                        self.DEFAULT_USE_BARCODES,
                        "--check_reads",
                        self.DEFAULT_CHECK_READS,
                        "--min_reads",
                        self.DEFAULT_MIN_READS,
                    ]
                ),
            ),
            "rna_demux_all_options": (
                [
                    "rna",
                    "demux",
                    "--fastq1",
                    self.FASTQ1,
                    "--fastq2",
                    self.FASTQ2,
                    "--type_of_experiment",
                    self.TYPE_OF_EXPERIMENT,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--barcodes_file",
                    self.BARCODES_FILE,
                    "--all_well_barcodes_file",
                    self.ALL_WELL_BARCODES_FILE,
                    "--mismatch",
                    self.MISMATCH,
                    "--umi_length",
                    self.UMI_LENGTH,
                    "--n_processes",
                    self.N_PROCESSES,
                    "--n_writers",
                    self.N_WRITERS,
                    "--undetermined_fq",
                    "--i7_rc",
                    self.I7_RC,
                    "--i5_rc",
                    self.I5_RC,
                    "--read_buffer",
                    self.READ_BUFFER,
                    "--hpc",
                    "--prog",
                    self.PROG,
                    "--use_barcodes",
                    self.USE_BARCODES,
                    "--check_reads",
                    self.CHECK_READS,
                    "--min_reads",
                    self.MIN_READS,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "demux",
                        "--fastq1",
                        self.FASTQ1,
                        "--fastq2",
                        self.FASTQ2,
                        "--type_of_experiment",
                        self.TYPE_OF_EXPERIMENT,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--barcodes_file",
                        self.BARCODES_FILE,
                        "--all_well_barcodes_file",
                        self.ALL_WELL_BARCODES_FILE,
                        "--mismatch",
                        self.MISMATCH,
                        "--umi_length",
                        self.UMI_LENGTH,
                        "--n_processes",
                        self.N_PROCESSES,
                        "--n_writers",
                        self.N_WRITERS,
                        "--undetermined_fq",
                        "--i7_rc",
                        self.I7_RC,
                        "--i5_rc",
                        self.I5_RC,
                        "--read_buffer",
                        self.READ_BUFFER,
                        "--hpc",
                        "--prog",
                        self.PROG,
                        "--use_barcodes",
                        self.USE_BARCODES,
                        "--check_reads",
                        self.CHECK_READS,
                        "--min_reads",
                        self.MIN_READS,
                    ]
                ),
            ),
        }

    def tearDown(self):
        self.OUTPUT_DIR.cleanup()


class TestCli_Rna_Analyze(BaseCliTestCase):
    INPUT_DIR = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
    )
    OUTPUT_DIR = tempfile.TemporaryDirectory()
    GENOME = "mm10"

    def setUp(self):
        self.OUTPUT_DIR = tempfile.TemporaryDirectory()
        self.test_cases = {
            "rna_analyze_required_options_only": (
                [
                    "rna",
                    "analyze",
                    "--genome",
                    self.GENOME,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--input_dir",
                    self.INPUT_DIR,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "analyze",
                        "--genome",
                        self.GENOME,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--input_dir",
                        self.INPUT_DIR,
                    ]
                ),
            ),
            "rna_analyze_all_options": (
                [
                    "rna",
                    "analyze",
                    "--genome",
                    self.GENOME,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--input_dir",
                    self.INPUT_DIR,
                    "--immune",
                    "--fusion",
                    "--skip_ribodepletion",
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "analyze",
                        "--genome",
                        self.GENOME,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--input_dir",
                        self.INPUT_DIR,
                        "--immune",
                        "--fusion",
                        "--skip_ribodepletion",
                    ]
                ),
            ),
        }

    def tearDown(self):
        self.OUTPUT_DIR.cleanup()


class TestCli_Rna_DemuxAndAnalyze(BaseCliTestCase):
    FASTQ1 = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "test_FL_R1.fastq.gz",
    )
    FASTQ2 = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "test_FL_R2.fastq.gz",
    )
    TYPE_OF_EXPERIMENT = "icell8_fla"
    GENOME = "mm39"
    BARCODES_FILE = os.path.join(
        COGENT_ROOT,
        "test",
        "fixtures",
        "experiments",
        "icell8_fla",
        "99999_CogentAP_test_selected_WellList.TXT",
    )
    ALL_WELL_BARCODES_FILE = BARCODES_FILE

    DEFAULT_MISMATCH = 1
    DEFAULT_N_PROCESSES = 15
    DEFAULT_N_WRITERS = 8
    DEFAULT_I7_RC = "Auto"
    DEFAULT_I5_RC = "Auto"
    DEFAULT_READ_BUFFER = 0.01
    DEFAULT_PROG = 10000000
    DEFAULT_USE_BARCODES = 10000
    DEFAULT_CHECK_READS = 10000000
    DEFAULT_MIN_READS = 1000

    MISMATCH = 0
    N_PROCESSES = 4
    N_WRITERS = 2
    I7_RC = "True"
    I5_RC = "True"
    READ_BUFFER = 0.1
    PROG = 1000000
    USE_BARCODES = 7000
    CHECK_READS = 7000000
    MIN_READS = 700
    UMI_LENGTH = 12

    def setUp(self):
        self.OUTPUT_DIR = tempfile.TemporaryDirectory()
        self.test_cases = {
            "rna_demux_and_analyze_required_options_only": (
                [
                    "rna",
                    "demux_and_analyze",
                    "--fastq1",
                    self.FASTQ1,
                    "--fastq2",
                    self.FASTQ2,
                    "--type_of_experiment",
                    self.TYPE_OF_EXPERIMENT,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--barcodes_file",
                    self.BARCODES_FILE,
                    "--genome",
                    self.GENOME,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "demux_and_analyze",
                        "--demux_mode",
                        "copy",
                        "--fastq1",
                        self.FASTQ1,
                        "--fastq2",
                        self.FASTQ2,
                        "--type_of_experiment",
                        self.TYPE_OF_EXPERIMENT,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--barcodes_file",
                        self.BARCODES_FILE,
                        "--mismatch",
                        self.DEFAULT_MISMATCH,
                        "--n_processes",
                        self.DEFAULT_N_PROCESSES,
                        "--n_writers",
                        self.DEFAULT_N_WRITERS,
                        "--i7_rc",
                        self.DEFAULT_I7_RC,
                        "--i5_rc",
                        self.DEFAULT_I5_RC,
                        "--read_buffer",
                        self.DEFAULT_READ_BUFFER,
                        "--prog",
                        self.DEFAULT_PROG,
                        "--use_barcodes",
                        self.DEFAULT_USE_BARCODES,
                        "--check_reads",
                        self.DEFAULT_CHECK_READS,
                        "--min_reads",
                        self.DEFAULT_MIN_READS,
                        "--genome",
                        self.GENOME,
                    ]
                ),
            ),
            "rna_demux_and_analyze_all_options": (
                [
                    "rna",
                    "demux_and_analyze",
                    "--fastq1",
                    self.FASTQ1,
                    "--fastq2",
                    self.FASTQ2,
                    "--type_of_experiment",
                    self.TYPE_OF_EXPERIMENT,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--barcodes_file",
                    self.BARCODES_FILE,
                    "--all_well_barcodes_file",
                    self.ALL_WELL_BARCODES_FILE,
                    "--mismatch",
                    self.MISMATCH,
                    "--umi_length",
                    self.UMI_LENGTH,
                    "--n_processes",
                    self.N_PROCESSES,
                    "--n_writers",
                    self.N_WRITERS,
                    "--undetermined_fq",
                    "--i7_rc",
                    self.I7_RC,
                    "--i5_rc",
                    self.I5_RC,
                    "--read_buffer",
                    self.READ_BUFFER,
                    "--hpc",
                    "--prog",
                    self.PROG,
                    "--use_barcodes",
                    self.USE_BARCODES,
                    "--check_reads",
                    self.CHECK_READS,
                    "--min_reads",
                    self.MIN_READS,
                    "--genome",
                    self.GENOME,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "demux_and_analyze",
                        "--demux_mode",
                        "copy",
                        "--fastq1",
                        self.FASTQ1,
                        "--fastq2",
                        self.FASTQ2,
                        "--type_of_experiment",
                        self.TYPE_OF_EXPERIMENT,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--barcodes_file",
                        self.BARCODES_FILE,
                        "--all_well_barcodes_file",
                        self.ALL_WELL_BARCODES_FILE,
                        "--mismatch",
                        self.MISMATCH,
                        "--umi_length",
                        self.UMI_LENGTH,
                        "--n_processes",
                        self.N_PROCESSES,
                        "--n_writers",
                        self.N_WRITERS,
                        "--undetermined_fq",
                        "--i7_rc",
                        self.I7_RC,
                        "--i5_rc",
                        self.I5_RC,
                        "--read_buffer",
                        self.READ_BUFFER,
                        "--hpc",
                        "--prog",
                        self.PROG,
                        "--use_barcodes",
                        self.USE_BARCODES,
                        "--check_reads",
                        self.CHECK_READS,
                        "--min_reads",
                        self.MIN_READS,
                        "--genome",
                        self.GENOME,
                    ]
                ),
            ),
        }

    def tearDown(self):
        self.OUTPUT_DIR.cleanup()


class TestCli_Rna_Postprocess(BaseCliTestCase):
    INPUT_DIR = tempfile.TemporaryDirectory()
    OUTPUT_DIR = tempfile.TemporaryDirectory()
    GENOME = "hg38"

    def setUp(self):
        self.OUTPUT_DIR = tempfile.TemporaryDirectory()
        self.test_cases = {
            "rna_fusion_postprocess": (
                [
                    "rna",
                    "postprocess",
                    "fusion",
                    "--input_dir",
                    self.INPUT_DIR.name,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--genome",
                    self.GENOME,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "run_fusion_analysis",
                        "--input_dir",
                        self.INPUT_DIR.name,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--genome",
                        self.GENOME,
                    ]
                ),
            ),
            "rna_immune_postprocess": (
                [
                    "rna",
                    "postprocess",
                    "immune",
                    "--input_dir",
                    self.INPUT_DIR.name,
                    "--output_dir",
                    self.OUTPUT_DIR.name,
                    "--genome",
                    self.GENOME,
                ],
                Validator(
                    [
                        "nextflow",
                        "run",
                        [FileExistsValidator(), StringContainsValidator("main.nf")],
                        "--analysis",
                        "run_immune_analysis",
                        "--input_dir",
                        self.INPUT_DIR.name,
                        "--output_dir",
                        self.OUTPUT_DIR.name,
                        "--genome",
                        self.GENOME,
                    ]
                ),
            ),
        }

    def tearDown(self):
        self.OUTPUT_DIR.cleanup()
        self.INPUT_DIR.cleanup()


class TesCli_Dna(BaseCliTestCase):
    def test_dna(self):
        rc, out, err = self._run(["dna"])
        self.assertEqual(rc, 0)
        self.assertIn("This submenu contains tools for processing DNA-Seq data", out)
        self.assertIn("Coming soon", out)


if __name__ == "__main__":
    unittest.main(sys.modules[__name__])
