import sys
import unittest

sys.path.append("lib")

from common.util.ordered_set import OrderedSet  # noqa: E402


class TestOrderedSet(unittest.TestCase):
    def test_init(self):
        s = OrderedSet()
        self.assertEqual(len(s), 0)

        s = OrderedSet([1, 2, 3])
        self.assertEqual(len(s), 3)

        s = OrderedSet([1, 2, 3, 1, 2, 3])
        self.assertEqual(len(s), 3)

    def test_add(self):
        s = OrderedSet()
        s.add(1)
        self.assertEqual(len(s), 1)
        s.add(2)
        self.assertEqual(len(s), 2)
        s.add(1)
        self.assertEqual(len(s), 2)

    def test_issuperset(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(s.issuperset([1, 2]))
        self.assertTrue(s.issuperset([1, 2, 3]))
        self.assertFalse(s.issuperset([1, 2, 3, 4]))
        self.assertTrue(s.issuperset(OrderedSet([1, 2])))
        self.assertTrue(s.issuperset(OrderedSet([1, 2, 3])))
        self.assertFalse(s.issuperset(OrderedSet([1, 2, 3, 4])))

    def test_union(self):
        s = OrderedSet([1, 2, 3])
        self.assertEqual(s.union([1, 2]), {1, 2, 3})
        self.assertEqual(s.union([1, 2, 3]), {1, 2, 3})
        self.assertEqual(s.union([1, 2, 3, 4]), {1, 2, 3, 4})
        self.assertEqual(s.union(OrderedSet([1, 2])), {1, 2, 3})
        self.assertEqual(s.union(OrderedSet([1, 2, 3])), {1, 2, 3})
        self.assertEqual(s.union(OrderedSet([1, 2, 3, 4])), {1, 2, 3, 4})

    def test_eq(self):
        s = OrderedSet([1, 2, 3])
        self.assertEqual(s, {1, 2, 3})
        self.assertNotEqual(s, {1, 2})
        self.assertEqual(s, OrderedSet({1, 2, 3}))
        self.assertNotEqual(s, OrderedSet({1, 2}))

    def test_ne(self):
        s = OrderedSet([1, 2, 3])
        self.assertNotEqual(s, {1, 2})
        self.assertEqual(s, {1, 2, 3})
        self.assertNotEqual(s, OrderedSet({1, 2}))
        self.assertEqual(s, OrderedSet({1, 2, 3}))

    def test_lt(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(s < {1, 2, 3, 4})
        self.assertFalse(s < {1, 2, 3})
        self.assertTrue(s < OrderedSet({1, 2, 3, 4}))
        self.assertFalse(s < OrderedSet({1, 2, 3}))

    def test_le(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(s <= {1, 2, 3, 4})
        self.assertTrue(s <= {1, 2, 3})
        self.assertFalse(s <= {1, 2})
        self.assertTrue(s <= OrderedSet({1, 2, 3, 4}))
        self.assertTrue(s <= OrderedSet({1, 2, 3}))
        self.assertFalse(s <= OrderedSet({1, 2}))

    def test_gt(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(s > {1, 2})
        self.assertFalse(s > {1, 2, 3})
        self.assertTrue(s > OrderedSet({1, 2}))
        self.assertFalse(s > OrderedSet({1, 2, 3}))

    def test_ge(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(s >= {1, 2})
        self.assertTrue(s >= {1, 2, 3})
        self.assertFalse(s >= {1, 2, 3, 4})
        self.assertTrue(s >= OrderedSet({1, 2}))
        self.assertTrue(s >= OrderedSet({1, 2, 3}))
        self.assertFalse(s >= OrderedSet({1, 2, 3, 4}))

    def test_iter(self):
        s = OrderedSet([1, 2, 3])
        self.assertEqual(list(s), [1, 2, 3])

    def test_contains(self):
        s = OrderedSet([1, 2, 3])
        self.assertTrue(1 in s)
        self.assertFalse(4 in s)

    def test_repr(self):
        s = OrderedSet([1, 2, 3])
        self.assertEqual(repr(s), "OrderedSet([1, 2, 3])")
