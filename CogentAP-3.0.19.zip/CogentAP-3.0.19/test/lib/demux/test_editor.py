import sys
import tempfile
import unittest

sys.path.append("lib")

from demux.editor import Editor  # noqa: E402


class TestNormalEditor(unittest.TestCase):
    def setUp(self):
        self.temp_file = tempfile.NamedTemporaryFile(delete=True)

    def test_init(self):
        editor = Editor(self.temp_file.name, gzip=False)
        self.assertEqual(editor._write_pointer, 0)
        self.assertEqual(editor._chunks, dict())
        self.assertEqual(editor._out_file, self.temp_file.name)
        self.assertEqual(editor._mode, "ab")
        self.assertEqual(editor._hpc_mode, False)
        self.assertEqual(editor._gzip, False)
        self.assertIsNone(editor._out_file_stream)

    def test_hpc_mode(self):
        editor = Editor(self.temp_file.name, gzip=False, hpc_mode=True)
        self.assertEqual(editor._write_pointer, 0)
        self.assertEqual(editor._chunks, dict())
        self.assertEqual(editor._out_file, self.temp_file.name)
        self.assertEqual(editor._mode, "ab")
        self.assertEqual(editor._hpc_mode, True)
        self.assertEqual(editor._gzip, False)
        self.assertIsNotNone(editor._out_file_stream)

    def test_write(self):
        editor = Editor(self.temp_file.name)
        editor.write("data".encode("utf-8"), 0)
        self.assertEqual(len(editor._chunks), 0)

    def test_write_chunks_to_file(self):
        editor = Editor(self.temp_file.name)
        editor.write("data".encode("utf-8"), 0)
        editor.write("data".encode("utf-8"), 1)
        editor._write_chunks_to_file(editor._out_file_stream)
        self.assertEqual(len(editor._chunks), 0)

    def test_write_chunks_to_file_out_of_order(self):
        editor = Editor(self.temp_file.name)

        # Chunk 1 cannot be flushed until chunk 0 is written
        editor.write("data".encode("utf-8"), 1)
        self.assertEqual(len(editor._chunks), 1)

        editor.write("data".encode("utf-8"), 0)
        editor._write_chunks_to_file(editor._out_file_stream)
        self.assertEqual(len(editor._chunks), 0)

    def test_raise_error_for_unflushed_chunks(self):
        editor = Editor(self.temp_file.name)
        editor.write("data".encode("utf-8"), 1)
        self.assertEqual(len(editor._chunks), 1)
        with self.assertWarns(Warning):
            editor.close()
