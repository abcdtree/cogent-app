#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script for CogentAP.
# This script receives one sub-command and parameters for that.
# Then appropriate task according to the sub-command is run.
#

from datetime import datetime
from ensurepip import version
from os import path
import sys
import argparse
import os
import importlib.util
import importlib

import common.arguments as arguments
import add_genome.add_genome as add_genome
import analyze.analyzer as analyzer
import run_transcript_analysis.run_transcript_analysis as run_transcript_analysis
import run_fusion_analysis.run_fusion_analysis as run_fusion_analysis
import run_immune_analysis.run_immune_analysis as run_immune_analysis
import merge_bam.merge_bam as merge_bam
from common.experiment.experiment import Experiment
from common.util.util import elapsed_time
import demux.demuxer as demuxer

from common.logger import Logger
from common.config import Config
from typing import Dict, List, Union

# -----------------------------------------------------------------------------
# region: Script Info
SCRIPT_NAME = "cogent"
DESCRIPTION="""
	Script to perform NGS analysis. Please see helps of each command for details.
"""
# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Commands Definition
SUB_COMMANDS = {
	'add_genome': [add_genome.MAIN_DESC, add_genome.SUB_DESC],
	'demux': [demuxer.MAIN_DESC, demuxer.SUB_DESC],
	'analyze': [analyzer.MAIN_DESC, analyzer.SUB_DESC],
	'run_transcript_analysis': [run_transcript_analysis.MAIN_DESC, run_transcript_analysis.SUB_DESC],
	'run_immune_analysis':[run_immune_analysis.MAIN_DESC, run_immune_analysis.SUB_DESC],
	'run_fusion_analysis': [run_fusion_analysis.MAIN_DESC, run_fusion_analysis.SUB_DESC],
	'merge_bam': [merge_bam.MAIN_DESC, merge_bam.SUB_DESC]
}
# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Functions

# Get version str
def get_version() -> str:
	# Reads version number from VERSION file
	try:
		install_dir = os.path.join(os.path.dirname(__file__), '..')
		with open(os.path.join(install_dir, 'VERSION')) as f:
			version_no = f.read().strip()
			return version_no
	except:
		print('Error: Cannot open VERSION file.', file=sys.stderr)
		return 'ERROR'

# Print command versions
def print_versions():
	"""Print versions of Cogent
	"""

	# Reads version number from VERSION file
	version_str = get_version()
	if version_str != 'ERROR':
		print('v%s' % (version_str))

# Prepare arguments
def prepare_arguments(command: str, required, optional, default_configs: Dict[str, List[str]], experiment_names: List[str]) -> bool:
	"""Prepare arguments according to passed command

	Arguments:
		command {str} -- sub command
		default_configs {Dict[str, List[str]]} -- load data from local_config.csv

	Returns:
		bool -- success, or not
	"""
	genome_choices = [k.split(Config.GENOME_CONFIG_DELIMITER)[1] for k, v in default_configs.items() if Config.GENOME_CONFIG_KEY in k]

	if command == 'add_genome':
		arguments.prepare_add_genome(required, optional)
	elif command == 'demux':
		arguments.prepare_demux(required, optional, experiment_names)
	elif command == 'analyze':
		arguments.prepare_analyze(required, optional, experiment_names, genome_choices)
	elif command == 'run_transcript_analysis':
		arguments.prepare_run_transcript_analysis(required, optional, experiment_names, genome_choices)
	elif command == 'run_fusion_analysis':
		arguments.prepare_run_fusion_analysis(required, optional, experiment_names, genome_choices)
	elif command == 'run_immune_analysis':
		arguments.prepare_run_immune_analysis(required, optional, experiment_names, genome_choices)
	elif command == 'merge_bam':
		arguments.prepare_merge_bam(required, optional)

	return True

# Run commands
def run_command(command: str, input_args, config_dir: str, default_configs: Dict[str, List[str]], first_log: str, experiment_dict: Dict[str, Experiment]) -> bool:

	experiment = None

	if command in ['demux', 'analyze', 'run_transcript_analysis', 'run_fusion_analysis', 'run_immune_analysis']:

		experiment = experiment_dict.get(input_args.type_exp, None)
		if experiment == None:
			print('Error: Incorrect experiment type', file=sys.stderr)
			return False

		experiment.initialize(config_dir)

	if command == 'demux' and not experiment is None:
		return demuxer.run(input_args, experiment, first_log, os.path.join(config_dir, '..'))
	elif command == 'analyze' and not experiment is None:
		return analyzer.run(input_args, experiment, config_dir, default_configs, first_log)
	elif command == 'add_genome':
		return add_genome.run(input_args, default_configs)
	elif command == 'run_transcript_analysis' and not experiment is None:
		return run_transcript_analysis.run(input_args, experiment, config_dir, default_configs, first_log)
	elif command == 'run_fusion_analysis' and not experiment is None:
		return run_fusion_analysis.run(input_args, experiment, config_dir, default_configs, first_log)
	elif command == 'merge_bam':
		return merge_bam.run(input_args, default_configs, first_log)
	elif command == 'run_immune_analysis' and not experiment is None:
		return run_immune_analysis.run(input_args, experiment, config_dir, default_configs, first_log)
	else:
		return False

def initialize_experiments(experiment_def: Dict[str, str]) -> Union[Dict[str, Experiment], None]:

	classes = {}
	for class_name, module_name in experiment_def.items():
		module_path = f'common.experiment.{module_name}'
		spec = importlib.util.find_spec(module_path)
		if not spec is None:
			module = importlib.import_module(module_path)

			try:
				c = getattr(module, class_name)
				class_instance = c()
				classes[class_instance.name] = class_instance
			except AttributeError as e:
				print(f'Cannot load experiment class for {class_name}', file=sys.stderr)
				return None
		else:
			print(f'Cannot find module for {module_name}', file=sys.stderr)
			return None

	return classes

# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Main
if __name__ == '__main__':

	# Initialize Logger and output starting information
	first_log = 'Started script execution: %s version %s' % (SCRIPT_NAME, get_version())

	config_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../config')
	config = Config((os.path.realpath(__file__)), config_dir)

	default_configs = config.load_config()
	if default_configs is None:
		sys.exit(1)

	# -----
	# Initialize all experiment type classes
	experiment_dict = initialize_experiments(config.get_experiments())
	if experiment_dict is None:
		sys.exit(1)

	# -----
	# Preapre arguments, parsers
	parser = argparse.ArgumentParser(description=DESCRIPTION, usage=SCRIPT_NAME)
	arguments.prepare_cogent(parser)

	# sub parsers (sub commands)
	sub_parsers = parser.add_subparsers(title='commands', dest='sub_command')
	for cmd, cmd_help in SUB_COMMANDS.items():
		sub_parser = sub_parsers.add_parser(cmd, help=cmd_help[0], description=cmd_help[1], formatter_class=argparse.RawDescriptionHelpFormatter)
		optional = sub_parser._action_groups.pop() 							# change order of groups
		required = sub_parser.add_argument_group('required arguments')		# add required first
		sub_parser._action_groups.append(optional)							# re-set optional again
		if not prepare_arguments(cmd, required, optional, default_configs, list(experiment_dict.keys())):
			sys.exit(1)

	# Parse arguments
	input_args = parser.parse_args()					# parse
	if input_args.show_version:
		print_versions()
		sys.exit(0)

	if input_args.sub_command is None:					# If no command comes
		parser.print_help()
		sys.exit(0)

	# Run according to command
	start_time = datetime.now()
	res = run_command(input_args.sub_command, input_args, config_dir, default_configs, first_log, experiment_dict)

	# Suppose Logger is initialized inside
	if res:
		if Logger.initialized():
			Logger.info_logger("Successfully completed script execution.")
			Logger.info_logger("Total elapsed time: " + elapsed_time(start_time))
		sys.exit(0)
	else:
		if Logger.initialized():
			Logger.error_both("Pipeline finished with error.")
		sys.exit(1)

# endregion
# -----------------------------------------------------------------------------