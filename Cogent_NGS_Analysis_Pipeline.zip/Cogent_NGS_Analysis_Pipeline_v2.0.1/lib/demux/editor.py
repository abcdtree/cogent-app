import gzip
from common.cogent_error import CogentError

class NormalEditor:
	def __init__(self, outfile, mode = "ab", hpc_mode: bool = False):
		self._i = 0
		self._data = dict()
		self._outfile = outfile
		self._mode = mode

		self.__hpc_mode = hpc_mode
		self.__out_file_stream = None
		if hpc_mode:
			self.__out_file_stream = open(self._outfile, mode='wb')

	def write(self, data, chunk):
		if len(data) == 0:
			self._data[chunk] = None
		else:
			self._data[chunk] = data

		if self.__hpc_mode:														# Use keep opened file stream
			if self.__out_file_stream is None:
				raise CogentError('File stream is not opened for hpc mode.')

			while self._i in self._data:
				if not self._data[self._i] is None:
					self.__out_file_stream.write(self._data[self._i])
				del self._data[self._i]
				self._i += 1
		else:
			while self._i in self._data:
				with open(self._outfile, mode = self._mode) as o:
					if not self._data[self._i] is None:
						o.write(self._data[self._i])
					del self._data[self._i]
					self._i += 1

	def close(self):
		if self.__out_file_stream is not None:
			self.__out_file_stream.close()
			self.__out_file_stream = None

	def done(self):
		return not self._data

class GzipEditor:
	def __init__(self, outfile, mode = "ab", hpc_mode: bool = False, compression_level = 4):
		self._i = 0
		self._data = dict()
		self._outfile = outfile
		self._mode = mode

		self.__compression_level = compression_level
		self.__hpc_mode = hpc_mode
		self.__out_file_stream = None
		if hpc_mode:
			self.__out_file_stream = gzip.open(self._outfile, mode='wb', compresslevel=compression_level)

	def write(self, data, chunk):
		if len(data) == 0:
			self._data[chunk] = None
		else:
			self._data[chunk] = data

		if self.__hpc_mode:														# Use keep opened file stream
			if self.__out_file_stream is None:
				raise CogentError('File stream is not opened for hpc mode.')

			while self._i in self._data:
				if not self._data[self._i] is None:
					self.__out_file_stream.write(self._data[self._i])
				del self._data[self._i]
				self._i += 1
		else:																	# Open each time
			with gzip.open(self._outfile, mode=self._mode, compresslevel=self.__compression_level) as o:
				while self._i in self._data:
					if not self._data[self._i] is None:
						o.write(self._data[self._i])
					del self._data[self._i]
					self._i += 1

	def close(self):
		if self.__out_file_stream is not None:
			self.__out_file_stream.close()
			self.__out_file_stream = None

	def done(self):
		return not self._data