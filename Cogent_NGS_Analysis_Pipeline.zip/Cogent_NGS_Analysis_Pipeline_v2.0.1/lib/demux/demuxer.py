#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script of demux sub-command.
#
# Script to de-multiplex barcoded reads from sequence data stored in FASTQ files. User options are
# designed to simplify de-multiplexing for experiments derived from Takara protocols. Barcode
# (and optionally UMI) sequences are extracted and stored in the read name. Users may specify whether the
# resulting de-multiplexed data are merged, or split into individual barcode-level files.
#

# -----------------------------------------------------------------------------
# region: Script Info

SCRIPT_NAME = "demuxer"
REPO_NAME = "CogentAP"
MAIN_DESC = """
		De-multiplex barcoded reads from sequence data stored in FASTQ files.
	"""

# Do not put indent, because it effects for output.
SUB_DESC = """
descripton:
  Script to de-multiplex barcoded reads from sequence data stored in FASTQ files. User options are
  designed to simplify de-multiplexing for experiments derived from Takara protocols. Barcode
  (and optionally UMI) sequences are extracted and stored in the read name. Users may specify whether the
  resulting de-multiplexed data are merged, or split into individual barcode-level files.
"""

# endregion
# -----------------------------------------------------------------------------

# ---------- import modules ---------- #

from datetime import datetime
from multiprocessing.connection import Connection
from os import path, unlink
import sys
import os
import re
import io
import csv
import multiprocessing
from multiprocessing import Manager, Pool, Process, Pipe, Queue
import traceback
from collections import deque
import subprocess
import itertools
import shutil
from typing import Any, Dict, List, Tuple, Union, cast
import dnaio
from xopen import xopen
import resource
from common.cogent_error import CogentError
from common.experiment.experiment import Experiment
from common.util.const import ReadMode

from common.logger import Logger
from demux.barcode_reader import BarcodeFileType, BarcodeReader
from demux.editor import GzipEditor, NormalEditor

from pprint import pprint


# ---------- fxn | load background barcodes ---------- #

def load_bg(bcs, idx, experiment: Experiment, repo_path: str, user_background_file: str):
	try:
		hh1 = None
		hh2 = None
		bc_map = None
		idx_map = None

		if user_background_file is None:
			bc_map, hh1, hh2, idx_map = experiment.get_background_info(repo_path, bcs, idx)
		else:
			Logger.info_logger('Use user input backgournd barcodes file.')
			barcode_reader = BarcodeReader(user_background_file)
			barcode_reader.read()
			bc_map = barcode_reader.barcode_list
			idx_map = barcode_reader.separator_pos

		c = list(set([x in bc_map for x in bcs]))
		if len(c) == 1 and c[0] is True:
			Logger.info_logger("Loaded chip barcode map file.")
			if hh1 is None:
				Logger.info_logger("Generating hamming distance maps denovo.")
				hh1, hh2 = ham_denovo(bc_map = bc_map, idx = idx)
			else:
				Logger.info_logger("Loading hamming distance maps from source.")
				hh1 = ham_hash(ham_map = hh1)
				hh2 = ham_hash(ham_map = hh2)

		if any(x is False for x in c):
			Logger.info_logger("All barcodes not found in background. Background set to selected barcode list, computing hamming distance maps denovo.")
			bc_map = bcs
			idx_map = idx
			hh1, hh2 = ham_denovo(bc_map = bc_map, idx = idx)

		check_bcs(bcs, idx, bc_map, idx_map)

		return bc_map, idx, hh1, hh2
	except EnvironmentError as err:
		raise CogentError("Unable to open barcode map file \n" + str(err), 'load_bg')

# ---------- fxn | check I5/I7 for reverse compliment ---------- #

def check_rc(bcs, experiment: Experiment, r1_file, umi_len, idx, depth, i5_rc = 'Auto', i7_rc = 'Auto'):
	if experiment.check_revcomp:
		Logger.info_logger('Start checking I5/I7 for reverse compliment')

		rc_count = [0, 0, 0, 0, 0]
		bc_len = len(bcs[0])
		with dnaio.open(r1_file, mode = 'r') as f1:
			for r1 in f1:	# type: ignore
				if sum(rc_count) > depth * 2:
					break
				bc, umi = get_bc(r1, experiment, bc_len, umi_len, hh1 = None, hh2 = None, idx = idx, bcs_chip = bcs,
								mismatch = 0)
				if bc in bcs:
					rc_count[0] += 1
				else:
					bc1, umi1 = get_bc(r1, experiment, bc_len, umi_len, hh1 = None, hh2 = None, idx = idx, bcs_chip = bcs,
									mismatch = 0, rev1 = True)
					bc2, umi2 = get_bc(r1, experiment, bc_len, umi_len, hh1 = None, hh2 = None, idx = idx, bcs_chip = bcs,
									mismatch = 0, rev2 = True)
					if bc1 in bcs:
						rc_count[1] += 1
					else:
						rc_count[2] += 1
					if bc2 in bcs:
						rc_count[3] += 1
					else:
						rc_count[4] += 1

		for i in range(1, 4, 2):
			if rc_count[i] / sum(rc_count[0:1] + rc_count[i:i + 2]) > 0.5:
				rc_count[i] = True
			else:
				rc_count[i] = False

		if rc_count[1] is True and i5_rc == 'Auto':
			Logger.info_logger("Evidence of reverse compliment for I5 Index. Sequences reversed.")
		elif i5_rc != 'Auto':
			Logger.info_logger("Reverse complment status for I5 Index manually set to: " + i5_rc)
			rc_count[1] = strbool(i5_rc)

		if rc_count[3] is True and i7_rc == 'Auto':
			Logger.info_logger("Evidence of reverse compliment for I7 Index. Sequences reversed.")
		elif i7_rc != 'Auto':
			Logger.info_logger("Reverse complment status for I7 Index manually set to: " + i7_rc)
			rc_count[3] = strbool(i7_rc)

		return rc_count[1], rc_count[3]
	else:
		return False, False


# ---------- fxn | check selected barcode length matches background barcodes ---------- #

def check_bcs(bcs, idx, bcs_chip, idx_chip):
	if int(idx_chip) >= 0:
		l1 = str(len(bcs[0][0:idx]))
		l2 = str(len(bcs[0][idx:]))
		l1_chip = str(len(bcs_chip[0][0:idx_chip]))
		l2_chip = str(len(bcs_chip[0][idx_chip:]))
		if not l1 == l1_chip or not l2 == l2_chip:
			raise CogentError("Incorrect length of selected barcodes. Expected length: " + l1_chip + " (barcode 1) & " + l2_chip + " (barcode 2)", 'check_bcs')
	elif int(idx_chip) == -1:
		if not idx == idx_chip or not len(bcs[0]) == len(bcs_chip[0]):
			raise CogentError("Length of input barcodes incorrect. Expected barcode length: " + str(len(bcs_chip[0])), 'check_bcs')


# ---------- fxns | set read buffer ---------- #

def set_read_buffer(gb):
	b = int(gb * 1073741824)
	return b


# ---------- fxns | set connections ---------- #

def set_connections(n_workers, n_writers):
	con = dict()
	con["reader_A"] = []
	con["reader_B"] = []
	con["writer_A"] = []
	con["writer_B"] = []
	for _ in range(n_workers):
		b, a = Pipe(duplex = False)
		con["reader_A"].append(a)
		con["reader_B"].append(b)
		out_a = []
		out_b = []
		for _ in range(n_writers):
			b, a = Pipe(duplex = False)
			out_a.append(a)
			out_b.append(b)
		con["writer_A"].append(out_a)
		con["writer_B"].append(out_b)
	return con


# ---------- fxn | set outfiles ---------- #

def set_outfiles(split_fastq, bcs, sh, r1_keep, und_fq, out_dir, out_prefix, gzip: bool):
	outfiles = []
	if split_fastq is True:
		for i in range(len(bcs)):
			if r1_keep is True:
				outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "R1.fastq", bc = bcs[i], sh = sh, gzip = gzip))
			outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "R2.fastq", bc = bcs[i], sh = sh, gzip = gzip))
	else:
		if r1_keep is True:
			outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "demuxed_R1.fastq", gzip = gzip))
		outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "demuxed_R2.fastq", gzip = gzip))
	if und_fq is True:
		outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "undetermined_R1.fastq", gzip = gzip))
		outfiles.append(fq_bcf(out_dir = out_dir, out_prefix = out_prefix, ext = "undetermined_R2.fastq", gzip = gzip))
	return outfiles


# ---------- fxn | demux main ---------- #

def demux_main(r1_file, r2_file, bcs, bcs_chip, experiment: Experiment, mismatch, split_fastq, umi_len, und_fq, sh, hh1, hh2,
				idx, rev1, rev2, read_buffer, out_dir, out_prefix, n_workers, n_writers, r1_keep, gzip: bool, prog, debug, hpc_mode: bool):

	# set outfiles
	outfiles = set_outfiles(split_fastq, bcs, sh, r1_keep, und_fq, out_dir, out_prefix, gzip)

	# set work queue
	work_queue = Queue()

	# set connections
	con = set_connections(n_workers, n_writers)

	# start reader
	reader = launch_reader(r1_file, r2_file, con, work_queue, read_buffer)

	# start workers
	workers = launch_workers(work_queue, n_workers, con, bcs, bcs_chip, experiment, mismatch, split_fastq, umi_len,
							hh1, hh2, idx, rev1, rev2, r1_keep, und_fq, debug)

	# start writers
	writers, return_dict = launch_writers(outfiles, con, n_writers, bcs, sh, out_dir, out_prefix, prog, debug, gzip, hpc_mode)

	# wait for processes to finish
	reader.join()

	for worker in workers:
		worker.join()

	for writer in writers:
		writer.join()

	for key, success in return_dict.items():
		if success == False:
			raise CogentError('Failed in subprocess', f'demux_main:{key}')


	# FIXME: Confirm if this strategy is OK. But should be changed to not generating unnecessary files
	# Remove Unnecessary files
	if experiment.read_mode != ReadMode.PAIRED:
		r = None
		if experiment.read_mode == ReadMode.READ1:					# Delete Read2 files
			r = re.compile(f'.+_R2\\.fastq.*')						# Catch both with/without .gz
		elif experiment.read_mode == ReadMode.READ2:				# Delete Read1 files
			r = re.compile(f'.+_R1\\.fastq.*')						# Catch both with/without .gz

		target_list = list(filter(r.match, outfiles))				# type: ignore
		for f in target_list:
			if path.isfile(f):
				unlink(f)
			outfiles.remove(f)

	return outfiles


# ---------- fxns | writer functions ---------- #

#
# launch_workers | initiate a worker process(es)
# writer_sub | signal open for data to work_queue | recv chunk index and data | run demux sub | stream to writers
#

def launch_workers(work_queue, n, con, bcs, bcs_chip, experiment: Experiment, mismatch, split_fastq, umi_len, hh1, hh2, idx,
					rev1, rev2, r1_keep, und_fq, debug):
	workers = []
	for i in range(n):
		worker = Process(target = worker_sub,
						args = (i, work_queue, con, bcs, bcs_chip, experiment, mismatch, split_fastq, umi_len,
								hh1, hh2, idx, rev1, rev2, r1_keep, und_fq, debug))
		worker.daemon = True
		worker.start()
		workers.append(worker)
	return workers


def worker_sub(pid, work_queue, con, bcs, bcs_chip, experiment: Experiment, mismatch, split_fastq, umi_len, hh1, hh2, idx, rev1, rev2,
				r1_keep, und_fq, debug = False):
	try:
		while True:
			work_queue.put(pid)
			chunk_index = con["reader_B"][pid].recv()
			if chunk_index == -1:
				for c in con["writer_A"][pid]:
					c.send(-1)
				break
			elif chunk_index == -2:
				e, tb_str = con["reader_B"][pid].recv()
				Logger.error_logger('%s' % (tb_str))
				raise e
			if debug is True:
				if chunk_index % 100 == 0:
					Logger.info_logger("Worker " + str(pid) + ": " + str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
			data1 = con["reader_B"][pid].recv_bytes()
			data2 = con["reader_B"][pid].recv_bytes()
			r1s, r2s, u1s, u2s, bc_cts = demux_sub(bcs, bcs_chip, data1, data2, experiment, mismatch, split_fastq,
													umi_len, r1_keep, und_fq, hh1, hh2, idx, rev1, rev2)
			for c in con["writer_A"][pid]:
				c.send(chunk_index)
			outdata = deque()
			if split_fastq is True:
				for i in range(len(bcs)):
					if r1_keep is True:
						outdata.append(r1s[i])
					outdata.append(r2s[i])
			else:
				if r1_keep is True:
					outdata.append(r1s[0])
				outdata.append(r2s[0])
			if und_fq is True:
				outdata.append(u1s)
				outdata.append(u2s)
			outdata = deque_chunk(outdata, len(con["writer_A"][pid]))
			for i, data in enumerate(outdata):
				c = con["writer_A"][pid][i]
				if i == 0:
					c.send(bc_cts)
				for record in data:
					c.send_bytes(record)
	except Exception as e:
		print("Exception has occured is worker " + str(pid), flush = True)
		for c in con["writer_A"][pid]:
			c.send(-2)
			c.send((e, traceback.format_exc()))


# ---------- fxns | writer functions ---------- #

#
# launch_writers | initiate a writer process(es) | return writer_pool
# writer_sub | wait for data from workers | when recieved send to editors to be written to file | editors save order
#   of input and save reads accordingly.
#

def launch_writers(outfiles, con, writer_count, bcs, sh, out_dir, out_prefix, prog, debug, gzip: bool, hpc_mode: bool):
	writers = []
	for outfile in outfiles:
		if gzip:
			writers.append(GzipEditor(outfile, hpc_mode=hpc_mode))
		else:
			writers.append(NormalEditor(outfile, hpc_mode=hpc_mode))

	writers = list_chunk(writers, writer_count)
	writer_pool = []

	manager = Manager()
	return_dict = manager.dict()
	for i in range(writer_count):
		connections = [x[i] for x in con["writer_B"]]
		writer = Process(target = writer_sub, args = (i, writers[i], connections, bcs, sh, out_dir, out_prefix, return_dict, prog, debug))
		writer.daemon = True
		writer.start()
		writer_pool.append(writer)

	return writer_pool, return_dict


def writer_sub(pid, writers, connections, bcs, sh, out_dir, out_prefix, return_dict, prog_inc = 10000000, debug = False):

	# Initialize values
	bc_sum_cts = []
	prog = prog_inc
	ct = 0

	success = True

	if pid == 0:
		bc_sum_cts = [0] * (len(bcs) + 3)

	while connections:
		open_connections = cast(List[Connection], multiprocessing.connection.wait(connections))	# type: ignore
		for c in open_connections:
			chunk_index = c.recv()
			if chunk_index == -1:
				connections.remove(c)
				continue
			elif chunk_index == -2:
				e, tb_str = c.recv()
				Logger.error_logger('%s' % (tb_str))
				raise e
			if debug is True:
				if chunk_index % 100 == 0:
					Logger.info_logger("Writer " + str(pid) + ": " + str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))
			if pid == 0:
				bc_cts = c.recv()
				if sum(bc_cts) > 0:
					bc_sum_cts = [sum(x) for x in zip(bc_sum_cts, bc_cts)]
				ct = sum(bc_sum_cts)
				if ct > prog:
					prog += prog_inc
					Logger.info_logger(" ".join(["Processed", str(ct), "reads."]))
			for writer in writers:
				data = c.recv_bytes()
				writer.write(data, chunk_index)

	for writer in writers:
		writer.close()
		if writer.done() is False:
			Logger.error_both("Incomplete writing to file. Please contact technical support.")
			success = False

	if pid == 0:
		Logger.info_logger(" ".join(["Total | Processed", str(ct), "reads."]))
		write_bc_cts(bc_sum_cts, bcs, sh, out_dir, out_prefix)

	return_dict[f'Process-{str(pid)}'] = success


# ---------- fxns | reader functions ---------- #

#
# launch_reader | initiate a single reader process
# demux_reader | read through input files and send to available workers | send kill signal to all workers after data
#   is exhausted.
#

def launch_reader(r1_file, r2_file, con, work_queue, read_buffer):
	reader = Process(target = demux_reader, args = (r1_file, r2_file, con, work_queue, read_buffer))
	reader.daemon = True
	reader.start()
	return reader

def demux_reader(r1_file, r2_file, con, work_queue, read_buffer):
	try:
		with xopen(r1_file, "rb") as r1:
			with xopen(r2_file, "rb") as r2:
				for i, (c1, c2) in enumerate(dnaio.read_paired_chunks(r1, r2, read_buffer)):
					pid = work_queue.get()
					c = con["reader_A"][pid]
					c.send(i)
					c.send_bytes(c1)
					c.send_bytes(c2)
		for _ in range(len(con["reader_A"])):
			pid = work_queue.get()
			con["reader_A"][pid].send(-1)
		Logger.info_logger("Reader finished processing FASTQ file(s).")
	except Exception as e:
		for pid in range(len(con["reader_A"])):
			con["reader_A"][pid].send(-2)
			con["reader_A"][pid].send((e, traceback.format_exc()))


# ---------- fxns | convert fq read(s) to bytes ---------- #

def read_converter(record):
	s = ('@' + record.name + '\n' + record.sequence + '\n+' + '\n' + record.qualities + '\n').encode('ascii')
	return s

def multiread_converter(records):
	out = bytearray()
	for record in records:
		s = ('@' + record.name + '\n' + record.sequence + '\n+' + '\n' + record.qualities + '\n').encode('ascii')
		out += s
	return out


# ---------- fxn | demux subroutine ---------- #

def demux_sub(bcs, bcs_chip, r1_inp, r2_inp, experiment: Experiment, mismatch, split_fastq, umi_len, r1_keep, und_fq,
			  hh1 = None, hh2 = None, idx = -1, rev1 = False, rev2 = False):
	bc_len  = len(bcs[0])
	r1s = deque(bytearray() for _ in bcs)
	r2s = deque(bytearray() for _ in bcs)
	u1s = bytearray()
	u2s = bytearray()
	bc_cts = [0] * (len(bcs) + 3)

	with dnaio.open(io.BytesIO(r1_inp), mode = 'r') as f1, dnaio.open(io.BytesIO(r2_inp), mode = 'r') as f2:
		for r1, r2 in zip(f1, f2):	# type: ignore
			bc = None
			umi = None
			if experiment.use_read2_for_demux:
				bc, umi = get_bc(r2, experiment, bc_len, umi_len, hh1, hh2, idx, bcs_chip, mismatch, rev1, rev2)
			else:
				bc, umi = get_bc(r1, experiment, bc_len, umi_len, hh1, hh2, idx, bcs_chip, mismatch, rev1, rev2)

			if bc in bcs:
				pos = bcs.index(bc)
				bc_cts[pos] += 1
				experiment.process_read_on_demux(r1, r2, bc, bc_len, umi)
				if split_fastq is True:
					l = bcs.index(bc)
					if r1_keep is True:
						r1s[l].extend(read_converter(r1))
					r2s[l].extend(read_converter(r2))
				else:
					if r1_keep is True:
						r1s[0].extend(read_converter(r1))
					r2s[0].extend(read_converter(r2))
			elif bc in bcs_chip:
				bc_cts[len(bcs) + 1] += 1
				if und_fq is True:
					u1s.extend(read_converter(r1))
					u2s.extend(read_converter(r2))
			elif bc == 'short':
				bc_cts[len(bcs)] += 1
			else:
				bc_cts[len(bcs) + 2] += 1
				if und_fq is True:
					u1s.extend(read_converter(r1))
					u2s.extend(read_converter(r2))
	return r1s, r2s, u1s, u2s, bc_cts


# ---------- fxn | extract barcode/umi from read ---------- #

def get_bc(read, experiment: Experiment, bc_len, umi_len, hh1, hh2, idx, bcs_chip, mismatch, rev1 = False, rev2 = False):
	# strip umi & bc sequence
	bc, umi = experiment.get_barcode(read, bc_len, umi_len)

	# reverse compliment if neccessary
	if bc != 'short':
		if rev1 is True:
			if experiment.dual_index_barcode:
				bc = bc[0:idx] + rev_bc(bc[idx:])
			else:
				bc = rev_bc(bc)
		if rev2 is True:
			if experiment.dual_index_barcode:
				bc = rev_bc(bc[0:idx]) + bc[idx:]
			else:
				bc = rev_bc(bc)

	# check if exists | turn bcs_chip to hash for performance?
	if mismatch == 0 or bc in bcs_chip or bc == 'short':
		pass
	else:
		if experiment.dual_index_barcode:
			h1 = ham_check(hh1, bc[0:idx])
			if len(h1) > 0:
				h2 = ham_check(hh2, bc[idx:])
				if len(h2) > 0:
					bc = h1 + h2
		else:
			h1 = ham_check(hh1, bc)
			if (len(h1) > 0):
				bc = h1

	return bc, umi


# ---------- fxns | handle barcode mismatch | generate hash of bcs with hamming distance <= 1 ---------- #

def ham_denovo(bc_map, idx):
	if idx > 0:
		hh1 = ham_hash(bc_list = list(set([x[0:idx] for x in bc_map])))
		hh2 = ham_hash(bc_list = list(set([x[idx:] for x in bc_map])))
	else:
		hh1 = ham_hash(bc_list = bc_map)
		hh2 = None
	return(hh1, hh2)

def ham_substr(txt, idx = 0, rep = ''):
	return '%s%s%s' % (txt[:idx], rep, txt[idx + 1:])

def rev_bc(bc, rbc = '', rc = None):
	if rc is None:
		rc = {"A": "T", "T": "A", "C": "G", "G": "C", "N": "N"}
	for i in reversed(range(0, len(bc))):
		rbc = rbc + rc[bc[i]]
	return rbc

def ham_check(hh, bc):
	try:
		return hh[bc]
	except KeyError:
		return ""

def ham_hash(bc_list = None, ham_map = None, nuc = None, rev = False, idx = 0):
	if ham_map == None and bc_list == None:
		return None
	if nuc is None:
		nuc = ["A", "C", "T", "G", "N"]
	hh = {}
	if ham_map == None:
		drop = []
		if rev is True:
			bc_list = [x[0:idx] + rev_bc(x[idx:]) for x in bc_list]
		for bc in bc_list:
			for i in range(0, len(bc)):
				for n in nuc:
					p = ham_substr(bc, i, n)
					if p in hh:
						drop.append(p)
					else:
						hh[p] = bc
		drop = list(set(drop))
		for p in drop:
			if p in hh and p not in bc_list:
				del hh[p]
	else:
		with open(ham_map) as f:
			for line in f:
				(p, bc) = re.split(r',+', line.rstrip(',\n'))
				if rev is True:
					p = p[0:idx] + rev_bc(p[idx:])
					bc = bc[0:idx] + rev_bc(bc[idx:])
				hh[p] = bc
	return hh

def ham_calc_dist(bc1, bc2):
	if not len(bc1) == len(bc2):
		return len(bc1)
	else:
		return sum(b1 != b2 for b1, b2 in zip(bc1, bc2))

# ---------- fxn | generate fastq barcode file name ---------- #

def fq_bcf(out_dir, out_prefix, gzip: bool, ext, r = None, bc = None, sh = None, n = None, ):
	if gzip is True:
		ext += ".gz"

	if r is None and bc is None:
		bcf = os.path.join(out_dir, "_".join([out_prefix, ext]))
	else:
		if not r is None and bc is None:
			bc = r.split('_')[1].split(" ")[0]
		bc_fq = bc
		if not sh is None:
			s = sh[bc]
			if not s == "":
				bc_fq = "_".join([bc, s])
		if not n is None:
			bc_fq = "_".join([bc_fq, str(n)])
		bcf = os.path.join(out_dir, "_".join([out_prefix, bc_fq, ext]))
	return bcf


# ---------- fxn | write barcode counts file ---------- #

def write_bc_cts(bc_sum_cts, bcs, sh, out_dir, out_prefix):
	with open(os.path.join(out_dir, out_prefix + "_" + "counts_all.csv"), 'w', newline = '') as f:
		w = csv.writer(f, delimiter = ',')
		for i in range(len(bcs)):
			w.writerow([str(bcs[i]), str(sh[bcs[i]]), str(bc_sum_cts[i])])
		w.writerow(["Short", "Non_sample", str(bc_sum_cts[len(bcs)])])
		w.writerow(["Unselected", "Non_sample", str(bc_sum_cts[len(bcs) + 1])])
		w.writerow(["Undetermined", "Non_sample", str(bc_sum_cts[len(bcs) + 2])])


# ---------- fxn | chunk hash into splits for parallel processing ---------- #

def hash_chunk(h, n):
	s = [int(len(h) / n)] * n
	idx = [s[i] + 1 if i < len(h) % n else s[i] for i in range(len(s))]
	out = []
	c = 0
	for i in idx:
		split = {k: h[k] for k in list(h)[c:c + i]}
		c = c + i
		out.append(split)
	return out

def list_chunk(l, n):
	s = [int(len(l) / n)] * n
	idx = [s[i] + 1 if i < len(l) % n else s[i] for i in range(len(s))]
	out = []
	c = 0
	for i in idx:
		split = [k for k in l[c:c + i]]
		c = c + i
		out.append(split)
	return out

def deque_chunk(l, n):
	s = [int(len(l) / n)] * n
	idx = [s[i] + 1 if i < len(l) % n else s[i] for i in range(len(s))]
	out = deque()
	c = 0
	for i in idx:
		split = deque(itertools.islice(l, c, c + i))
		c = c + i
		out.append(split)
	return out


# ---------- fxn | string to boolean ---------- #

def strbool(s):
	if s.lower() in ["true", "t"]:
		return True
	elif s.lower() in ["false", "f"]:
		return False
	else:
		return s


# ---------- fxn | compression ---------- #
def pigz(outfiles, n, compression_level, pigz: str) -> bool:
	for f in outfiles:
		command = [
			pigz,
			"-" + str(compression_level),
			"-p", str(n),
			str(f)
		]
		c = subprocess.run(command)
		if c.returncode != 0:
			Logger.error_both("Issue compressing output FASTQ files.")
			return False

	return True

def pigz_multi(outfiles: List[str], n_process: int, compression_level: int, pigz: str, pigz_n_cores: int) -> bool:

	num_pool = n_process // pigz_n_cores	# Calculate pool number
	pool = Pool(processes=num_pool)			# Create a pool

	Logger.info_logger(f'Compression level = {compression_level}')
	Logger.info_logger(f'Number of pools = {num_pool}. Cores for each process = {pigz_n_cores}')

	manager = Manager()
	res_list = manager.list()

	for file in outfiles:
		pool.apply_async(pigz_sub, args=(file, pigz_n_cores, compression_level, pigz, res_list))

	pool.close()
	pool.join()

	if any([x != 0 for x in res_list]):										# When error in any process
		Logger.error_both("Issue compressing output FASTQ files.")
		return False

	return True

def pigz_sub(file: str, n_cores: int, compression_level: int, pigz: str, res_list: List[int]):
	res = subprocess.run([pigz, '-' + str(compression_level), '-p', str(n_cores), file])
	res_list.append(res.returncode)


# ---------- fxn | check if file exists ---------- #
def check_file(f, exp) -> bool:
	if os.path.isfile(f) is False:
		Logger.error_both(f + " " + exp)
		return False
	else:
		return True

# ---------- fxn | check all input requirements ---------- #
def check_requirements(user_args, barcode_reader: BarcodeReader, experiment: Experiment) -> bool:

	res = True

	if experiment.read_mode == ReadMode.PAIRED or experiment.read_mode == ReadMode.READ2:
		if user_args.r2_file is None:
			Logger.error_both(f'Read2 is necessary for the experiment type.')
			return False
	elif experiment.read_mode == ReadMode.READ1:
		if user_args.r2_file is None:
			user_args.r2_file = user_args.r1_file			# Re-use r1 file as r2
		else:
			Logger.warning_logger(f'R2 file is specified for "{experiment.name}", but it will be ignored.')
	else:
		Logger.error_both(f'Unrecognized read mode.')
		return False

	# Check if files exist
	for f in [user_args.r1_file, user_args.r2_file, user_args.bcs_file]:
		res = check_file(f, "does not exist!") and res

	# Check if backgournd file exist
	if not user_args.background_barcodes_file is None:
		res = check_file(user_args.background_barcodes_file, "does not exist!") and res

	if not res:
		return False

	if barcode_reader.judge_file_type(suppress_warning=True) is BarcodeFileType.NOT_DETECTED:
		Logger.error_both(f'Unrecognized barcode file format')
		res = False

	return res

def check_pigz_install(user_args, repository_path: str) -> Union[str, None]:

	pigz_locs = [
		user_args.pigz_loc,
		os.path.join(repository_path, '_'.join([REPO_NAME, 'tools']), 'bin', 'pigz'),
		str(shutil.which('pigz'))
	]

	# Check if pigz is installed
	pigz_loc = None
	for pl in pigz_locs:
		if os.path.isfile(pl) is True:
			pigz_loc = pl
			break

	if pigz_loc is None:
		Logger.error_both("Can't find pigz executable.")

	return pigz_loc

# -----------------------------------------------------------------------------
# region: Main Function
def run(user_args, experiment: Experiment, first_log: str, repo_path: str) -> bool:

	# ---------- setup | output directory ---------- #
	if os.path.isdir(user_args.out_dir):
		print(f'Error: Analysis dir already exists: {user_args.out_dir}', file=sys.stderr)
		return False
	else:
		try:
			os.makedirs(user_args.out_dir)
		except OSError as err:
			print(f'Error: Unable to create directory: {user_args.out_dir}', file=sys.stderr)
			return False

	if user_args.out_dir.endswith('/'):
		user_args.out_dir = user_args.out_dir.rstrip('/')

	user_args.out_prefix = os.path.split(user_args.out_dir)[1]

	# ---------- setup | logger ---------- #
	Logger.initialize(SCRIPT_NAME, path.join(user_args.out_dir, f'{user_args.out_prefix}_{SCRIPT_NAME}.log'))
	Logger.info_logger(first_log)
	Logger.info_logger('Command name: ' + SCRIPT_NAME)
	Logger.info_logger("Original call: " + " ".join(sys.argv))

	if user_args.hpc_mode:
		Logger.info_logger("Start working as HPC mode.")

	# ---------- setup | check input ---------- #
	barcode_reader = BarcodeReader(user_args.bcs_file)
	if not check_requirements(user_args, barcode_reader, experiment):
		return False

	# ---------- setup | check pigz install ---------- #
	pigz_loc = check_pigz_install(user_args, repo_path)
	if pigz_loc is None:
		return False

	# ---------- setup | read buffer ---------- #
	user_args.read_buffer = set_read_buffer(user_args.read_buffer)

	# ---------- setup | UMI length ---------- #
	effective_umi_length = experiment.umi_length
	if not user_args.umi_len is None:
		if experiment.umi_length is None:
			Logger.info_logger(f'UMI length is specified by option. But it is ignored for the experiment type: {experiment.name}')
		else:
			effective_umi_length = user_args.umi_len

	if experiment.is_use_umi:
		Logger.info_logger(f'Effective UMI length is defined as {effective_umi_length}')

	# ---------- setup | z_type ---------- #
	# Internal use only
	if user_args.z_type is None:
		pass
	else:
		user_args.type_exp = user_args.z_type
		if user_args.type_exp not in ['solo_umi', 'strnd_umi']:
			Logger.error_both("Unrecognized z_type")
			return False

	# ---------- setup | multiprocess ---------- #
	total_processes = user_args.n_processes + user_args.n_writers + 1
	if multiprocessing.cpu_count() < total_processes:
		Logger.info_logger(f"More processes ({str(total_processes)}) requested than avaialble. Reducing to ({str(multiprocessing.cpu_count() - 1)})")
		user_args.n_processes = multiprocessing.cpu_count() - user_args.n_writers - 1
	if user_args.split_fastq is False:
		if user_args.und_fq is True and user_args.n_writers > 4:
			Logger.info_logger("Based on settings only 4 writer processes required. Re-allocating extra processes to workers.")
			user_args.n_processes += user_args.n_writers - 4
			user_args.n_writers = 4
		if user_args.und_fq is False and user_args.n_writers > 2:
			Logger.info_logger("Based on settings only 2 writer processes required. Re-allocating extra processes to workers.")
			user_args.n_processes += user_args.n_writers - 2
			user_args.n_writers = 2

	Logger.info_logger(str(multiprocessing.cpu_count()) + " total cores detected | 1 (reading) | " + str(user_args.n_processes) + " (workers) | " + str(user_args.n_writers) + " (writing)")

	# -----
	# Start processing
	try:
		# ---------- load | selected barcodes ---------- #
		if not barcode_reader.read():
			return False
		# bcs, idx, sh = cast(Tuple[List[Any], Any, Dict[Any, Any]], load_bcs(user_args.bcs_file, sample_hash = True))
		Logger.info_logger("Loaded input well-list / barcodes file")

		# ---------- check | I5/I7 for reverse compliment (full-length and stranded_umi only) ---------- #
		rev1, rev2 = check_rc(bcs = barcode_reader.barcode_list,
							idx = barcode_reader.separator_pos,
							experiment = experiment,
							r1_file = user_args.r1_file,
							umi_len = effective_umi_length,
							depth = 10000,
							i5_rc = user_args.i5_rc,
							i7_rc = user_args.i7_rc)


		# ---------- load | background barcodes & hamming distance hashes ---------- #
		bcs_chip, idx_chip, hh1, hh2 = load_bg(barcode_reader.barcode_list, barcode_reader.separator_pos, experiment, repo_path, user_args.background_barcodes_file)

		# ---------- demultiplex | launch demux_sub thread(s) ---------- #
		Logger.info_logger("Start demultiplexing.")
		outfiles = demux_main(
			r1_file = user_args.r1_file,
			r2_file = user_args.r2_file,
			bcs = barcode_reader.barcode_list,
			bcs_chip = bcs_chip,
			experiment = experiment,
			mismatch = user_args.mismatch,
			split_fastq = user_args.split_fastq,
			umi_len = effective_umi_length,
			und_fq = user_args.und_fq,
			sh = barcode_reader.sample_hash,
			hh1 = hh1,
			hh2 = hh2,
			idx = barcode_reader.separator_pos,
			rev1 = rev1,
			rev2 = rev2,
			read_buffer = user_args.read_buffer,
			out_dir = user_args.out_dir,
			out_prefix = user_args.out_prefix,
			n_workers = user_args.n_processes,
			n_writers = user_args.n_writers,
			r1_keep = (experiment.read_mode == ReadMode.PAIRED or experiment.read_mode == ReadMode.READ1),
			gzip = user_args.gzip,
			prog = user_args.prog,
			debug = user_args.debug,
			hpc_mode=user_args.hpc_mode
		)
		Logger.info_logger("Successfully completed demultiplexing.")


		# # ---------- compress | output files ---------- #
		# if user_args.gzip is True:
		# 	Logger.info_logger("Start compression.")
		# 	gzip_start_time = datetime.now()
		# 	res = pigz_multi(
		# 		outfiles = outfiles,
		# 		# n = user_args.n_processes + user_args.n_writers + 1,
		# 		n_process = user_args.n_processes,
		# 		compression_level = 6,
		# 		pigz = pigz_loc,
		# 		pigz_n_cores = 2
		# 	)

		# 	if not res:
		# 		return False

		# 	Logger.info_logger("Elapsed time for compression: " + elapsed_time(gzip_start_time))

	except CogentError as e:
		if e.function is None:
			Logger.error_both(f'{e.message}')
		else:
			Logger.error_both(f'{e.message} (at {e.function})')

		return False

	return True

# endregion
# -----------------------------------------------------------------------------
