from enum import Enum
import re
from typing import Dict, List, Union

from common.cogent_error import CogentError
from common.logger import Logger

class BarcodeFileType(Enum):
	WELL_LIST = 1
	SAMPLE_SHEET = 2
	TEXT = 3
	NOT_DETECTED = 4

class BarcodeReader:

	@property
	def barcode_list(self) -> List[str]:
		return list(self.__barcode_info.keys())

	@property
	def sample_hash(self) -> Dict[str, str]:
		return self.__barcode_info

	@property
	def separator_pos(self) -> int:
		return self.__separator_pos

	def __init__(self, in_file: str) -> None:
		self.__input_file = in_file
		self.__barcode_info = {}
		self.__separator_pos = -1

	def load_bcs(self, bc_file, sample_hash = False):
		bc_list = []
		s_list = []
		ext = None
		s_pos = None
		l = []

		try:
			with open(bc_file) as f:
				header = f.readline()
				try:
					bc_pos = re.split(r'\t+', header.rstrip().rstrip('\t')).index('Barcode')
					try:
						s_pos = re.split(r'\t+', header.rstrip().rstrip('\t')).index('Sample')
					except ValueError:
						s_pos = None
					ext = "tsv"
				except ValueError:
					try:
						bc_pos = re.split(',', header.strip()).index('Barcode')
						try:
							s_pos = re.split(',', header.strip()).index('Sample')
						except ValueError:
							s_pos = None
						ext = "csv"
					except ValueError:
						raise CogentError("Unrecognized barcode file format " + bc_file, 'load_bcs')

				for line in f:
					if ext == "tsv":
						l = re.split(r'\t+', line.rstrip().rstrip('\t'))
					elif ext == "csv":
						l = re.split(',', line.strip())
					if l[bc_pos] != "":
						bc_list.append(l[bc_pos])
						if s_pos is None:
							s_list.append("Sample")
						else:
							s_list.append(re.sub(r'\W+', '', re.sub(r' |-', '_', l[s_pos])))
				bcs, idx = self.__check_idx(bc_list, "+")
				sh = {k: v for k, v in zip(bcs, s_list)}
		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + bc_file + "\n" + str(err), 'load_bcs')

		if sample_hash is True:
			return bcs, idx, sh
		else:
			return bcs, idx

	def read(self) -> bool:

		# Find file type from Well-list, Smplesheet and Other texts
		file_type = self.judge_file_type(suppress_warning=True)
		if file_type is BarcodeFileType.NOT_DETECTED:
			Logger.error_both(f'Unrecognized barcode file format: {self.__input_file}')
			return False
		elif file_type is BarcodeFileType.WELL_LIST:
			Logger.info_logger(f'Detected barcode file as Well-List: {self.__input_file}')
			return self.__load_well_list()
		elif file_type is BarcodeFileType.TEXT:
			Logger.info_logger(f'Detected barcode file as Text: {self.__input_file}')
			return self.__load_text()
		elif file_type is BarcodeFileType.SAMPLE_SHEET:
			Logger.info_logger(f"Detected barcode file as Illumina's sample sheet: {self.__input_file}")
			return self.__load_sample_sheet()
		else:
			raise CogentError(f'Unexpected error: {self.__input_file}', 'read (BarcodeReader)')


	def judge_file_type(self, suppress_warning: bool = False) -> BarcodeFileType:

		res = BarcodeFileType.NOT_DETECTED

		with open(self.__input_file, 'r') as f:
			header = f.readline().rstrip()
			sep = self.__find_separator(header, suppress_warning)

			if sep is None:
				if 'Barcode' in header:
					res = BarcodeFileType.TEXT
				elif '[Header]' in header:
					for line in f:
						if '[Data]' in line:
							res = BarcodeFileType.SAMPLE_SHEET
							break
				else:
					res = BarcodeFileType.NOT_DETECTED
			else:
				values = re.split(rf'{sep}', header)
				if 'Barcode' in values:
					if 'Row' in values and 'Col' in values and values.index('Row') == 0 and values.index('Col') == 1 and 'Sample' in values:
						res = BarcodeFileType.WELL_LIST
					else:
						res = BarcodeFileType.TEXT
				elif '[Header]' in values:
					for line in f:
						if '[Data]' in line:
							res = BarcodeFileType.SAMPLE_SHEET
							break

		return res

	# ---------------------------------
	# region: Internal functions

	def __load_well_list(self) -> bool:
		try:
			with open(self.__input_file) as f:

				# Load header
				header = f.readline().rstrip()
				sep = self.__find_separator(header, True)
				if sep is None:
					return False

				# Find target position
				values = re.split(rf'{sep}', header)
				pos_barcode = values.index('Barcode')
				pos_sample = values.index('Sample')

				barcode_list = []
				sample_name_list = []
				for line in f:
					line = line.rstrip()
					# line = line.rstrip().rstrip('\t')		# Need to do like this? Dual stripping?
					if line == '':			# Skip if empty line
						continue

					values = re.split(rf'{sep}', line)
					barcode_list.append(values[pos_barcode])
					sample_name_list.append(re.sub(r'\W+', '', re.sub(r' |-', '_', values[pos_sample])))

				# Fix dual index
				refined_barcodes, sep_pos = self.__check_idx(barcode_list, '+')

				# Store to keeping values
				self.__separator_pos = sep_pos
				self.__barcode_info = {k: v for k, v in zip(refined_barcodes, sample_name_list)}

		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + self.__input_file + "\n" + str(err), '__load_well_list()')

		return True

	def __load_text(self) -> bool:
		try:
			with open(self.__input_file) as f:

				# Load header
				header = f.readline().rstrip()
				sep = self.__find_separator(header, True)

				# Find target position
				values = []
				if sep is None:
					values = [header]
				else:
					values = re.split(rf'{sep}', header)

				pos_barcode = values.index('Barcode')
				pos_sample = -1
				if 'Sample' in values:
					pos_sample = values.index('Sample')

				barcode_list = []
				sample_name_list = []
				for line in f:
					line = line.rstrip()
					# line = line.rstrip().rstrip('\t')		# Need to do like this? Dual stripping?
					if line == '':			# Skip if empty line
						continue

					values = []
					if sep is None:
						values = [line]
					else:
						values = re.split(rf'{sep}', line)
					barcode_list.append(values[pos_barcode])

					if pos_sample == -1:
						sample_name_list.append('Sample')
					else:
						sample_name_list.append(re.sub(r'\W+', '', re.sub(r' |-', '_', values[pos_sample])))

				# Fix dual index
				refined_barcodes, sep_pos = self.__check_idx(barcode_list, '+')

				# Store to keeping values
				self.__separator_pos = sep_pos
				self.__barcode_info = {k: v for k, v in zip(refined_barcodes, sample_name_list)}

		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + self.__input_file + "\n" + str(err), '__load_well_list()')

		return True

	def __load_sample_sheet(self) -> bool:
		try:
			with open(self.__input_file) as f:

				# Skip lines to [Data] line
				for line in f:
					if line.startswith('[Data]'):
						break

				header = f.readline().rstrip()
				sep = ','							# Separator is always commma

				# Find target position
				values = re.split(rf'{sep}', header)
				pos_index1 = -1
				pos_index2 = -1
				pos_sample = -1

				if not 'index' in values:
					Logger.error_both('"index" column is required in sample sheet.')
					return False

				pos_index1 = values.index('index')
				if 'index2' in values:
					pos_index2 = values.index('index2')

				if 'Sample_Name' in values:
					pos_sample = values.index('Sample_Name')
				elif 'Sample_ID' in values:						# Try to catch Sample ID if there is not Sample_name column
					pos_sample = values.index('Sample_ID')

				barcode_list = []
				sample_name_list = []
				for line in f:
					line = line.rstrip()
					# line = line.rstrip().rstrip('\t')		# Need to do like this? Dual stripping?
					if line == '':			# Skip if empty line
						continue

					values = re.split(rf'{sep}', line)
					if pos_index2 == -1:
						barcode_list.append(values[pos_index1])
					else:
						barcode_list.append(f'{values[pos_index1]}+{values[pos_index2]}')

					if pos_sample == -1:
						sample_name_list.append('Sample')
					else:
						sample_name_list.append(re.sub(r'\W+', '', re.sub(r' |-', '_', values[pos_sample])))

				# Fix dual index
				refined_barcodes, sep_pos = self.__check_idx(barcode_list, '+')

				# Store to keeping values
				self.__separator_pos = sep_pos
				self.__barcode_info = {k: v for k, v in zip(refined_barcodes, sample_name_list)}

		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + self.__input_file + "\n" + str(err), '__load_sample_sheet()')

		return True

	def __find_separator(self, data: str, suppress_warning: bool = False) -> Union[str, None]:

		sep = None
		values = re.split(r'\t', data)		# Try to split \t
		if len(values) > 1:
			sep = '\t'
		else:
			values = re.split(',', data)
			if len(values) > 1:
				sep = ','
			else:
				if not suppress_warning:
					Logger.warning_both(f'Cannot detect separator in barcode file: {self.__input_file}')

		return sep


	# endregion: Internal functions
	# ---------------------------------

	# ---------- fxn | check barcode for dual index ('+' sign in bc) ---------- #
	def __check_idx(self, bc_list, d = "\\+"):

		if not len(bc_list) == len(list(set(bc_list))):
			raise CogentError(f"Barcodes file contains DUPLICATES: {self.__input_file}", '__check_idx()')
		else:
			idx = bc_list[0].find(d)
			if idx > 0:
				bc_list = [x.replace(d, '') for x in bc_list]

			return bc_list, idx