#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script of analyze sub-command.
#
# Script to perform immune profiing analysis for split fastq files
# This script receives output from demux command as input, then analyze according to
# specified experiment type (deems type of kit) - as of April 2021, FLA kit.
#

# -----------------------------------------------------------------------------
# region: Script Info

SCRIPT_NAME = "run_immune_analysis"
MAIN_DESC = """
		Perform immune profiling analysis by results from demux and analyze command.
	"""

# Do not put indent, because it affects for output.
SUB_DESC="""
description:
  A command for perfoming immune-profiling on split fastqs.
  The input to this script are files output by Cogent demux.
  The fastq files are expected to contain the barcode info in the read name.
  The modules currently included are:
  	-- read assembly & clonotype identification (Trust4)
"""
#   To develop:
#   	Trim off barcode & UMI & keep only transcript region as input to Trust4

# endregion
# -----------------------------------------------------------------------------

# ---------- import modules ---------- #

from os import path
from os.path import isdir, isfile
import shutil
import sys
import os
import multiprocessing
from typing import Dict, List

from common.cogent_error import CogentError
from common.config import Config

from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.immune import create_input_for_cogent_ds
from common.util.util import get_fastq_file_list
from common.util.const import  DebugMode, to_debug_mode

from common.util.demux import find_summary_file, load_summary_file

from run_immune_analysis.immune_processor import ImmuneProcessor
from run_immune_analysis.data.immune_report import ImmuneReport

from analyze.tools.cogent_ds import CogentDS


# -----------------------------------------------------------------------------
# region: Function

# Check all input requirements
def check_requirements(user_args, experiment: Experiment, genome_pref: Dict) -> bool:

	res = True

	# Check if number of threads requested is available
	Logger.info_logger(f'Detected number of CPUs: {multiprocessing.cpu_count()}')
	if multiprocessing.cpu_count() < user_args.threads_num * user_args.cores_num:
		Logger.info_logger(f'Input "threads x cores" is {user_args.threads_num * user_args.cores_num}. It exceeds installed number of CPUs.')

		if multiprocessing.cpu_count() < user_args.threads_num:
			user_args.threads_num = multiprocessing.cpu_count()

		# Check total number again
		if multiprocessing.cpu_count() < user_args.threads_num * user_args.cores_num:
			user_args.cores_num = int(multiprocessing.cpu_count() / user_args.threads_num)

		Logger.info_logger(f'Changed number of threads as {user_args.threads_num } and cores as {user_args.cores_num}.')

	# Check if input path (directory) exists
	if not isdir(user_args.input_dir):
		Logger.error_both(f'Input directory does not exist. {user_args.input_dir}')
		res = False

	# Check if input path (directory) exists
	if not isdir(user_args.analyze_dir):
		Logger.error_both(f'Analyze directory does not exist. {user_args.analyze_dir}')
		res = False

	if not experiment.is_support_immune:
		Logger.error_both('The experiment type does not support immune analysis.')
		res = False

	if not genome_pref['immune']:
		Logger.error_both('The genome does not support immune analysis.')
		res = False

	return res

def clean_work_dir(work_dir: str, key_list: List[str], debug_mode: DebugMode, cogent_ds_work_dir: str) -> bool:
	try:
		if debug_mode is DebugMode.NONE:					# Remove all files and directories
			shutil.rmtree(work_dir)
		else:
			for key in key_list:
				shutil.rmtree(path.join(work_dir, key))		# Remove only working directory per barcode

		return True
	except:
		Logger.error_both('Failed to clean working directory')
		return False

def adjust_threads(user_args, samples_num: int):
	if user_args.threads_num > samples_num:
		total_num = user_args.threads_num * user_args.cores_num
		user_args.threads_num = samples_num
		user_args.cores_num = int(total_num / user_args.threads_num)
		Logger.info_logger(f'Number of threads exceeds the number of input samples. Adjusted number of threads as {user_args.threads_num } and cores as {user_args.cores_num}.')

# endregion: Function
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# region: Main Function
def run(user_args, experiment: Experiment, config_dir: str, default_configs, first_log: str):

	# ---------- setup | parse/check user options ---------- #
	if user_args.out_dir.endswith('/'):
		user_args.out_dir = user_args.out_dir.rstrip('/')

	user_args.out_prefix = path.split(user_args.out_dir)[1]			# save child directory as prefix for output file names
	user_args.debug_mode = to_debug_mode(user_args.debug_mode)

	# ---------- setup | output directory ---------- #
	work_dir = ''
	logs_dir = ''
	if path.isdir(user_args.out_dir):
		print(f'Error: Immune analysis dir already exists: {user_args.out_dir}', file=sys.stderr)
		return False
	else:
		# Create require directories
		target_dir = None
		try:
			target_dir = user_args.out_dir
			os.makedirs(target_dir)

			work_dir = path.join(user_args.out_dir, 'work')
			target_dir = work_dir
			os.makedirs(target_dir)

			logs_dir = path.join(work_dir, 'logs')
			target_dir = logs_dir
			os.makedirs(target_dir)

			target_dir = path.join(logs_dir, 'immune') #Wenwen note
			os.mkdir(target_dir)

			# store clonotype_matrix & metadata for CogentDS
			target_dir = path.join(work_dir,'clonotype')
			os.mkdir(target_dir)

		except OSError as err:
			print(f'Unable to create directory: {target_dir}', file=sys.stderr)
			return False

	# ---------- setup | logger ---------- #
	Logger.initialize(SCRIPT_NAME, path.join(user_args.out_dir, f'{user_args.out_prefix}_{SCRIPT_NAME}.log'))
	Logger.info_logger(first_log)
	Logger.info_logger("Command name: " + SCRIPT_NAME)
	Logger.info_logger("Original call : " + " ".join(sys.argv))

	# ---------- setup | define local resources ---------- #
	# Write config to log
	tmp_conf = ""
	for k,v in default_configs.items():
		tmp_conf = tmp_conf + "  --" + str(k) + "," + ",".join([str(vl) for vl in v]) + "\n"
	Logger.info_logger("Configs loaded as: \n" + tmp_conf)

	# ---------- setup | check requirement ---------- #
	if not check_requirements(user_args, experiment, default_configs[Config.GENOME_CONFIG_KEY + user_args.genome_used][3]):
		return False

	try:
		# ---------- setup | Find counts_all.csv ---------- #
		demux_count_file = find_summary_file(user_args.input_dir)						# file path or None is OK

		# ---------- setup | Load FASTQ file paths ---------- #
		in_files = get_fastq_file_list(user_args.input_dir, experiment.read_mode)		# Check input files exist and load its path
		if in_files is None:
			return False

		# --- Load demuxed count results
		demux_summary = None
		if demux_count_file is None:
			return False
		else:
			demux_summary = load_summary_file(demux_count_file)

		# ---------- Adjust threads and cores again ---------- #
		adjust_threads(user_args, len(in_files.keys()))

		# ---------- Process ---------- #
		immuneProcessor = ImmuneProcessor(
			user_args.threads_num, user_args.cores_num, experiment, work_dir,
			logs_dir, config_dir,
			default_configs, user_args.genome_used,
			user_args.debug_mode
			)

		res = immuneProcessor.process(in_files, demux_summary)
		if not res:
			return False

		# ---------- Merge all result files ---------- #
		report = ImmuneReport(user_args.out_dir, user_args.out_prefix, experiment)
		report.create(list(in_files.keys()), immuneProcessor.results, demux_summary)

		# ---------- CogentDS | analysis / report ---------- #
		clonotype_work_dir = create_input_for_cogent_ds(work_dir, report.clonotype_matrix, report.meta_data)
		cogent_ds = CogentDS(
			work_dir, user_args.out_dir, logs_dir, experiment.norm_method.value, default_configs['rscript_loc'][0],
			user_args.analyze_dir, user_args.threads_num * user_args.cores_num, user_args.debug_mode, experiment.cogent_ds_config
			)

		res = cogent_ds.call_run_immune(clonotype_work_dir)
		if not res:
			Logger.warning_logger('An issue was detected at CogentDS part, but continue the pipeline.')

		# ---------- Remove temporary files (final) ---------- #
		if not user_args.debug_mode is DebugMode.HIGH:
			clean_work_dir(work_dir, list(in_files.keys()), user_args.debug_mode, clonotype_work_dir)

	except CogentError as e:
		if e.function is None:
			Logger.error_both(f'{e.message}')
		else:
			Logger.error_both(f'{e.message} (at {e.function})')

		return False
	finally:
		...

	return True

# #endregion
# -----------------------------------------------------------------------------