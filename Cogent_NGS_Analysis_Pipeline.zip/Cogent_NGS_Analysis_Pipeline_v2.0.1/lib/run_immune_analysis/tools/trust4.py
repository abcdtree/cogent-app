from datetime import datetime
from genericpath import isfile
import shutil
from typing import List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.util import elapsed_time, run_system_cmd
from os import path, unlink

class Trust4:

	TRUST4_ERROR_MESSAGE1 = 'Need to use -a to specify the assembly file.'
	TRUST4_ERROR_MESSAGE2 = 'Read file is empty.'
	# ---------------------------------
	# region: Property

	@property
	def clonotype_tsv_file(self) -> str:
		return self.__clonotype_tsv_file

	def COMMON_PARAMS(self) -> List[str]:
		# return [
		# 	'-m', '15',
		# 	'--trim-n',
		# 	'--max-n', '0.7',
		# 	'-q', '20'
		# 	]
		return [
		    ]

	# endregion: Property
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, trust4_path: str, cores_num: int, genome_name: str):
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__trust4_path = trust4_path
		self.__cores_num = cores_num
		self.__genome_name = genome_name
		if self.__genome_name == 'hg38':
			self.__f_fasta = path.join(path.split(self.__trust4_path)[0], 'hg38_bcrtcr.fa')
			self.__ref_fasta = path.join(path.split(self.__trust4_path)[0], 'human_IMGT+C.fa')
		elif self.__genome_name == 'mm10':
			self.__f_fasta = path.join(path.split(self.__trust4_path)[0], 'mouse','GRCm38_bcrtcr.fa')
			self.__ref_fasta = path.join(path.split(self.__trust4_path)[0], 'mouse','mouse_IMGT+C.fa')
		self.__exist_result = True

	# Run command
	def run(self, input_r1: str = None, input_r2: str = None) -> bool:
		start_time = datetime.now()
		Logger.info_logger("Started immune profiling module", self.__key)

		if input_r1 is None and input_r2 is None:
			raise CogentError('Both read1 and read2 for immune profiling are None.')

		# Setup files
		infile_list = []
		if not input_r1 is None:
			infile_list.append(input_r1)

		if not input_r2 is None:
			infile_list.append(input_r2)


		log_stdout = path.join(self.__log_dir, f'{self.__key}_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'{self.__key}_stderr.txt')

		# Common options
		command = [
			self.__trust4_path,
			'-t', str(self.__cores_num)
		]
		# command += self.COMMON_PARAMS

		# Input files
		command += [
			'-1', infile_list[0]
			]
		# print('length of infile_list is ' + str(len(infile_list)))
		if len(infile_list) > 1:
			command += [
				'-2', infile_list[1]
				]

		# reference files
		command += [
			'-f', self.__f_fasta,
			'--ref', self.__ref_fasta
			# '--skipMateExtension'
			]

		# output folder
		command += [
			'-o', self.__key,
			'--od', self.__work_dir
			]

		command_str = ' '.join(command)
		Logger.info_logger("Launched immune profiling using command: " + command_str, self.__key)

		# catch the failed barcode: check if tsv file exsit or only header in tsv file
		res = run_system_cmd(command_str, log_stdout, log_stderr, suppress_error_message = True)
		if not res:
			if self.__judge_trust4_error(log_stderr):					# Check if error is because of estimation for read length
				error_message = f'Failed to assemble reads and create clonotype tsv file. [{self.__key}]'
				Logger.warning_logger(error_message, self.__key)	# Output to console and log for this barcode
				Logger.warning_logger(error_message)				# Output to global log file
				self.__exist_result = False
			else:
				Logger.error_logger(f'Unexpected error when launching immune analysis: {command_str}')
				return False

		# Rename automatically output file .bam.featureCounts
		self.__clonotype_tsv_file = path.join(self.__work_dir, f'{self.__key}_report.tsv')

		Logger.info_logger("Successfully completed immune profiling. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def remove_temp_files(self) -> bool:
		try:
			# remove intermedia files
			# shutil.rmtree(out_path)
			# shutil.rmtree(self.__work_dir)
			if self.__exist_result:
				unlink(path.join(self.__work_dir, f'{self.__key}_annot.fa'))
				unlink(path.join(self.__work_dir, f'{self.__key}_assembled_reads.fa'))
				unlink(path.join(self.__work_dir, f'{self.__key}_cdr3.out'))
				unlink(path.join(self.__work_dir, f'{self.__key}_final.out'))
				unlink(path.join(self.__work_dir, f'{self.__key}_raw.out'))
				unlink(path.join(self.__work_dir, f'{self.__key}_report.tsv'))

			assem_file = path.join(self.__work_dir, f'{self.__key}_toassemble_1.fq')
			if isfile(assem_file):
				unlink(assem_file)
				unlink(path.join(self.__work_dir, f'{self.__key}_toassemble_2.fq'))
		except:
			Logger.error_both(f'Failed to remove temporary files of immune profiling for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_stdout.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of immune profiling for {self.__key}', self.__key)
			return False

		return True

	def __judge_trust4_error(self, error_file: str) -> bool:
		with open(error_file, 'r') as f:
			for line in f:
				if line.strip() == self.TRUST4_ERROR_MESSAGE1:
					return True
				elif line.strip() == self.TRUST4_ERROR_MESSAGE2:
					return True
		return False