from datetime import datetime
import os
import shutil
from typing import Dict, Tuple, Union
from os import path, unlink

from common.analyze.base_processor import BaseProcessor

from common.cogent_error import CogentError
from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import DebugMode
from common.util.analyze import AnalyzeStats
from common.util.demux import DemuxSummary
# from common.util.immu import ImmuneStats
from common.util.util import elapsed_time
from common.analyze.base_summarize import BaseSummarize
from run_immune_analysis.data.immune_summarize import ImmuneSummarize

class ImmuneProcessor(BaseProcessor):

	@property
	# def results(self) -> Dict[str, BaseSummarize]:
	def results(self) -> Dict[str, ImmuneSummarize]:
		return self._results

	# Initialize
	def __init__(self, threads_num: int, cores_num: int, experiment: Experiment, work_dir: str, logs_dir: str, config_dir: str,
				default_configs, genome_name: str, debug_mode: DebugMode):

		super().__init__(threads_num, cores_num, experiment, logs_dir, config_dir, default_configs, genome_name)

		self.__experiment = experiment				# Experiment type
		self.__debug_mode = debug_mode

		self.__work_dir_root = work_dir
		self.__logs_dir_root = logs_dir

		self.__species = default_configs[Config.GENOME_CONFIG_KEY + genome_name][3]['species']

	# Impl of abstract method
	def _work_per_barcode(self, pid: int, key: str, input_files: tuple, res_dict: Dict[str, BaseSummarize], demux_summary: DemuxSummary) -> bool:
		start_time = datetime.now()

		# ---------- Setup for this key ---------- #
		work_dir = path.join(self.__work_dir_root, key)
		Logger.add_logger(key, path.join(self.__logs_dir_root, f'{key}_log.txt'))
		Logger.info_logger(f'Started processing for {key}.', key)

		try:
			os.makedirs(work_dir)
		except OSError as err:
			raise CogentError(f'Unable to create directory: {work_dir}')

		# ---------- Immune profiling ---------- #
		immune = self._immune(key, work_dir, input_files)
		if immune is None:
			Logger.error_both(f'Failed immune for {key}')
			return False

		# ---------- Summarize ---------- #
		summarize = ImmuneSummarize(key, work_dir)
		summarize.create_summary_files(demux_summary.name, demux_summary.reads_num, immune.clonotype_tsv_file)

		# ---------- Clean working directory (first time) ---------- #
		if self.__debug_mode is DebugMode.NONE:
			self._clean_work_dir(False, immune=immune)
		elif self.__debug_mode is DebugMode.MODERATE:
			self._clean_work_dir(True, immune=immune)

		# Keep summarized class for return
		res_dict[key] = summarize

		Logger.info_logger(f'Finished processing. Elapsed time: ' + elapsed_time(start_time), key)		# For an independent log file
		Logger.info_logger(f'Finished processing for {key} in ' + elapsed_time(start_time))				# For main log file

		return True

	# ---------------------------------