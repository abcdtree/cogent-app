from datetime import datetime
from os import path
import os
# import shutil
from typing import Dict, List, Union
from common.cogent_error import CogentError
import csv

from common.logger import Logger
from common.experiment.experiment import Experiment
from common.util.demux import DemuxSummary
# from common.util.analyze import AnalyzeStats, create_analyze_stats_header
from common.util.util import elapsed_time, load_csv_as_dict
from common.analyze.base_report import BaseReport
from run_immune_analysis.data.immune_summarize import ImmuneSummarize

class ImmuneReport(BaseReport):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def stats_file(self) -> Union[str, None]:
		return self.__immune_stats_file

	@property
	def top3_clonotype_matrix(self) -> str:
		return self.__top3_clonotype_matrix

	@property
	def top3_metadata(self) -> str:
		return self.__top3_metadata

	@property
	def top3_summary(self) -> str:
		return self.__top3_summary

	@property
	def clonotype_matrix(self) -> str:
		return self.__clonotype_matrix

	@property
	def meta_data(self) -> str:
		return self.__meta_data

	@property
	def full_summary(self) -> str:
		return self.__full_summary

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, output_dir: str, prefix: str, experiment: Experiment):

		self.__out_dir = output_dir
		self.__experiment = experiment

		# Define file names
		self._define_files_path(output_dir, prefix)


	def create(self, key_list: List[str], result_objects: Dict[str, ImmuneSummarize], demux_summary: Dict[str, DemuxSummary] = None):

		# Create result files
		Logger.info_logger('Started creating metadata files, matrix files and stats files.')
		start_time = datetime.now()

		# stats: temp command out until more stats added in
		# self._merge_stats(key_list, {key:item.immune_stats_file for key, item in result_objects.items()}, self.__immune_stats_file, summary=demux_summary)

		# clono summary
		self._merge_top3_summary(key_list, {key:item.top3_summary_file for key, item in result_objects.items()}, self.__top3_summary)
		self._merge_full_summary(key_list, {key:item.full_summary_file for key, item in result_objects.items()}, self.__full_summary)

		# clonotype matrix
		self._merge_clonotype_matrix('V-D-J-C-CDR3aa', key_list, {key:item.top3_clonotype_matrix_file for key, item in result_objects.items()}, self.__top3_clonotype_matrix)
		self._merge_clonotype_matrix('V-D-J-C-CDR3aa', key_list, {key:item.clonotype_matrix_file for key, item in result_objects.items()}, self.__clonotype_matrix)

		# metadata
		self._merge_meta_data(key_list, {key:item.top3_meta_file for key, item in result_objects.items()}, self.__top3_metadata)
		self._merge_meta_data(key_list, {key:item.meta_data_file for key, item in result_objects.items()}, self.__meta_data)

		Logger.info_logger("Successfully completed reporting. Time elapsed: " + elapsed_time(start_time))

	def _merge_top3_summary(self, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		if out_file is None:
			return True
		with open(out_file, 'w') as out_f:
			header = [
				'Barcode','Total_Reads','Top1_clonotype','Top2_clonotype','Top3_clonotype',
				'Top1_V','Top1_D','Top1_J','Top1_C',
				'Top2_V','Top2_D','Top2_J','Top2_C',
				'Top3_V','Top3_D','Top3_J','Top3_C'
			]
			writer = csv.writer(out_f, lineterminator = '\n')
			writer.writerows([header])
			try:
				for key in key_list:
					if not key in in_files:
						raise CogentError(f'Result about {key} is not found.')
					with open(in_files[key], 'r') as in_f:
						one_char = in_f.read(1)
						if not one_char:
							continue
						else:
							next(in_f)
							out_f.write(in_f.read())
			except KeyError as err:
				Logger.error_both(f'Illegal clonotype {err}')
				return False
		return True


	def _merge_full_summary(self, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		if out_file is None:
			return True
		with open(out_file, 'w') as out_f:
			header = [
				'Barcode','Total_Reads',
				'TRA','TRB','TRD','TRG',
				'IGG','IGD','IGA','IGM','IGE','IGH','IGK','IGL',
				'TRA_V','TRA_D','TRA_J','TRA_C',
				'TRB_V','TRB_D','TRB_J','TRB_C',
				'TRD_V','TRD_D','TRD_J','TRD_C',
				'TRG_V','TRG_D','TRG_J','TRG_C',
				'IGG_V','IGG_D','IGG_J','IGG_C',
				'IGD_V','IGD_D','IGD_J','IGD_C',
				'IGA_V','IGA_D','IGA_J','IGA_C',
				'IGM_V','IGM_D','IGM_J','IGM_C',
				'IGE_V','IGE_D','IGE_J','IGE_C',
				'IGH_V','IGH_D','IGH_J','IGH_C',
				'IGK_V','IGK_D','IGK_J','IGK_C',
				'IGL_V','IGL_D','IGL_J','IGL_C'	
			]
			writer = csv.writer(out_f, lineterminator = '\n')
			writer.writerows([header])
			try:
				for key in key_list:
					if not key in in_files:
						raise CogentError(f'Result about {key} is not found.')
					with open(in_files[key], 'r') as in_f:
						one_char = in_f.read(1)
						if not one_char:
							continue
						else:
							next(in_f)
							out_f.write(in_f.read())
			except KeyError as err:
				Logger.error_both(f'Illegal clonotype {err}')
				return False
		return True


	def _merge_clonotype_matrix(self, header: str, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split clonot_matrix files
		   here header is used at cell 0,0 of matrix to show matrix type
		"""

		if out_file is None:
			return True

		header_values = [header]
		clonos = []
		bc_clone_dict = {}

		try:
			for key in key_list:
				if not key in in_files:
					raise CogentError(f'Result about {key} is not found.')

				with open(in_files[key], 'r') as f:
					one_char = f.read(1)
					if not one_char:
						continue
					else:
						header_values.append(f.readline().strip().split(',')[1])
						for line in f:
							clonotype, clono_count = line.strip().split(',')

							if clonotype not in clonos:
								clonos.append(clonotype)
								bc_clone_dict[clonotype] = {}
								bc_clone_dict[clonotype][key] = clono_count

							else:
								bc_clone_dict[clonotype][key] = clono_count

			clonos.sort()
			with open(out_file, 'w') as f:
				f.write(','.join(header_values) + '\n')
				count=0

				for clonotype in clonos:
					count +=  1
					f.write(clonotype)
					barcode_wi_clono = header_values[1:]
					for key in barcode_wi_clono:
						if key in bc_clone_dict[clonotype]:
							f.write(',' + bc_clone_dict[clonotype][key])
						else:
							f.write(',' + '0.0')
					f.write('\n')

			return True
		except KeyError as err:
			Logger.error_both(f'Illegal clonotype {err}')
			return False


	def _merge_meta_data(self, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split meta data files
		"""
		if out_file is None:
			return True
		with open(out_file, 'w') as out_f:
			header = ['V-D-J-C-CDR3aa',	'V', 'D', 'J', 'C', 'CDR3aa', 'Light Chain', 'Heavy Chain']
			writer = csv.writer(out_f, lineterminator = '\n')
			writer.writerows([header])
			meta_dict = {}
			try:
				for key in key_list:
					if not key in in_files:
						raise CogentError(f'Result about {key} is not found.')
					with open(in_files[key], 'r') as in_f:
						one_char = in_f.read(1)
						if not one_char:
							continue
						next(in_f)
						for line in in_f:
							clonotype, v, d, j, c, cdr3aa, lchain, hchain = line.strip().split(',')
							if clonotype not in meta_dict:
								meta_dict[clonotype] = [v, d, j, c, cdr3aa, lchain, hchain]
							else:
								pass
				keys = list(meta_dict.keys())
				keys.sort()
				for key in keys:
					data = [key] + meta_dict[key]
					writer.writerows([data])
				return True
			except KeyError as err:
				Logger.error_both(f'Illegal Fusion ID: {err}')
				return False

	def _define_files_path(self, out_dir: str, prefix: str):
		self.__immune_stats_file = path.join(out_dir, prefix + '_immune_stats.csv')
		self.__top3_summary = path.join(out_dir, prefix + '_top3_summary.csv')
		self.__top3_metadata = path.join(out_dir, prefix + '_top3_metadata.csv')
		self.__top3_clonotype_matrix = path.join(out_dir, prefix + '_top3_clonotype_matrix.csv')
		self.__full_summary = path.join(out_dir, prefix + '_summary.csv')
		self.__meta_data = path.join(out_dir, prefix + '_metadata.csv')
		self.__clonotype_matrix = path.join(out_dir, prefix + '_clonotype_matrix.csv')
		
			
	def _create_stats_header(self):
		headers = [
			'Barcode', 'Sample', 'Barcoded_Reads', 'Clonotype_Counts'
		]
		return headers
