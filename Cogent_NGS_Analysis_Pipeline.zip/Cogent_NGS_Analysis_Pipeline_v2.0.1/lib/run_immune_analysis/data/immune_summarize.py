from datetime import datetime
from os import path
from common.analyze.base_summarize import BaseSummarize

from common.logger import Logger
from common.util.util import elapsed_time

from run_immune_analysis.data.immune_parser import ImmuneParser

class ImmuneSummarize(BaseSummarize):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def immune_stats_file(self) -> str:
		return path.join(self.__work_dir, 'immune_stats.csv')

	@property
	def filter_report_file(self) -> str:
		return path.join(self.__work_dir, 'immune_filter_report.csv')

	@property
	def top3_summary_file(self) -> str:
		return path.join(self.__work_dir, 'immune_top3_summary.csv')

	@property
	def top3_clonotype_matrix_file(self) -> str:
		return path.join(self.__work_dir, 'immune_top3_clonotype_matrix.csv')

	@property
	def top3_meta_file(self) -> str:
		return path.join(self.__work_dir, 'immune_top3_metadata.csv')

	@property
	def full_summary_file(self) -> str:
		return path.join(self.__work_dir, 'immune_summary.csv')

	@property
	def clonotype_matrix_file(self) -> str:
		return path.join(self.__work_dir, 'immune_clonotype_matrix.csv')

	@property
	def meta_data_file(self) -> str:
		return path.join(self.__work_dir, 'immune_metadata.csv')

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, key: str, work_dir: str):
		self.__key = key
		self.__work_dir = work_dir

	def create_summary_files(self, sample_name: str, input_reads: int, clonotype_tsv_file: str) -> bool:

		start_time = datetime.now()
		parser = ImmuneParser(self.__key)

		# output split results for barcode
		self._create_result_files(parser, sample_name, input_reads, clonotype_tsv_file)
		Logger.info_logger("Successfully completed creating immune summary stats files. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def _create_result_files(self, parser: ImmuneParser, sample_name: str, input_count: int, clonotype_tsv_file: str) -> bool:

		# create filter report
		parser.create_filter_report(self.__key, clonotype_tsv_file, self.filter_report_file)

		# stats
		parser.create_immune_stats(self.__key, self.immune_stats_file, sample_name, input_count)

		# top3 summary, matrix & meta data 
		parser.create_top3_summary(self.__key, self.filter_report_file, self.top3_summary_file, self.top3_clonotype_matrix_file, self.top3_meta_file)

		# full after filtering summary, matrix & meta data 
		parser.create_full_summary(self.__key, self.filter_report_file, self.full_summary_file, self.clonotype_matrix_file, self.meta_data_file)

		return True

