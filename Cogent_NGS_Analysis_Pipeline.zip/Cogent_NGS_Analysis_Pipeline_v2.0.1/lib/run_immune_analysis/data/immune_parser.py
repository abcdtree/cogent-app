#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to perform and handle immune profiling files
# This class holds count stats for each barcode.

import csv

from common.logger import Logger
from analyze.data.count_stats import CountStats
from os import path

class ImmuneParser:
	"""
	Handles Immune profiling counts of all barcodes.
	Also having functions for reporting.
	"""

	# on initialize
	def __init__(self, key: str):
		"""Initialize function. Save passed parameters.
		"""
		self.__key = key
		self.__count_stats = CountStats(key)

	# --- methods ---

	#--------------------------------------------------------------------------
	# region: For split mode

	def create_filter_report(self, barcode: str, in_file: str, out_file: str):
		sampleType=None
		if out_file is None:
			return
		readCutoff = 2
		perCutoff = 0.005
		if not path.isfile(in_file):
			with open(out_file, 'w') as out_f:
				writer = csv.writer(out_f, lineterminator = '\n')
		else:
			with open(in_file, 'r') as in_f, open(out_file, 'w') as out_f:
				next(in_f)
				nline = 0
				chains = []
				tnBCR = 0
				tnTCR = 0
				tpBCR = 0
				tpTCR = 0
				for line in in_f:
					nline += 1
					entries = line.rstrip().split('\t') # rstrip() method removes any trailing characters
					# print(entries)
					if len(list(set([ f[0:2] for f in entries[4:8] if f!='.']))) == 1:
						curC = list(set([ f[0:2] for f in entries[4:8] if f!='.']))[0]
					# else:
					#	print('BCR & TCR both idenitified for current entry: barcode ' + barcode + ' row ' + nline)
					curRead = int(entries[0])
					curPer  = float(entries[1])
					chains.append(curC)
					if curC == 'IG':
						tnBCR += curRead
						tpBCR += curPer
					elif curC == 'TR':
						tnTCR += curRead
						tpTCR += curPer
					#else:
					#	print('wrong clonotype found: ' + curC)
				if len(set(chains)) == 0:
					# print('no clonotype identified')
					return
				elif len(set(chains)) == 1:
					# print('only identified one chain: ' + chains[0])
					sampleType = chains[0]
				elif 'IG' in chains and 'TR' in chains:
					# if round(tpBCR) == 1 and round(tpTCR) == 1:
					# if tnBCR/(tnBCR+tnTCR)>0.8:
					if tnBCR > tnTCR:
						sampleType = 'IG'
					# elif tnTCR/(tnBCR+tnTCR)>0.8:
					elif tnTCR > tnBCR:
						sampleType = 'TR'
					# else:
					#	print('need drop this sample')
				# if len(chains)!= nline:
				#	print('number of chains not equal to number of entry, missing entry')
				#	break
				if sampleType == None:
					return
				in_f.seek(0) # re-iteration
				next(in_f)
				nline = 0
				rowID =[]
				nRead = []
				pRead = []
				cdr3nt = []
				cdr3aa = []
				vRegion = []
				dRegion = []
				jRegion = []
				cRegion = []
				partialFilter = []
				outframeFilter = []
				readFilter = []
				perFilter = []
				# typeFilter = []
				finalFilter = []
				for line in in_f:
					nline += 1
					rowID.append(nline)
					entries = line.rstrip().split('\t')
					nRead.append(entries[0])
					pRead.append(entries[1])
					cdr3nt.append(entries[2])
					cdr3aa.append(entries[3])
					vRegion.append(entries[4])
					dRegion.append(entries[5])
					jRegion.append(entries[6])
					cRegion.append(entries[7])
					if entries[3] == 'partial':
						partialFilter.append(1)
					else:
						partialFilter.append(0)
					if entries[3] == 'out_of_frame':
						outframeFilter.append(1)
					else:
						outframeFilter.append(0)
					if int(entries[0]) <  int(readCutoff):
						readFilter.append(1)
					else:
						readFilter.append(0)
					if float(entries[1]) < float(perCutoff):
						perFilter.append(1)
					else:
						perFilter.append(0)
					# if chains[nline - 1] != sampleType:
					# 	typeFilter.append(1)
					# else:
					#	typeFilter.append(0)
				finalFilter = [sum(elts) for elts in zip(partialFilter,outframeFilter,readFilter,perFilter)] # ,typeFilter
				if any(ele == 0 for ele in finalFilter): # make sure there is entry after applied all filters
					indices = [i for i, x in enumerate(finalFilter) if x == 0]
					# only if data after filtering, would write header to filter_report.csv
					if len(indices) != 0:
						writer = csv.writer(out_f, lineterminator = '\n')
						header = ['count','frequency','cdr3nt','cdr3aa','V','D','J','C']
						writer.writerows([header])
						for i in indices:
							data =[nRead[i], pRead[i], cdr3nt[i], cdr3aa[i],vRegion[i], dRegion[i], jRegion[i], cRegion[i]]
							writer.writerows([data])

	def create_immune_stats(self, key: str, out_file: str, sample_name: str, demux_count: int):
		with open(out_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')
			data = [key, sample_name, str(demux_count)]
			writer.writerows([data])

	def create_top3_summary(self, barcode: str, in_file: str, out_file1: str, out_file2: str, out_file3: str):
		if out_file1 is None:
			return
		if out_file2 is None:
			return
		if out_file3 is None:
			return
		with open(in_file, 'r') as in_f, open(out_file1, 'w') as out_f1,open(out_file2, 'w') as out_f2,open(out_file3, 'w') as out_f3:
			one_char = in_f.read(1)
			if not one_char:
				return
			nline = 0
			sumCount_dict = {}
			tCount = 0
			top1_clonotype = top2_clonotype = top3_clonotype = ''
			top1_V = top2_V = top3_V = ''
			top1_D = top2_D = top3_D = ''
			top1_J = top2_J = top3_J = ''
			top1_C = top2_C = top3_C = ''
			next(in_f)
			for line in in_f:
				nline += 1
				if nline <= 3:
					entries = line.rstrip().split(',')
					curCount = entries[0]
					vGene = entries[4]
					dGene = entries[5]
					jGene = entries[6]
					cGene = entries[7]
					aaCall = entries[3]
					tCount += int(curCount)
					receptorTypes=[ item[0:2] for item in entries[4:7] if item!='.' ]
					receptor=list(set(receptorTypes))[0]
					filtChains = [ item[2] for item in entries[4:7] if item!='.' ]
					chainType = list(set(filtChains))[0] 
					if receptor == 'IG':
						# heavy chain (IgG, IgD, IgA, IgM, IgE, IgH) & light chain (IgK & IgL)
						if chainType in ['G', 'D', 'A', 'M','E','H']:
							heavyChain = 'Y'
							lightChain = 'N'
						elif chainType in ['L','K']:
							lightChain = 'Y'
							heavyChain = 'N'
					elif receptor == 'TR':
						# heavy chain (TRB, TRD) & light chain (TRA & TRG)
						if chainType in ['B','D']:
							heavyChain = 'Y'
							lightChain = 'N'
						elif chainType in ['A','G']:
							lightChain = 'Y'
							heavyChain = 'N'
					jointKey = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall + '$' + lightChain + '$' + heavyChain
					if jointKey not in sumCount_dict:
						sumCount_dict[jointKey] = int(curCount)
					else:
						sumCount_dict[jointKey] += int(curCount)
					curType = list(set([ item[0:3] for item in entries[4:7] if item!='.' ]))[0]
					if nline == 1:
						top1_clonotype = curType
						top1_V = vGene
						top1_D = dGene
						top1_J = jGene
						top1_C = cGene
					elif nline == 2:
						top2_clonotype = curType
						top2_V = vGene
						top2_D = dGene
						top2_J = jGene
						top2_C = cGene
					elif nline == 3:
						top3_clonotype = curType
						top3_V = vGene
						top3_D = dGene
						top3_J = jGene
						top3_C = cGene

			# write top3 summary
			writer1 = csv.writer(out_f1, lineterminator = '\n')
			header1 = [
				'Barcode','Total_Reads','Top1_clonotype','Top2_clonotype','Top3_clonotype',
				'Top1_V','Top1_D','Top1_J','Top1_C',
				'Top2_V','Top2_D','Top2_J','Top2_C',
				'Top3_V','Top3_D','Top3_J','Top3_C'
			]
			writer1.writerows([header1])
			data1 = [
					barcode, tCount, top1_clonotype, top2_clonotype, top3_clonotype,
					top1_V, top1_D, top1_J, top1_C,
					top2_V, top2_D, top2_J, top3_C,
					top3_V, top3_D, top3_J, top3_C,
			]
			writer1.writerows([data1])

			# write clonotype matrix
			writer2 = csv.writer(out_f2, lineterminator = '\n')
			header2 = ['V-D-J-C-CDR3aa', barcode]
			writer2.writerows([header2])
			key_list = list(sumCount_dict.keys())
			key_list.sort()
			for key in key_list:
				vGene, dGene, jGene, cGene, aaCall = key.split('$')[0:5]
				joint_vdj = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall
				joint_count = sumCount_dict[key]
				data2 = [joint_vdj, joint_count]
				writer2.writerows([data2])

			# write meta data
			writer3 = csv.writer(out_f3, lineterminator = '\n')
			header3 = ['V-D-J-C-CDR3aa','V', 'D', 'J', 'C', 'CDR3aa', 'Light Chain', 'Heavy Chain']
			writer3.writerows([header3])
			key_list = list(sumCount_dict.keys())
			key_list.sort()
			for key in key_list:
				vGene, dGene, jGene, cGene, aaCall, lightChain, heavyChain = key.split('$')
				joint_vdj = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall
				data3 = [
					joint_vdj,
					vGene, dGene, jGene, cGene, aaCall,
					lightChain, heavyChain
				 ]
				writer3.writerows([data3])

	def create_full_summary(self, barcode: str, in_file: str, out_file1: str, out_file2: str, out_file3: str):
		if in_file is None:
			return
		if out_file1 is None:
			return
		if out_file2 is None:
			return
		if out_file3 is None:
			return	
		with open(in_file, 'r') as in_f, open(out_file1, 'w') as out_f1,open(out_file2, 'w') as out_f2,open(out_file3, 'w') as out_f3:
			one_char = in_f.read(1)
			if not one_char:
				return
			nline = 0
			sumCount_dict = {}
			tCount = 0
			IGG = IGD = IGA = IGM = IGE = IGH = IGK = IGL = TRA = TRB = TRD = TRG = ''
			IGG_V = IGD_V = IGA_V = IGM_V = IGE_V = IGH_V = IGK_V = IGL_V = TRA_V = TRB_V = TRD_V = TRG_V = ''
			IGG_D = IGD_D = IGA_D = IGM_D = IGE_D = IGH_D = IGK_D = IGL_D = TRA_D = TRB_D = TRD_D = TRG_D = ''
			IGG_J = IGD_J = IGA_J = IGM_J = IGE_J = IGH_J = IGK_J = IGL_J = TRA_J = TRB_J = TRD_J = TRG_J = ''
			IGG_C = IGD_C = IGA_C = IGM_C = IGE_C = IGH_C = IGK_C = IGL_C = TRA_C = TRB_C = TRD_C = TRG_C = ''
			next(in_f)
			for line in in_f:
				nline += 1
				entries = line.rstrip().split(',')
				curCount = entries[0]
				vGene = entries[4]
				dGene = entries[5]
				jGene = entries[6]
				cGene = entries[7]
				aaCall = entries[3]
				tCount += int(curCount)
				receptorTypes=[ item[0:2] for item in entries[4:7] if item!='.' ]
				receptor=list(set(receptorTypes))[0]
				filtChains = [ item[2] for item in entries[4:7] if item!='.' ]
				chainType = list(set(filtChains))[0] 
				if receptor == 'IG':
					# heavy chain (IgG, IgD, IgA, IgM, IgE, IgH) & light chain (IgK & IgL)
					if chainType in ['G', 'D', 'A', 'M','E','H']:
						heavyChain = 'Y'
						lightChain = 'N'
					elif chainType in ['L','K']:
						lightChain = 'Y'
						heavyChain = 'N'
				elif receptor == 'TR':
					# heavy chain (TRB, TRD) & light chain (TRA & TRG)
					if chainType in ['B','D']:
						heavyChain = 'Y'
						lightChain = 'N'
					elif chainType in ['A','G']:
						lightChain = 'Y'
						heavyChain = 'N'
				jointKey = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall + '$' + lightChain + '$' + heavyChain
				if jointKey not in sumCount_dict:
					sumCount_dict[jointKey] = int(curCount)
				else:
					sumCount_dict[jointKey] += int(curCount)
				curType = list(set([ item[0:3] for item in entries[4:7] if item!='.' ]))[0]  
				if receptor == 'IG':      
					if curType == 'IGG' and IGG == '':
						IGG = curType
						IGG_V = vGene
						IGG_D = dGene
						IGG_J = jGene
						IGG_C = cGene
					elif curType == 'IGD' and IGD == '':
						IGD = curType
						IGD_V = vGene
						IGD_D = dGene
						IGD_J = jGene
						IGD_C = cGene
					elif curType == 'IGA' and IGA == '':
						IGA = curType
						IGA_V = vGene
						IGA_D = dGene
						IGA_J = jGene
						IGA_C = cGene
					elif curType == 'IGM' and IGM == '':
						IGM = curType
						IGM_V = vGene
						IGM_D = dGene
						IGM_J = jGene
						IGM_C = cGene
					elif curType == 'IGE' and IGE == '':
						IGE = curType
						IGE_V = vGene
						IGE_D = dGene
						IGE_J = jGene
						IGE_C = cGene
					elif curType == 'IGH' and IGH == '':
						IGH = curType
						IGH_V = vGene
						IGH_D = dGene
						IGH_J = jGene
						IGH_C = cGene	
					elif curType == 'IGK' and IGK == '':
						IGK = curType
						IGK_V = vGene
						IGK_D = dGene
						IGK_J = jGene
						IGK_C = cGene
					elif curType == 'IGL' and IGL == '':
						IGL = curType
						IGL_V = vGene
						IGL_D = dGene
						IGL_J = jGene
						IGL_C = cGene					
				elif receptor == 'TR':
					if curType == 'TRA' and TRA == '':
						TRA = curType
						TRA_V = vGene
						TRA_D = dGene
						TRA_J = jGene
						TRA_C = cGene
					elif curType == 'TRB' and TRB == '':
						TRB = curType
						TRB_V = vGene
						TRB_D = dGene
						TRB_J = jGene
						TRB_C = cGene
					elif curType == 'TRD' and TRD == '':
						TRD = curType
						TRD_V = vGene
						TRD_D = dGene
						TRD_J = jGene
						TRD_C = cGene
					elif curType == 'TRG' and TRG == '':
						TRG = curType
						TRG_V = vGene
						TRG_D = dGene
						TRG_J = jGene
						TRG_C = cGene
			# write clonotype summary
			writer1 = csv.writer(out_f1, lineterminator = '\n')
			header1 = [
				'Barcode','Total_Reads',
				'TRA','TRB','TRD','TRG',
				'IGG','IGD','IGA','IGM','IGE','IGH','IGK','IGL',
				'TRA_V','TRA_D','TRA_J','TRA_C',
				'TRB_V','TRB_D','TRB_J','TRB_C',
				'TRD_V','TRD_D','TRD_J','TRD_C',
				'TRG_V','TRG_D','TRG_J','TRG_C',
				'IGG_V','IGG_D','IGG_J','IGG_C',
				'IGD_V','IGD_D','IGD_J','IGD_C',
				'IGA_V','IGA_D','IGA_J','IGA_C',
				'IGM_V','IGM_D','IGM_J','IGM_C',
				'IGE_V','IGE_D','IGE_J','IGE_C',
				'IGH_V','IGH_D','IGH_J','IGH_C',
				'IGK_V','IGK_D','IGK_J','IGK_C',
				'IGL_V','IGL_D','IGL_J','IGL_C'		
			]
			writer1.writerows([header1])
			data1 = [
				barcode, tCount, 
				TRA,TRB,TRD,TRG,
				IGG,IGD,IGA,IGM,IGE,IGH,IGK,IGL,
				TRA_V,TRA_D,TRA_J,TRA_C,
				TRB_V,TRB_D,TRB_J,TRB_C,
				TRD_V,TRD_D,TRD_J,TRD_C,
				TRG_V,TRG_D,TRG_J,TRG_C,
				IGG_V,IGG_D,IGG_J,IGG_C,
				IGD_V,IGD_D,IGD_J,IGD_C,
				IGA_V,IGA_D,IGA_J,IGA_C,
				IGM_V,IGM_D,IGM_J,IGM_C,
				IGE_V,IGE_D,IGE_J,IGE_C,
				IGH_V,IGH_D,IGH_J,IGH_C,
				IGK_V,IGK_D,IGK_J,IGK_C,
				IGL_V,IGL_D,IGL_J,IGL_C			
			]
			writer1.writerows([data1])

			# write clonotype matrix
			writer2 = csv.writer(out_f2, lineterminator = '\n')
			header2 = ['V-D-J-C-CDR3aa', barcode]
			writer2.writerows([header2])
			key_list = list(sumCount_dict.keys())
			key_list.sort()
			for key in key_list:
				vGene, dGene, jGene, cGene, aaCall = key.split('$')[0:5]
				joint_vdj = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall
				joint_count = sumCount_dict[key]
				data2 = [joint_vdj, joint_count]
				writer2.writerows([data2])

			# write meta data
			writer3 = csv.writer(out_f3, lineterminator = '\n')
			header3 = ['V-D-J-C-CDR3aa','V', 'D', 'J', 'C', 'CDR3aa', 'Light Chain', 'Heavy Chain']
			writer3.writerows([header3])
			key_list = list(sumCount_dict.keys())
			key_list.sort()
			for key in key_list:
				vGene, dGene, jGene, cGene, aaCall, lightChain, heavyChain = key.split('$')
				joint_vdj = vGene + '$' + dGene + '$' + jGene + '$' + cGene + '$' + aaCall
				data3 = [
					joint_vdj,
					vGene, dGene, jGene, cGene, aaCall, 
					lightChain, heavyChain
				 ]
				writer3.writerows([data3])

	# endregion
	#--------------------------------------------------------------------------
