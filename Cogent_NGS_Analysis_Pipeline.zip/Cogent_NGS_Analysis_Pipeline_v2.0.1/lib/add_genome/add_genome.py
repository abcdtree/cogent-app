#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script of add_genome sub-command.
#
# Script to add (or replace) genome build to genomes directory in CogentAP installed.
# To do that, this script receives FASTA and GTF of target species.
# Then run STAR to make genome index for alignment.
#

# ---------- script info ---------- #
SCRIPT_NAME = 'add_genome'
MAIN_DESC = 'Build a genome with preferred STAR and RSEM parameters.'

# Do not put indent, because it effects for output.
SUB_DESC = """
description:
  Build a genome with preferred STAR and RSEM parameters.
"""

import os
import subprocess
import json
from os import path, unlink
import sys
import shutil
from datetime import datetime
from common.cogent_error import CogentError
from common.config import Config
from common.logger import Logger

from common.util.util import elapsed_time, run_system_cmd

# Build genome index for STAR aligner
def build_star_index(genome_dir: str, name: str, star_path: str, genome_fasta: str, gtf_file: str, cores: int, ram_limit: int) -> bool:

	Logger.info_both("Started building STAR index.")

	start_time = datetime.now()
	star_index_dir = path.join(genome_dir, Config.STAR_INDEX_NAME)
	os.mkdir(star_index_dir)

	command = [
		star_path,
		'--runThreadN', str(cores),
		'--runMode', 'genomeGenerate',
		'--genomeDir', star_index_dir,
		'--genomeFastaFiles', genome_fasta,
		'--sjdbGTFfile', gtf_file,
		'--sjdbOverhang', '100',
		'--limitGenomeGenerateRAM', str(ram_limit)
	]

	build_out = path.join(star_index_dir, 'star_build.stdout')
	build_err = path.join(star_index_dir, 'star_build.stderr')

	Logger.info_both('Building the STAR index: ' + name)
	Logger.info_both('*** This takes a while (~1hr for human/mouse genome sizes) ***')

	res =  run_system_cmd(' '.join(command), build_out, build_err)
	if not res:
		Logger.error_both('Failed to build STAR index.')
		return False

	# Copy Log.out file (required when version before 2.7.3a)
	try:
		os.rename(path.join(os.getcwd(), 'Log.out'), path.join(star_index_dir, 'Log.out'))
	except OSError as err:
		Logger.warning_both("Unable to move Log.out file to genome directory")

	Logger.info_both("Successfully built STAR index. Elapsed time: " + elapsed_time(start_time))

	return True

# # Build genome index for salmon (deprecated)
# def build_salmon_index(genome_dir: str, name: str, salmon_path: str, gffread_path: str, genome_fasta: str, gtf_file: str, cores: int) -> bool:

# 	Logger.info_both("Started building salmon index.")

# 	start_time = datetime.now()
# 	salmon_index_dir = path.join(genome_dir, Config.SALMON_INDEX_NAME)
# 	os.mkdir(salmon_index_dir)

# 	# Create decoy list (chromosome name list)
# 	decoy_file = path.join(salmon_index_dir, 'decoys.txt')
# 	with open(genome_fasta, 'r') as in_file, open(decoy_file, 'w') as out_file:
# 		for line in in_file:
# 			if line.startswith('>'):
# 				out_file.write(str(line.rstrip().split(' ')[0][1:]) + '\n')

# 	# Create transcripts fasta
# 	transcript_fasta = path.join(salmon_index_dir, 'transcripts.fa')
# 	command = [
# 		gffread_path,
# 		'-w', transcript_fasta,
# 		'-g', genome_fasta,
# 		gtf_file
# 	]
# 	res =  run_system_cmd(' '.join(command))
# 	if not res:
# 		Logger.error_both('Failed to run gffread.')
# 		return False

# 	# Concatenate
# 	trans_genome_fasta = path.join(salmon_index_dir, 'transcripts_with_genome.fa')
# 	with open(trans_genome_fasta, 'w') as out_file:
# 		for file in [transcript_fasta, genome_fasta]:
# 			with open(file, 'r') as in_file:
# 				for line in in_file:
# 					out_file.write(line)

# 	# Build index
# 	command = [
# 		salmon_path,
# 		'index',
# 		'-t', trans_genome_fasta,
# 		'-i', salmon_index_dir,
# 		'--decoys', decoy_file,
# 		'-k', '31',
# 		'-p', str(cores),
# 		'--keepDuplicates'
# 	]

# 	build_out = path.join(salmon_index_dir, 'salmon_build.stdout')
# 	build_err = path.join(salmon_index_dir, 'salmon_build.stderr')

# 	Logger.info_both('Building the salmon index: ' + name)
# 	Logger.info_both('*** This takes a while (~1hr for human/mouse genome sizes) ***')

# 	res =  run_system_cmd(' '.join(command), build_out, build_err)
# 	if not res:
# 		Logger.error_both('Failed to build salmon index.')
# 		return False

# 	# Remove temporary files
# 	unlink(decoy_file)
# 	unlink(transcript_fasta)
# 	unlink(trans_genome_fasta)
# 	unlink(genome_fasta + '.fai')

# 	Logger.info_both("Successfully built salmon index. Elapsed time: " + elapsed_time(start_time))

# 	return True

# Build genome index for rsem
def build_rsem_index(genome_dir: str, name: str, rsem_path: str, star_path: str, genome_fasta: str, gtf_file: str, cores: int) -> bool:

	Logger.info_both("Started building RSEM index.")

	start_time = datetime.now()
	rsem_index_dir = path.join(genome_dir, Config.RSEM_INDEX_NAME)
	os.mkdir(rsem_index_dir)

	# Build index
	command = [
		rsem_path,
		'-p', str(cores),
		'--gtf', gtf_file,
		'--star',
		'--star-path', path.dirname(star_path),
		genome_fasta,
		path.join(rsem_index_dir, name)
	]

	build_out = path.join(rsem_index_dir, 'rsem_build.stdout')
	build_err = path.join(rsem_index_dir, 'rsem_build.stderr')

	Logger.info_both('Building the rsem index: ' + name)
	Logger.info_both('*** This takes a while (~1hr for human/mouse genome sizes) ***')

	res =  run_system_cmd(' '.join(command), build_out, build_err)
	if not res:
		Logger.error_both('Failed to build rsem index.')
		return False

	# # Remove temporary files
	# unlink(genome_fasta + '.fai')

	Logger.info_both("Successfully built rsem index. Elapsed time: " + elapsed_time(start_time))

	return True

def create_mito_gtf(chr_file: str, out_dir: str, mito_name: str) -> bool:

	try:
		Logger.info_both(f'Generete mitochondria GTF file. Key is {mito_name}.')

		gtf_file = out_dir + "/mitochondria.gtf"
		output_count = 0

		with open(chr_file, 'r') as ip, open(gtf_file, 'w') as op:
			# Pickup lines of mitochondria and output it as gtf
			for line in ip:
				values = line.rstrip().split('\t')
				if values[0] == mito_name:
					op.write('%s\t.\tgene\t1\t%s\t.\t+\t.\tgene_id "gMT";\n' % (values[0], values[1]))
					output_count += 1

		if output_count == 0:
			Logger.warning_both(f'Unable to find mitochondria chromosome for the name {mito_name} in {chr_file}. But proceed steps without generating mitochondria information.')
			unlink(gtf_file)								# Remove empty file

			return True
		else:
			if output_count > 1:
				Logger.warning_both(f'Found multiple mitochondria info in {chr_file}')

			return True

	except subprocess.CalledProcessError as err:
		Logger.error_logger("Unexpected error while creating mitochondria gtf: " +  str(err))
		return False


# ---------- main ---------- #
def run(user_args, default_configs) -> bool:

	# ---------- set | genome options ---------- #
	genome_choices = [k.split(Config.GENOME_CONFIG_DELIMITER)[1] for k, v in default_configs.items() if Config.GENOME_CONFIG_KEY in k]

	# ---------- setup | parse/check user options ---------- #
	genome_dir = default_configs['genomedir_loc'][0]
	output_dir = path.join(genome_dir, user_args.g_name)

	if (user_args.g_name in genome_choices) or (os.path.isdir(output_dir)):
		print("Genome with given name already exists:" + user_args.g_name + "\n")
		if user_args.repl:
			print("Existing genome will be replaced as per request\n")
		else:
			print("Re-run with edited name OR with -r option to replace existing genome\n")
			return False

	if ":" in user_args.g_name:
		print('You cannot use ":" in genome name. Please input an another name: ' + user_args.g_name)
		return False

	if not os.path.isdir(genome_dir):
		print("ERROR: genomes directory not found\n")
		return False

	if user_args.repl:
		try:
			shutil.rmtree(output_dir)
		except OSError as err:
			print("Warning: Unable to find genome sub-directory: " + user_args.g_name + "\n")
			print("Continuing...\n")

	#Create out dir
	try:
		os.makedirs(output_dir)
	except OSError as err:
		print("Unable to create directory: " + user_args.g_name)
		return False

	# ---------- setup | logger ---------- #
	Logger.initialize(SCRIPT_NAME, path.join(output_dir, 'add_genome_log.txt'))
	Logger.info_logger("Command name: " + SCRIPT_NAME)
	Logger.info_logger("Original call : " + " ".join(sys.argv))

	try:
		# Unzip if needed
		if user_args.g_fa.endswith(".gz"):
			cmd = default_configs['unpigz_loc'][0] + ' ' + user_args.g_fa
			tmpout = os.path.join(os.getcwd(), 'tmp.stdout')
			tmperr = os.path.join(os.getcwd(), 'tmp.stderr')
			res = run_system_cmd(cmd, tmpout, tmperr)
			if not res:
				raise CogentError('Unzip failed.')

			user_args.g_fa = user_args.g_fa[:-3]
			os.remove(tmpout)
			os.remove(tmperr)

		if user_args.g_gtf.endswith(".gz"):
			cmd = default_configs['unpigz_loc'][0] + ' ' + user_args.g_gtf
			tmpout = os.path.join(os.getcwd(), 'tmp.stdout')
			tmperr = os.path.join(os.getcwd(), 'tmp.stderr')
			res = run_system_cmd(cmd, tmpout, tmperr)
			if not res:
				raise CogentError('Unzip failed.')

			user_args.g_gtf = user_args.g_gtf[:-3]
			os.remove(tmpout)
			os.remove(tmperr)

		# Build genome with STAR
		res = build_star_index(output_dir, user_args.g_name, default_configs['star_loc'][0], user_args.g_fa, user_args.g_gtf, user_args.n_threads, user_args.limit_genome_generate_ram)
		if not res:
			return False

		# Generate mitochondria gtf
		chr_file = path.join(output_dir, Config.STAR_INDEX_NAME, 'chrNameLength.txt')
		res = create_mito_gtf(chr_file, output_dir, user_args.mito_name)
		if not res:
			return False

		# Build rsem index
		res = build_rsem_index(
			output_dir, user_args.g_name, default_configs['rsem_reference_loc'][0], default_configs['star_loc'][0],
			user_args.g_fa, user_args.g_gtf, user_args.n_threads)
		if not res:
			return False

		# Copy gtf to genome dir
		try:
			gtf_name = path.basename(user_args.g_gtf)
			shutil.copyfile(user_args.g_gtf, path.join(output_dir, gtf_name))
		except OSError as err:
			Logger.error_both('Unable to copy GTF file to genome directory')
			return False

		# Create genome preferences for use genome in json
		genome_pref = {'provider': 'user', 'species': 'unknown', 'fusion': False, 'immune': False}
		with open(f'{output_dir}/{Config.GENOME_PREFERENCES}', 'w') as f:
			json.dump(genome_pref, f, indent=4)

		Logger.info_both("Successfully completed genome build and addition to config")

	except CogentError as e:
		if e.function is None:
			Logger.error_both(f'{e.message}')
		else:
			Logger.error_both(f'{e.message} (at {e.function})')

		return False

	return True
