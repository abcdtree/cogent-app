from datetime import datetime
import os
from typing import Dict
from os import path

from common.analyze.base_processor import BaseProcessor
from common.cogent_error import CogentError
from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.analyze import AnalyzeStats
from common.util.const import DebugMode, FusionFilter
from common.util.util import elapsed_time
from run_fusion_analysis.data.fusion_summarize import FusionSummarize

class FusionProcessor(BaseProcessor):

	@property
	def results(self) -> Dict[str, FusionSummarize]:
		return self._results

	# Initialize
	def __init__(self, threads_num: int, cores_num: int, experiment: Experiment,
				work_dir: str, logs_dir: str, config_dir: str, default_configs, genome_used: str,
				debug_mode: DebugMode, filter: FusionFilter):

		super().__init__(threads_num, cores_num, experiment, logs_dir, config_dir, default_configs, genome_used)

		self.__experiment = experiment				# Experiment type
		self.__debug_mode = debug_mode
		self.__filter = filter

		self.__work_dir_root = work_dir
		self.__logs_dir_root = logs_dir

	# Impl of abstract method
	def _work_per_barcode(self, pid: int, key: str, chimeric_file: tuple, res_dict: Dict[str, FusionSummarize], stats: AnalyzeStats) -> bool:

		start_time = datetime.now()

		# ---------- Setup for this key ---------- #
		work_dir = path.join(self.__work_dir_root, key)
		Logger.add_logger(key, path.join(self.__logs_dir_root, f'{key}_log.txt'))
		Logger.info_logger(f'Started processing for {key}.', key)

		try:
			os.makedirs(work_dir)		# Create sub-folder
		except OSError as err:
			raise CogentError(f'Unable to create directory: {work_dir}')

		# ---------- Gene Fusion Analysis ---------- #
		fusion = self._fusion(key, work_dir, chimeric_file[0], self.__filter)
		if fusion is None:
			Logger.error_both(f'Failed fusion for {key}')
			return False

		# ---------- Summarize ---------- #
		if stats.sample_name is None or stats.barcoded_reads is None:
			Logger.error_both(f'Failed when summarizing fusion for {key}. Cannot detect sample name and barcorded reads.')
			return False

		summarize = FusionSummarize(key, work_dir)
		summarize.create_summary_files(stats.sample_name, stats.barcoded_reads, fusion.result_file)

		# ---------- Clean working directory (first time) ---------- #
		if self.__debug_mode is DebugMode.NONE:
			self._clean_work_dir(False, fusion=fusion)
		elif self.__debug_mode is DebugMode.MODERATE:
			self._clean_work_dir(True, fusion=fusion)

		# ---------- Generate fusion info file (only once for pid = 1) ---------- #

		# Keep summarized class for return
		res_dict[key] = summarize

		Logger.info_logger(f'Finished processing. Elapsed time: ' + elapsed_time(start_time), key)		# For an independent log file
		Logger.info_logger(f'Finished processing for {key} in ' + elapsed_time(start_time))				# For main log file

		return True

