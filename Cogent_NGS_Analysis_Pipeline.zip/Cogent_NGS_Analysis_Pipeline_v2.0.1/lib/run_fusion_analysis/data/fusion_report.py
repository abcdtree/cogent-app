from datetime import datetime
from os import path
import os
import shutil
from typing import Dict, List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.experiment.experiment import Experiment
from common.util.analyze import AnalyzeStats
from common.util.demux import DemuxSummary
from common.util.util import elapsed_time
from common.analyze.base_report import BaseReport
from run_fusion_analysis.data.fusion_summarize import FusionSummarize

class FusionReport(BaseReport):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def stats_file(self) -> str:
		return self.__fusion_stats_file

	@property
	def junction_matrix(self) -> str:
		return self.__junction_matrix

	@property
	def spanning_matrix(self) -> str:
		return self.__spanning_matrix

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, output_dir: str, prefix: str, experiment: Experiment):

		self.__out_dir = output_dir
		self.__experiment = experiment

		# Define file names
		self._define_files_path(output_dir, prefix)

	def create(self, key_list: List[str], result_objects: Dict[str, FusionSummarize], stats: Union[Dict[str, AnalyzeStats], Dict[str, DemuxSummary]] = None):

		# Create result files
		Logger.info_logger('Started creating report files, matrix files and stats files.')
		start_time = datetime.now()

		# stats
		if stats is None:
			raise CogentError('Cannot detect stats from analyze command', 'create')

		self._merge_stats(key_list, {key:item.fusion_stats_file for key, item in result_objects.items()}, self.__fusion_stats_file, summary=stats)

		# junction matrix
		self._merge_fusion_matrix('GeneFusion', key_list, {key:item.junction_counts_file for key, item in result_objects.items()}, self.__junction_matrix)

		# spanning matrix
		self._merge_fusion_matrix('GeneFusion', key_list, {key:item.spanning_counts_file for key, item in result_objects.items()}, self.__spanning_matrix)

		Logger.info_logger("Successfully completed reporting. Time elapsed: " + elapsed_time(start_time))

	def _merge_fusion_matrix(self, header: str, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split fusion_matrix files

		"""

		if out_file is None:
			return True

		header_values = [header]

    	## Put fusion result into dictionsry
		fusionList = []
		fusionBcList = {}

		try:
			# process each file
			for key in key_list:
				if not key in in_files:
					raise CogentError(f'Result about {key} is not found.')

				with open(in_files[key], 'r') as f:
					header_values.append(f.readline().strip().split(',')[1])
					for line in f:
						fusion_id, value = line.strip().split(',')

						if fusion_id not in fusionList:
							fusionList.append(fusion_id)
							fusionBcList[fusion_id] = {}
							fusionBcList[fusion_id][key] = value
							temp=fusionBcList[fusion_id][key]

						else:
							fusionBcList[fusion_id][key] = value

			# output
			with open(out_file, 'w') as f:
				f.write(','.join(header_values) + '\n')
				num = len(fusionList)
				count=0

				for fusion_id in fusionList:
					count = count + 1

					f.write(fusion_id)

					for key in key_list:
						if key in fusionBcList[fusion_id]:
							f.write(',' + fusionBcList[fusion_id][key])

						else:
							f.write(',' + '0.0')
					f.write('\n')

			return True
		except KeyError as err:
			Logger.error_both(f'Illegal Fusion ID: {err}')
			return False

	def _define_files_path(self, out_dir: str, prefix: str):
		self.__junction_matrix = path.join(out_dir, prefix + "_junction_matrix.csv")
		self.__spanning_matrix = path.join(out_dir, prefix + "_spanning_matrix.csv")
		self.__fusion_stats_file = path.join(out_dir, prefix + "_stats.csv")

	def _create_stats_header(self):

		headers = [
			'Barcode', 'Sample', 'Barcoded_Reads', 'No_of_Fusions'
		]

		return headers

