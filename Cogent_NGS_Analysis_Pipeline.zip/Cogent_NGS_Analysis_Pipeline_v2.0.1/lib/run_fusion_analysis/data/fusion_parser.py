#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to perform and handle gene expression counting.
# This class holds count stats for each barcode.
#

import csv

from common.logger import Logger
from analyze.data.count_stats import CountStats

class FusionParser:
	"""
	Handles fusion counts of all barcodes.
	Also having functions for reporting.
	"""


	# on initialize
	def __init__(self, key: str):
		"""Initialize function. Save passed parameters.

		Arguments:
			demux_counts {Dict[str, List]} -- Demuxed count dictionaly loaded from result file of demux sub command.

		"""
		self.__key = key

		self.__count_stats = CountStats(key)
		self.__num_fusions = -1

	# --- methods ---

	def add_fusion_count(self, file: str) -> bool:
		try:
			fusionList = []
			flag = 0
			count = 0
			with open(file) as f:
				f.readline()		# Skip header

				for line in f:
					count = count + 1
	                # for barcode with no fusion
					if count == 1 and not line:
						flag = 1
					else:
						values = line.rstrip().split('\t')
						if values[0] not in fusionList:
							fusionList.append(values[0])

			if flag == 0:
				self.__num_fusions = len(fusionList)
			elif flag == 1:
				self.__num_fusions = 0

		except:
			Logger.error_both(f'Failed to count number of detected fusions: {file}', self.__key)
			return False

		return True

	#--------------------------------------------------------------------------
	# region: For split mode

	def create_fusion_only_stats_record(self, key: str, out_file: str, sample_name: str, demux_count: int):
		with open(out_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')
			# data = [key, sample_name, str(demux_count), str(trim_count), str(self.__num_transcripts)]
			data = [key, sample_name, str(demux_count), str(self.__num_fusions)]
			writer.writerows([data])

	def create_matrix_by_junction(self, barcode: str, in_file: str, out_file: str):
		if out_file is None:
			return

		with open(in_file, 'r') as in_f, open(out_file, 'w') as out_f:
			writer = csv.writer(out_f, lineterminator = '\n')
			in_f.readline()		# Skip header

			# write header
			data = ['GeneFusion', barcode]
			writer.writerows([data])

			# Put fusion result into dictionsry
			juncList = []
			juncCountList = {}

			count = 0
			# write values (per fusion)
			for line in in_f:
				count = count + 1
				# for barcode with no fusion
				if count == 1 and not line:
					juncList.append("NoFusion")
					juncCountList["NoFusion"] = 0
				else:
					values = line.rstrip().split('\t')
					if values[0] not in juncList:
						juncList.append(values[0])
						juncCountList[values[0]] = 0
						juncCountList[values[0]] = int(values[1])
					else:
						juncCountList[values[0]] = juncCountList[values[0]] + int(values[1])

			# Output
			for item in juncList:
				data = [item, juncCountList[item]]
				writer.writerows([data])

	def create_matrix_by_spanning(self, barcode: str, in_file: str, out_file: str):
		if out_file is None:
			return

		with open(in_file, 'r') as in_f, open(out_file, 'w') as out_f:
			writer = csv.writer(out_f, lineterminator = '\n')
			in_f.readline()		# Skip header

			# write header
			data = ['GeneFusion', barcode]
			writer.writerows([data])

			# Put fusion result into dictionsry
			spanList = []
			spanCountList = {}

			count = 0
			# write values (per fusion)
			for line in in_f:
				count = count + 1
				# for barcode with no fusion
				if count == 1 and not line:
					spanList.append("NoFusion")
					spanCountList["NoFusion"] = 0
				else:
					values = line.rstrip().split('\t')
					if values[0] not in spanList:
						spanList.append(values[0])
						spanCountList[values[0]] = 0
						spanCountList[values[0]] = int(values[2])
					else:
						if int(values[2]) > spanCountList[values[0]]:
							spanCountList[values[0]] = int(values[2])

			# Output
			for item in spanList:
				data = [item, spanCountList[item]]
				writer.writerows([data])

	# endregion
	#--------------------------------------------------------------------------



