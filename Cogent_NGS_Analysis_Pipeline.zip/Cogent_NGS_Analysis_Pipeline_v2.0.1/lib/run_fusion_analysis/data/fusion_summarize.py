from datetime import datetime
from os import path
from common.analyze.base_summarize import BaseSummarize

from common.logger import Logger
from common.util.util import elapsed_time

from run_fusion_analysis.data.fusion_parser import FusionParser

class FusionSummarize(BaseSummarize):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def fusion_stats_file(self) -> str:
		return path.join(self.__work_dir, 'fusion_stats.txt')

	@property
	def junction_counts_file(self) -> str:
		return path.join(self.__work_dir, 'fusion_junction_counts.txt')

	@property
	def spanning_counts_file(self) -> str:
		return path.join(self.__work_dir, 'fusion_spanning_counts.txt')

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, key: str, work_dir: str):
		self.__key = key
		self.__work_dir = work_dir

	def create_summary_files(self, sample_name: str, input_reads: int, fusion_file: str) -> bool:

		start_time = datetime.now()
		parser = FusionParser(self.__key)
		parser.add_fusion_count(fusion_file)

		# output split results for barcode
		self._create_result_files(parser, sample_name, input_reads, fusion_file)
		Logger.info_logger("Successfully completed creating summary files. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def _create_result_files(self, parser: FusionParser, sample_name: str, input_count: int, fusion_file: str) -> bool:

		# stats
		parser.create_fusion_only_stats_record(self.__key, self.fusion_stats_file, sample_name, input_count)

		# matrix
		parser.create_matrix_by_junction(self.__key, fusion_file, self.junction_counts_file)
		parser.create_matrix_by_spanning(self.__key, fusion_file, self.spanning_counts_file)

		return True

