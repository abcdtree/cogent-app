from datetime import datetime
from glob import glob
import shutil
from typing import Dict, List
from common.cogent_error import CogentError
from common.config import Config

from common.logger import Logger
from common.util.util import elapsed_time, run_system_cmd
from os import mkdir, path, unlink

from common.util.const import FusionFilter

class StarFusion:

	# ---------------------------------
	# region: Property
	@property
	def result_file(self) -> str:
		# return path.join(self.__work_dir, 'star-fusion.preliminary/star-fusion.fusion_candidates.preliminary')
		return path.join(self.__work_dir, 'star-fusion.fusion_predictions.tsv')			# JS: Changed to use official output file. Test to tune parameters.

	# endregion: Property
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, fusion_path: str, cores_num: int, genome_dir: str, species: str, filter: FusionFilter):
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__fusion_path = fusion_path
		self.__cores_num = cores_num
		self.__genome_dir = path.join(genome_dir, Config.FUSION_INDEX_NAME)

		self.__filter_option = self.__select_option(filter)

		if not path.isdir(self.__work_dir):
			mkdir(self.__work_dir)

		self.__fusion_info = {}

		self.__modify_chr_name = False				# Flag to add "chr" to chromosome name
		if species == 'human':
			self.__modify_chr_name = True

	# Run command
	def run(self, chimeric_file: str) -> bool:

		# Setup files
		align_prefix = path.join(self.__work_dir, self.__key + ".")
		out_chimeric = align_prefix + "Chimeric.out.junction"						# Assume output chimeric file name

		########################################
		# add chr to Chimeric.out.junction file
		########################################

		input_file = out_chimeric + '.chr'

		try:
			with open (chimeric_file) as inp, open(input_file, 'w') as out:
				counter = 0
				check="Nreads 0"
				for line in inp:
					counter = counter + 1
					if counter == 1:
						out.write(line)
					elif counter > 1:
						if line.startswith('#'):
							if check in line:
								temp = "# Nreads 1	NreadsUnique 0	NreadsMulti 0"
								out.write(temp)
							else:
								out.write(line)
						else:
							chr_donorA, brkpt_donorA, strand_donorA, chr_acceptorB, brkpt_acceptorB, strand_acceptorB, junction_type, \
							repeat_left_lenA, repeat_right_lenB, read_name, start_alnA, cigar_alnA, start_alnB, cigar_alnB, num_chim_aln, \
							max_poss_aln_score, non_chim_aln_score, this_chim_aln_score, bestall_chim_aln_score, PEmerged_bool, readgrp = [item.strip() for item in line.split("\t")]

							if self.__modify_chr_name:
								if chr_donorA == 'MT':
									chr_donorA = 'chrM'
								else:
									chr_donorA = 'chr' + chr_donorA

								if chr_acceptorB == 'MT':
									chr_acceptorB = 'chrM'
								else:
									chr_acceptorB = 'chr' + chr_acceptorB

							outline = [chr_donorA, brkpt_donorA, strand_donorA, chr_acceptorB, brkpt_acceptorB, strand_acceptorB, junction_type, \
							repeat_left_lenA, repeat_right_lenB, read_name, start_alnA, cigar_alnA, start_alnB, cigar_alnB, num_chim_aln, \
							max_poss_aln_score, non_chim_aln_score, this_chim_aln_score, bestall_chim_aln_score, PEmerged_bool, readgrp]

							outline = "\t".join(outline) + "\n"
							out.write(outline)

		except EnvironmentError as err:
			raise CogentError("Unable to open chimeric file")

		start_time = datetime.now()
		Logger.info_logger("Started gene-fusion analysis with STAR-fusion", self.__key)

		# Setup files

		log_stdout = path.join(self.__log_dir, f'{self.__key}_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'{self.__key}_stderr.txt')

		# Common options
		# STAR-Fusion --genome_lib_dir CogentAP/genomes/hg38/fusion_index
    	#-J test_1/work/CCGTACGCCAGGACCA/CCGTACGCCAGGACCA.Chimeric.out.junction --output_dir test_1/work/CCGTACGCCAGGACCA/fusion

		command = [
			self.__fusion_path,
			'--genome_lib_dir', self.__genome_dir,
			'-J', input_file,
			'--CPU', str(self.__cores_num),
			'--output_dir', self.__work_dir
		]

		# Set filtering opton
		command.extend(self.__filter_option)

		command_str = ' '.join(command)
		Logger.info_logger("Launched STAR-Fusion using command: " + command_str, self.__key)
		if not run_system_cmd(command_str, log_stdout, log_stderr):
			return False

		self.__fusion_info = self.__get_fusion_info(self.result_file)

		Logger.info_logger("Successfully completed fusion-level counting. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

#	def create_fusion_info_file(self, gtf_file: str, out_file: str) -> Union[str, None]:

	def remove_temp_files(self) -> bool:
		try:
			shutil.rmtree(path.join(self.__work_dir, '_starF_checkpoints'))
			shutil.rmtree(path.join(self.__work_dir, 'star-fusion.preliminary'))

			unlink(path.join(self.__work_dir, f'{self.__key}.Chimeric.out.junction.chr'))
			unlink(path.join(self.__work_dir, 'star-fusion.fusion_predictions.abridged.tsv'))
			unlink(path.join(self.__work_dir, 'star-fusion.fusion_predictions.tsv'))

			files = glob(f'{self.__work_dir}/pipeliner.*.cmds')
			for f in files:
				unlink(f)
		except:
			Logger.error_both(f'Failed to remove temporary files of fusion for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_stdout.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of fusion for {self.__key}', self.__key)
			return False

		return True

	def __get_fusion_info(self, result_file: str) -> Dict[str, str]:
		fusion_info = {}
		try:
			Logger.info_logger(f'Start loading fusion IDs from {result_file}', self.__key)
			with open(result_file) as f:
				f.readline()
				for line in f:
					values = line.rstrip().split('\t')
					fusion_info[values[0]] = values[1]		# Note: 1 = JunctionReadCount, 2 = SpanningFragCount
		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + result_file + "\n" + str(err))

		return fusion_info

	def __select_option(self, filter: FusionFilter) -> List[str]:
		if filter is FusionFilter.STAR_FUSION_DEFAULT:
			return []
		elif filter is FusionFilter.MAX_SENSITIVE:
			return ['--max_sensitivity']
		elif filter is FusionFilter.NO_RT_ARTIFACT:
			return ['--max_sensitivity', '--no_RT_artifact_filter']
		elif filter is FusionFilter.FULL_MONTY:
			return ['--full_Monty']
		elif filter is FusionFilter.NO_FILTER:
			return ['--no_filter', '--skip_FFPM', '--no_annotation_filter', '--no_RT_artifact_filter', '--skip_EM']
		else:
			return ['--max_sensitivity']

