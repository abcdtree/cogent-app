from datetime import datetime
import shutil
from typing import Dict, List, Union
from common.cogent_error import CogentError
from common.config import Config

from common.logger import Logger
from common.util.const import StrandedMode
from common.util.util import elapsed_time, run_system_cmd
from os import mkdir, path, unlink

class Rsem:

	EM_ERROR_MESSAGE = 'No valid read to estimate the length distribution!'

	# ---------------------------------
	# region: Property
	@property
	def COMMON_PARAMS(self) -> List[str]:
		return [
			'--estimate-rspd'
			]

	# @property
	# def ENCODE_PARAMS(self) -> List[str]:
	# 	return [
	# 		'--estimate-rspd',
	# 		'--calc-ci',
	# 		'--no-bam-output',
	# 		'--seed', '12345',
	# 		'--ci-memory', '5120'
	# 		]

	@property
	def result_file(self) -> Union[str, None]:
		if self.__exist_result:
			return path.join(self.__work_dir, self.__key + '.isoforms.results')
		else:
			return None

	# endregion: Property
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, rsem_path: str, cores_num: int, genome_dir: str, genome_name: str):
		self.__key = key
		self.__work_dir = work_dir
		self.__sample_name = path.join(self.__work_dir, key)
		self.__log_dir = log_dir
		self.__rsem_path = rsem_path
		self.__cores_num = cores_num

		self.__genome_index = path.join(genome_dir, Config.RSEM_INDEX_NAME, genome_name)
		self.__transcript_info = {}

		self.__exist_result = True

		if not path.isdir(self.__work_dir):
			mkdir(self.__work_dir)

	# Run command
	def run(self, bam_file: str, is_paired: bool, stranded_mode: StrandedMode) -> bool:

		start_time = datetime.now()
		Logger.info_logger("Started transcript expression counting with RSEM", self.__key)

		log_stdout = path.join(self.__log_dir, f'{self.__key}_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'{self.__key}_stderr.txt')

		# Common options
		command = [
			self.__rsem_path,
			'-p', str(self.__cores_num),
			'--bam', bam_file
		]
		command += self.COMMON_PARAMS

		if is_paired:
			command += ['--paired-end']

		if stranded_mode is StrandedMode.FORWARD:
			command += ['--forward-prob', '1.0']
		elif stranded_mode is StrandedMode.REVERSE:
			command += ['--forward-prob', '0.0']

		command += [self.__genome_index, self.__sample_name]

		command_str = ' '.join(command)
		Logger.info_logger("Launched RSEM using command: " + command_str, self.__key)

		res = run_system_cmd(command_str, log_stdout, log_stderr, suppress_error_message=True)
		if not res:
			if self.__judge_em_error(log_stderr):					# Check if error is because of estimation for read length
				error_message = f'Failed to estimate length distribution. All expression values are set as 0 for this barcode. [{self.__key}]'
				Logger.warning_logger(error_message, self.__key)	# Output to console and log for this barcode
				Logger.warning_logger(error_message)				# Output to global log file
				self.__exist_result = False
			else:
				Logger.error_logger(f'Unexpected error when launching RSEM: {command_str}')
				return False

		Logger.info_logger("Successfully completed transcript-level counting. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def create_transcript_info_file(self, gtf_file: str, out_file: Union[str, None]):

		if out_file is None:
			raise CogentError('Unable to detect output file for transcript information.', 'create_transcript_info_file')

		if not self.result_file is None:
			self.__transcript_info = self.__get_transcript_info(self.result_file)

		try:
			with open (gtf_file) as inp, open(out_file, 'w') as out:
				out.write(','.join(['Transcript_ID', 'Ensembl_ID', 'Transcript_Name', 'Gene_ID', 'Gene_Name', 'Transcript_Biotype', 'Transcript_Length']) + '\n')
				prev = 'NA'
				for line in inp:
					#Skip header lines
					if line.startswith('#'):
						continue

					values = line.rstrip().split('\t')
					if (values[2] != 'transcript'):
						continue

					# Process gtf line
					annot = str(line.rstrip().split("\t")[8]).split(";")
					gene_id = ""
					gene_name = ""
					transcript_id = ''
					transcript_name = ''
					transcript_type = ""

					for i in range(0, len(annot)):
						entry = annot[i]
						if "gene_id" in entry:
							gene_id = entry.split('"')[1]
						if "gene_name" in entry:
							gene_name = entry.split('"')[1]
						if 'transcript_id' in entry:
							transcript_id = entry.split('"')[1]
						if 'transcript_name' in entry:
							transcript_name = entry.split('"')[1]
						if "transcript_biotype" in entry:
							transcript_type = entry.split('"')[1]

					if transcript_id == prev:
						continue
					prev = transcript_id

					if transcript_id == '':
						continue

					if transcript_id in self.__transcript_info:
						out.write(','.join([
							transcript_id + '_' + transcript_name,
							transcript_id, transcript_name,
							gene_id, gene_name,
							transcript_type, self.__transcript_info[transcript_id]]) + '\n')
					else:
						out.write(','.join([
							transcript_id + '_' + transcript_name,
							transcript_id, transcript_name,
							gene_id, gene_name,
							transcript_type, str(1)]) + '\n')

		except EnvironmentError as err:
			raise CogentError(f"Unable to open files: {gtf_file}, {out_file}", 'create_transcript_info_file')

	def remove_temp_files(self) -> bool:
		try:
			shutil.rmtree(path.join(self.__work_dir, f'{self.__key}.stat'))

			if self.__exist_result:
				unlink(path.join(self.__work_dir, f'{self.__key}.genes.results'))
				unlink(path.join(self.__work_dir, f'{self.__key}.isoforms.results'))
				unlink(path.join(self.__work_dir, f'{self.__key}.transcript.bam'))
			else:
				shutil.rmtree(path.join(self.__work_dir, f'{self.__key}.temp'))
		except:
			Logger.error_both(f'Failed to remove temporary files of RSEM for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_stdout.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of RSEM for {self.__key}', self.__key)
			return False

		return True

	def __get_transcript_info(self, result_file: str) -> Dict[str, str]:
		transcript_info = {}
		try:
			Logger.info_logger(f'Start loading transcript ID and length from {result_file}', self.__key)
			with open(result_file) as f:
				f.readline()
				for line in f:
					values = line.rstrip().split('\t')
					transcript_info[values[0]] = values[2]		# Note: 2 = Length, 3 = effective_length
		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + result_file + "\n" + str(err))

		return transcript_info

	def __judge_em_error(self, error_file: str) -> bool:
		with open(error_file, 'r') as f:
			for line in f:
				if line.strip() == self.EM_ERROR_MESSAGE:
					return True

		return False

