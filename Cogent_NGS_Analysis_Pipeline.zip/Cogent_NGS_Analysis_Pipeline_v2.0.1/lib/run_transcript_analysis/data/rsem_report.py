from datetime import datetime
from os import path
import os
import shutil
from typing import Dict, List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.experiment.experiment import Experiment
from common.util.analyze import AnalyzeStats, create_analyze_stats_header
from common.util.util import elapsed_time, load_csv_as_dict
from common.analyze.base_report import BaseReport
from run_transcript_analysis.data.rsem_summarize import RsemSummarize

class RsemReport(BaseReport):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def stats_file(self) -> Union[str, None]:
		if self.__create_stats:
			return self.__transcript_stats_file
		else:
			return None

	@property
	def matrix(self) -> str:
		return self.__transcript_matrix

	@property
	def info_file(self) -> str:
		return self.__transcript_info_file

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, output_dir: str, prefix: str, experiment: Experiment, create_stats: bool, stats: Dict[str, AnalyzeStats] = None):

		self.__out_dir = output_dir
		self.__experiment = experiment

		self.__create_stats = create_stats
		self.__analyze_stats = stats

		# Define file names
		self._define_files_path(output_dir, prefix)

	def create(self, key_list: List[str], result_objects: Dict[str, RsemSummarize], transcript_info_file: str):

		# Create result files
		Logger.info_logger('Started creating transcript report files, matrix files and stats files.')
		start_time = datetime.now()

		# stats
		if self.__create_stats:
			if self.__analyze_stats is None:
				raise CogentError('Cannot detect stats from analyze command', 'create')

			self._merge_stats(key_list, {key:item.transcript_stats_file for key, item in result_objects.items()}, self.__transcript_stats_file, summary=self.__analyze_stats)

		# transcript matrix
		transcript_info = load_csv_as_dict(transcript_info_file, key_col=1, skip_header=True)
		self._merge_matrix('TranscriptID', key_list, transcript_info, {key:item.transcript_counts_file for key, item in result_objects.items()}, self.__transcript_matrix)

		# Move gene info files to certain directory
		self.__transcript_info_file = shutil.move(transcript_info_file, self.__out_dir)		# Move info file to output directory

		Logger.info_logger("Successfully completed reporting for transcript expression. Time elapsed: " + elapsed_time(start_time))

	def _define_files_path(self, out_dir: str, prefix: str):
		self.__transcript_matrix = path.join(out_dir, prefix + "_transcript_matrix.csv")
		self.__transcript_stats_file = path.join(out_dir, prefix + "_transcript_stats.csv")

	def _create_stats_header(self):
		# return create_analyze_stats_header(self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded, True, False)
		return create_analyze_stats_header(False, False, self.__experiment.is_stranded, True, False)		# Do not support UMI so far


