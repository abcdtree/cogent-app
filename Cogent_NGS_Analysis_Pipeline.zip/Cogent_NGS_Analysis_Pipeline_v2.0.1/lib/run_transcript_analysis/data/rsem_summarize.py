from datetime import datetime
from os import path
from typing import Union
from analyze.data.expression_parser import ExpressionParser
from common.analyze.base_summarize import BaseSummarize

from common.cogent_error import CogentError

from common.logger import Logger
from common.util.analyze import AnalyzeStats
from common.util.util import elapsed_time

class RsemSummarize(BaseSummarize):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def transcript_stats_file(self) -> str:
		return path.join(self.__work_dir, 'transcript_stats.txt')

	@property
	def transcript_counts_file(self) -> str:
		return path.join(self.__work_dir, 'transcript_counts.txt')

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, key: str, work_dir: str, create_stats: bool, stats: AnalyzeStats = None):
		self.__key = key
		self.__work_dir = work_dir

		self.__create_stats = create_stats
		self.__analyze_stats = stats

	def create_summary_files(self, transcript_file: Union[str, None], is_use_umi: bool, is_use_uss: bool, is_stranded: bool) -> bool:

		start_time = datetime.now()
		parser = ExpressionParser(self.__key, is_use_umi, is_use_uss, is_stranded, True)

		if self.__create_stats:
			res = parser.add_transcript_count(transcript_file)
			if not res:
				return False

		# output split results for barcode
		self._create_result_files(parser, transcript_file)
		Logger.info_logger("Successfully completed creating summary files for transcripts. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def _create_result_files(self, parser: ExpressionParser, transcript_file: Union[str, None]) -> bool:

		# stats
		if self.__create_stats:
			if self.__analyze_stats is None:
				raise CogentError('Cannot detect stats from analyze command', '_create_result_files')

			parser.create_trans_stats_record(self.__key, self.transcript_stats_file, self.__analyze_stats)

		# matrix
		parser.create_matrix_by_transcript(self.__key, transcript_file, self.transcript_counts_file)

		return True

