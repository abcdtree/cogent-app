from datetime import datetime
import os
import shutil
from typing import Dict, Tuple, Union
from os import path, unlink
from run_transcript_analysis.tools.rsem import Rsem

from common.analyze.base_processor import BaseProcessor

from common.cogent_error import CogentError
from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.analyze import AnalyzeStats
from common.util.const import DebugMode
from common.util.util import elapsed_time
from run_transcript_analysis.data.rsem_summarize import RsemSummarize

class RsemProcessor(BaseProcessor):

	@property
	def results(self) -> Dict[str, RsemSummarize]:
		return self._results

	@property
	def transcript_info_file(self) -> str:
		return self.__transcript_info_file

	# Initialize
	def __init__(self, threads_num: int, cores_num: int, experiment: Experiment, work_dir: str, logs_dir: str, config_dir: str, default_configs, genome_used: str,
				debug_mode: DebugMode):

		super().__init__(threads_num, cores_num, experiment, logs_dir, config_dir, default_configs, genome_used)

		self.__experiment = experiment				# Experiment type
		self.__debug_mode = debug_mode

		self.__gtf_path = default_configs[Config.GENOME_CONFIG_KEY + genome_used][1]

		self.__work_dir_root = work_dir
		self.__logs_dir_root = logs_dir

		self.__transcript_info_file = path.join(self.__work_dir_root, 'transcript_info.csv')

	# Impl of abstract method
	def _work_per_barcode(self, pid: int, key: str, bam_file: tuple, res_dict: Dict[str, RsemSummarize], stats: AnalyzeStats) -> bool:

		start_time = datetime.now()

		# ---------- Setup for this key ---------- #
		work_dir = path.join(self.__work_dir_root, key)
		Logger.add_logger(key, path.join(self.__logs_dir_root, f'{key}_log.txt'))
		Logger.info_logger(f'Started processing for {key}.', key)

		try:
			os.makedirs(work_dir)		# Create sub-folder
		except OSError as err:
			raise CogentError(f'Unable to create directory: {work_dir}')

		# ---------- Transcript counting ---------- #
		rsem = self._rsem(key, work_dir, bam_file[0], self.__experiment.is_paired, self.__experiment.stranded_mode)
		if rsem is None:
			Logger.error_both(f'Failed RSEM for {key}')
			return False

		# ---------- Summarize ---------- #
		summarize = RsemSummarize(key, work_dir, True, stats)
		# summarize.create_summary_files(rsem.result_file, self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded)
		summarize.create_summary_files(rsem.result_file, False, False, self.__experiment.is_stranded)		# Do not support UMI so far.

		# ---------- Generate transcript info file ---------- #
		self.__create_info_files(key, work_dir, rsem)

		# ---------- Clean working directory (first time) ---------- #
		if self.__debug_mode is DebugMode.NONE:
			self._clean_work_dir(False, rsem=rsem)
		elif self.__debug_mode is DebugMode.MODERATE:
			self._clean_work_dir(True, rsem=rsem)

		# Keep summarized class for return
		res_dict[key] = summarize

		Logger.info_logger(f'Finished processing. Elapsed time: ' + elapsed_time(start_time), key)		# For an independent log file
		Logger.info_logger(f'Finished processing for {key} in ' + elapsed_time(start_time))				# For main log file

		return True

	# ---------------------------------
	# region: Internal function
	def __create_info_files(self, key: str, work_dir: str, trans: Union[Rsem, None]):

		# ----------
		# Transcript
		if not trans is None and not self.__transcript_info_file is None:
			if not path.isfile(self.__transcript_info_file) and not trans.result_file is None:				# Check if already created by other process
				Logger.info_logger('Generate the transcript information file for use in CogentDS', key)

				# Create temporary file in each working directory
				temp_file = f'{work_dir}/temp_transcript_info.csv'
				trans.create_transcript_info_file(self.__gtf_path, temp_file)

				# Copy the file if possible
				if not path.isfile(self.__transcript_info_file):					# Check file exists again
					shutil.copyfile(temp_file, self.__transcript_info_file)
					Logger.info_logger(f'Generated the transcript information file for use in CogentDS in the process for {key}')

				# Remove temp file
				unlink(temp_file)

	# endregion: Internal function
	# ---------------------------------