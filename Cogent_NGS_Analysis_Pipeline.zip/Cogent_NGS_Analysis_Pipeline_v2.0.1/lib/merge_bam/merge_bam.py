#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# ....
#

# -----------------------------------------------------------------------------
# region: Script Info

SCRIPT_NAME = "merge_bam"
MAIN_DESC = """
	Perform BAM file merging according to input file and group.
	"""

# Do not put indent, because it affects for output.
SUB_DESC="""
description:
  A command to merge bam files according to custom groups.
  The input to this command is either CSV or TSV contains barcode and any columns.
  This command performs file merging by specified column name in input file.
  BAM files are merged by names described in the column and corresponding barcodes.
"""
# endregion
# -----------------------------------------------------------------------------

# ---------- import modules ---------- #

from os import path
from os.path import isdir, isfile
import shutil
import sys
import os
import multiprocessing
from typing import List
from analyze.tools.bam_merger import BamMerger

from common.cogent_error import CogentError

from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import  DebugMode

# -----------------------------------------------------------------------------
# region: Function

# Check all input requirements
def check_requirements(user_args) -> bool:

	res = True

	# Check if number of threads requested is available
	Logger.info_logger(f'Detected number of CPUs: {multiprocessing.cpu_count()}')
	if multiprocessing.cpu_count() < user_args.cores_num:
		Logger.info_logger(f'Input number of cores is {user_args.cores_num}. It exceeds installed number of CPUs.')
		user_args.cores_num = multiprocessing.cpu_count()

		Logger.info_logger(f'Changed number of cores as {user_args.cores_num}.')

	# Check if input file exists
	if not isfile(user_args.input_file):
		Logger.error_both(f'Input file does not exist. {user_args.input_file}')
		res = False

	# Check if input path (directory) exists
	if not isdir(user_args.input_dir):
		Logger.error_both(f'Input directory does not exist. {user_args.input_dir}')
		res = False
	else:
		# Check if bam directory is inside
		if not isdir(f'{user_args.input_dir}/bam'):
			Logger.error_both(f'bam directory does not exist in {user_args.input_dir}.')
			res = False

	return res

def clean_work_dir(work_dir: str, key_list: List[str], debug_mode: DebugMode) -> bool:
	try:
		if debug_mode is DebugMode.NONE:					# Remove all files and directories
			shutil.rmtree(work_dir)
		else:
			for key in key_list:
				shutil.rmtree(path.join(work_dir, key))		# Remove only working directory per barcode

		return True
	except:
		Logger.error_both('Failed to clean working directory')
		return False

def adjust_threads(user_args, samples_num: int):
	if user_args.threads_num > samples_num:
		total_num = user_args.threads_num * user_args.cores_num
		user_args.threads_num = samples_num
		user_args.cores_num = int(total_num / user_args.threads_num)
		Logger.info_logger(f'Number of threads exceeds the number of input samples. Adjusted number of threads as {user_args.threads_num } and cores as {user_args.cores_num}.')

# endregion: Function
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# region: Main Function
def run(user_args, default_configs, first_log: str):

	# ---------- setup | parse/check user options ---------- #

	# ---------- setup | output directory ---------- #
	if path.isdir(user_args.out_dir):
		print(f'Error: Output dir already exists: {user_args.out_dir}', file=sys.stderr)
		return False
	else:
		# Create require directories
		target_dir = None
		try:
			target_dir = user_args.out_dir
			os.makedirs(target_dir)
		except OSError as err:
			print(f'Unable to create directory: {target_dir}', file=sys.stderr)
			return False

	# ---------- setup | logger ---------- #
	Logger.initialize(SCRIPT_NAME, path.join(user_args.out_dir, f'{SCRIPT_NAME}.log'))
	Logger.info_logger(first_log)
	Logger.info_logger("Command name: " + SCRIPT_NAME)
	Logger.info_logger("Original call : " + " ".join(sys.argv))

	# ---------- setup | check requirement ---------- #
	if not check_requirements(user_args):
		return False

	# ---------- setup | define local resources ---------- #
	# Write config to log
	tmp_conf = ""
	for k,v in default_configs.items():
		tmp_conf = tmp_conf + "  --" + str(k) + "," + ",".join([str(vl) for vl in v]) + "\n"
	Logger.info_logger("Configs loaded as: \n" + tmp_conf)

	try:
		merger = BamMerger(user_args.cores_num, default_configs)
		res = merger.merge_by_list(user_args.input_file, user_args.target_column, user_args.input_dir, user_args.out_dir)
		if not res:
			return False

	except CogentError as e:
		if e.function is None:
			Logger.error_both(f'{e.message}')
		else:
			Logger.error_both(f'{e.message} (at {e.function})')

		return False

	return True

# #endregion
# -----------------------------------------------------------------------------