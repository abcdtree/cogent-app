#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Functions to define arguments for all sub commands.
#

import argparse
from typing import List

from common.util.const import BamKeepMode, DebugMode
from common.util.const import FusionFilter

# -----
# Global arguments
def prepare_cogent(parser):
	parser.add_argument('-v', '--version', dest='show_version', action='store_true',
						help='Show version number', default=False)

# -----
# For demux command
def prepare_demux(required, optional, experiment_names: List[str]):
	# add required arguments
	required.add_argument('-i', '--input_fastq', dest = 'r1_file',
						help = 'Input Read1 (R1) FASTQ file.', required = True)

	required.add_argument('-b', '--barcodes_file', dest = 'bcs_file',
						help = "Well List file from Takara's CellSelect Software (Recommended), or custom Barcodes "
								"File (see User Manual @ https://takarabiousa.github.io for details).",
						required = True)

	required.add_argument('-t', '--type_of_experiment', dest = 'type_exp',
						help = 'Experimental protocol used.',
						choices = experiment_names, required = True)

	required.add_argument('-o', '--output_dir',	dest = 'out_dir',
						help = 'Name of output directory to store results.', required = True)

	# add optional arguments
	required.add_argument('-p', '--paired_fastq', dest = 'r2_file',
						help = 'Input Read2 (R2) FASTQ file.', default = None)

	optional.add_argument('--no_split_fastqs', dest = 'split_fastq',
						action = 'store_false', default = True,
						help = 'Output merged FASTQ file(s). Barcodes are written into read names and merged into large FASTQ file. By default output into barcode-level FASTQ files.')

	optional.add_argument('-m', '--mismatch', dest = 'mismatch',
						help = 'Number of allowed mismatched bases per barcode [Default: 1].', choices = [0, 1], default = 1, type = int)

	optional.add_argument('-w', '--all_well_barcodes_file', dest = 'background_barcodes_file',
						help = 'Barcodes file used to calculate background contamination from unselected barcodes. '
							'This file is built-in for standard protocols (defined by option `-t`), but can be '
							'customized for rare cases where a custom chip or barcode set is used.',
						default = None)

	optional.add_argument('-u', '--umi_length', dest = 'umi_len',
						help = 'Overwrite UMI length. Default length is automatically detected by experiment type. [Default: None].', default = None, type = int)

	optional.add_argument('-n', '--n_processes', dest = 'n_processes',
						help = 'Number of demultiplexing (worker) processes to spawn during execution [Default: 16].', default = 16, type = int)

	optional.add_argument('--n_writers', dest = 'n_writers',
						help = 'Number of writing processes to spawn during execution [Default: 1].', default = 1, type = int)

	optional.add_argument('--no_gz', dest = 'gzip', action = "store_false", default = True,
						help = "Do not compress (gzip) output FASTQ files.")

	optional.add_argument('--undetermined_fq', dest = 'und_fq',
						action = 'store_true', default = False,
						help = 'Save Undetermined/Unselected/Short reads to Undetermined FASTQ files.')

	optional.add_argument('--i7_rc', dest = 'i7_rc',
						help = 'Reverse-complement I7 Index (Full Length protocol only). Enter "Auto" to detect and '
							'auto-correct the reverse complementation of I5/I7 indices by certain Illumina '
							'sequencers. Otherwise manually override with "True" or "False" [Default: "Auto"].',
						choices = ["Auto", "True", "False"], default = "Auto")

	optional.add_argument('--i5_rc', dest = 'i5_rc',
						help = "See help section for `--i7_rc`.", choices = ["Auto", "True", "False"], default = "Auto")

	optional.add_argument('--read_buffer', dest = 'read_buffer',
						help = 'Buffer size of data sent to each demultiplexing (worker) process in GB [Default: 0.01].',
						default = 0.01, type = float)

	optional.add_argument('--hpc', dest = 'hpc_mode', action = "store_true",
						help = 'Work as high performance computing mode. To use this option, changing file descriptors (ulimit -n) as unlimited is recommended.',
						default = False)

	optional.add_argument('--prog', dest = 'prog', type = int,
						help = "Number of reads to process before updating status in log file [Default 10,000,000].",
						default = 10000000)

	optional.add_argument('-z', '--z_type_internal_use_only', dest = 'z_type',
						help = argparse.SUPPRESS, default = None)

	optional.add_argument('--debug', dest = 'debug', action = "store_true",
						help = argparse.SUPPRESS, default = None)

	optional.add_argument('--pigz_loc', dest = 'pigz_loc',
						help = argparse.SUPPRESS, default = "")

# -----
# For analyze command
def prepare_analyze(required, optional, experiment_names: List[str], genome_choices: List[str]):
	#Add the required arguments
	required.add_argument('-g', '--genome', dest='genome_used',
						help='Choose from pre-built "hg38" or the name of custom genome that you created', required=True, choices=genome_choices)

	required.add_argument('-o', '--output_dir', dest='out_dir',
						help = 'An output directory to be created to store results', required = True)

	required.add_argument('-t', '--type_of_experiment', dest = 'type_exp',
						help ='Experimental protocol used', choices = experiment_names, required = True)

	# required.add_argument('-d', '--demux_counts', dest='demux_counts',
	# 					help = 'Use counts file from demux script output (*_counts_all.csv). ', required = True)

	required.add_argument('-i', '--input', dest = 'input',
						help = 'Directory contains results from demux command. The directory must contain FASTQ files after demultiplexing.', required = True)

	#Add the optional arguments
	# optional.add_argument('-p', '--paired_fastq', dest='r2_file',
	# 					help='De-muxed read2 (R2) fastq file', default=None)

	optional.add_argument('--threads', dest='threads_num',
						help='Number of processes to spawn during execution [Default: 16]', default=16, type=int)

	optional.add_argument('--cores', dest='cores_num',
						help='Number of cores used for each step. [Default: 1]', default=1, type=int)

	# optional.add_argument('--normalize', dest='type_norm',
	# 					help='Type of normalization desired [Default: cpm]', choices=['cpm', 'tpm', 'fpkm'], default='cpm')

	optional.add_argument('--skip_trimming', dest='skip_trim', action = 'store_true',
						help = 'Using this argument will skip trim reads for adapters [Default: FALSE]', default=False)

	# optional.add_argument('--debug', dest = 'is_debug', action = 'store_true',
	# 					help = 'Using this argument will stop file cleanup and keep all temporary files [Default: FALSE]', default=False)

	optional.add_argument('--transcript', dest='do_transcript', action = 'store_true',
						help = 'Generate transcript expression matrix [Default: FALSE]', default=False)

	optional.add_argument('--immune', dest='do_immune', action = 'store_true',
						help = 'Generate immune profiling matrix [Default: FALSE]', default=False)

	optional.add_argument('--fusion', dest='do_fusion', action = 'store_true',
						help = 'Generate gene fusion matrix [Default: FALSE]', default=False)

	optional.add_argument('--debug', dest = 'debug_mode',
						help = "Specify debug mode. [Default: moderate]",
						default = 'moderate', choices = DebugMode.to_list())

	# Hidden option
	optional.add_argument('--star_params', dest = 'star_params',
						help = argparse.SUPPRESS, default=None)

	optional.add_argument('--bam', dest = 'keep_bam', help =  argparse.SUPPRESS,
						default = 'each', choices = BamKeepMode.to_list())

# -----
# For add_genome command
def prepare_add_genome(required, optional):
	#Add the required arguments
	required.add_argument('-g', '--genome_name', dest='g_name',
						help='Provide a name for the genome', required=True)
	required.add_argument('-f', '--fasta_sequences', dest='g_fa',
						help='FASTA file with sequences of all chromosomes (.gz OK)', required=True)
	required.add_argument('-a', '--annotation_gtf', dest='g_gtf',
						help='GTF file with annotation (.gz OK)', required=True)

	#Add the optional arguments
	optional.add_argument('-n', '--n_threads',  dest='n_threads',
			help='Number of thread to use [Default: 8]',
			default=8, type=int)
	optional.add_argument('-r', '--replace_existing', dest='repl',
			action = 'store_true', help='Use this to replace an existing genome')
	optional.add_argument('--limitGenomeGenerateRAM', dest='limit_genome_generate_ram',
			help="RAM size for STAR's genomeGenerate command. This can be used when memory error is caused, otherwise do not need to change.",
			default=31000000000, type=int)
	optional.add_argument('-m', '--mitochondria_name', dest='mito_name',
			help='Chromosome name for mitochondria to create mitochondria info file.',
			default='MT', type=str)

# -----
# For new command
def prepare_run_transcript_analysis(required, optional, experiment_names: List[str], genome_choices: List[str]):
	#Add the required arguments
	required.add_argument('-g', '--genome', dest='genome_used',
						help='Choose from pre-built "hg38" or the name of custom genome that you created', required=True, choices=genome_choices)

	required.add_argument('-o', '--output_dir', dest='out_dir',
						help = 'An output directory to be created to store results', required = True)

	required.add_argument('-t', '--type_of_experiment', dest = 'type_exp',
						help ='Experimental protocol used', choices = experiment_names, required = True)

	required.add_argument('-i', '--input_dir', dest = 'input_dir',
						help = 'Directory contains results from analyze command. The directory must contain BAM files (*.Aligned.toTranscriptome.out.bam) and *_stats.csv.', required = True)

	optional.add_argument('--threads', dest='threads_num',
						help='Number of processes to spawn during execution [Default: 16]. ', default=16, type=int)

	optional.add_argument('--cores', dest='cores_num',
						help='Number of cores used for each step. [Default: 1]', default=1, type=int)

	optional.add_argument('--debug', dest = 'debug_mode',
						help = "Specify debug mode. [Default: moderate]",
						default = 'moderate', choices = DebugMode.to_list())

# -----
# For new command -- fusion
def prepare_run_fusion_analysis(required, optional, experiment_names: List[str], genome_choices: List[str]):
	#Add the required arguments
	required.add_argument('-g', '--genome', dest='genome_used',
						help='Choose from pre-built "hg38" or "mm10". Other custom genome builds are not supported.', required=True, choices=genome_choices)

	required.add_argument('-o', '--output_dir', dest='out_dir',
						help = 'An output directory to be created to store results', required = True)

	required.add_argument('-t', '--type_of_experiment', dest = 'type_exp',
						help ='Experimental protocol used', choices = experiment_names, required = True)

	required.add_argument('-i', '--input_dir', dest = 'input_dir',
						help = 'Directory contains results from analyze command. The directory must contain genematrix, *_stats.csv and chimeric files (*.Chimeric.out.junction).', required = True)

	# required.add_argument('-b', '--bam_dir', dest = 'bam_dir',
	# 					help = 'Directory contains chimeric files (*.Chimeric.out.junction) per each barcode. Output directory', required = True)

	# required.add_argument('-d', '--demux_counts', dest = 'demux_counts_file',
	# 					help = 'Use counts file from demux script output (*_counts_all.csv). ', required = True)

	optional.add_argument('-f', dest = 'filter',
						help = "Specify stringency of filtering from 0 to 4. 0 is most stringent and 4 is most lenient. [Default: 1]",
						default = 'max_sensitive', choices = FusionFilter.to_list())

	optional.add_argument('--threads', dest='threads_num',
						help='Number of processes to spawn during execution [Default: 16]. ', default=16, type=int)

	optional.add_argument('--cores', dest='cores_num',
						help='Number of cores used for each step. [Default: 1]', default=1, type=int)

	optional.add_argument('--debug', dest = 'debug_mode',
						help = "Specify debug mode. [Default: moderate]",
						default = 'moderate', choices = DebugMode.to_list()
						)

# -----
# For immune command
def prepare_run_immune_analysis(required, optional, experiment_names: List[str], genome_choices: List[str]):
	#Add the required arguments
	required.add_argument('-g', '--genome', dest='genome_used',
						help='Choose from pre-built "hg38" or "mm10". Other custom genome builds are not supported.', required=True, choices=genome_choices)

	required.add_argument('-o', '--output_dir', dest='out_dir',
						help = 'An output directory to be created to store results', required = True)

	required.add_argument('-t', '--type_of_experiment', dest = 'type_exp',
						help ='Experimental protocol used', choices = experiment_names, required = True)

	required.add_argument('-i', '--input_dir', dest = 'input_dir',
						help = 'Directory contains results from demux command. The directory must contain FASTQ files after demultiplexing.', required = True)

	required.add_argument('-a', '--analyze_dir', dest = 'analyze_dir',
						help = 'Directory contains results from analyze command. The directory must contain genematrix and *_stats.csv.', required = True)

	optional.add_argument('--threads', dest='threads_num',
						help='Number of processes to spawn during execution [Default: 16]. ', default=16, type=int)

	optional.add_argument('--cores', dest='cores_num',
						help='Number of cores used for each step. [Default: 1]', default=1, type=int)

	optional.add_argument('--debug', dest = 'debug_mode',
						help = "Specify debug mode. [Default: moderate]",
						default = 'moderate', choices = DebugMode.to_list()
						)

# For merge_bam command
def prepare_merge_bam(required, optional):
	#Add the required arguments
	required.add_argument('-f', '--file', dest='input_file',
						help='A list including "Barcode" and a target column specified by -c option. Either CSV or TSV is acceptable.', required=True)

	required.add_argument('-c', '--column', dest='target_column',
						help = 'Column name used to create groups for merging.', required = True)

	required.add_argument('-i', '--input_dir', dest = 'input_dir',
						help = 'Directory contains results from analyze command. The directory must contain "bam" directory and BAM files (*.Aligned.out.bam).', required = True)

	required.add_argument('-o', '--output_dir', dest='out_dir',
						help = 'An output directory to be created to store results', required = True)

	optional.add_argument('-n', '--n_cores', dest = 'cores_num',
						help = 'Number of cores used during merging [Default: 8].', default = 8, type = int)
