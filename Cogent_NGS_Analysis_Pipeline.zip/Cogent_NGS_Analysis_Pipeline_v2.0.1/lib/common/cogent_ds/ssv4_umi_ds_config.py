#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to specify ICELL8 Full length analysis
#
# Required:
#	-

from os import path
from typing import Dict, List, Set
from common.cogent_ds.ds_config_meta import DsConfigMeta
from common.util.const import AnalysisType

class SSv4UmiDsConfig(DsConfigMeta):

	# ---------------------------------
	# region: Property
	@property
	def keys(self) -> Set[str]:
		return set(['all', '5pUMI'])

	@property
	def gene_matrices(self) -> Dict[str, str]:
		return {
			'all': '_all_genematrix.csv',
			'5pUMI': '_5pUMI_umi_genematrix.csv'
		}

	@property
	def stats_files(self) -> Dict[str, str]:
		return {
			'all': '_all_stats.csv',
			'5pUMI': '_5pUMI_stats.csv'
		}

	@property
	def additional_analysis(self) -> Dict[str, List[AnalysisType]]:
		return {
			'all': [AnalysisType.TRANSCRIPT, AnalysisType.FUSION, AnalysisType.IMMUNE],
			'5pUMI': []
		}

	# endregion: Property
	# ---------------------------------
