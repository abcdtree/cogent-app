#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Abstract class to define configuration for launching CogentDS
#
# Required:
#	-

from abc import ABCMeta, abstractmethod
from typing import Dict, List, Set
from common.cogent_error import CogentError
from common.util.const import AnalysisType

class DsConfigMeta(metaclass = ABCMeta):

	# ---------------------------------
	# region: Abstract Property (to be implemented in each class)
	@property
	@abstractmethod
	def keys(self) -> Set[str]:
		"""Key names per execution. For example, setting two keys here indicates creating two rda files per key.
			Keys are used for the name of directories and log file names.

		Returns:
			Set[str]: Set of names
		"""
		...

	@property
	@abstractmethod
	def gene_matrices(self) -> Dict[str, str]:
		"""Specify list of genematrix to be input to CogentDS to create rda files.
			Each key should match to names described in keys property.

			The values should be return are postfix of files.
			e.g., {'all': "_all_genematrix.csv", '5pUMI': "_5pUMI_umi_genematrix.csv"}

		Returns:
			Dist[str, str]: Pairs of key and postfix of genematrix. See document above also.
		"""
		...

	@property
	@abstractmethod
	def stats_files(self) -> Dict[str, str]:
		"""Specify list of stats.csv to be input to CogentDS to create rda files.
			Each key should match to names described in keys property.

			The values should be return are postfix of files.
			e.g., {'all': "_all_stats.csv", '5pUMI': "_5pUMI_stats.csv"}

		Returns:
			Dist[str, str]: Pairs of key and postfix of stats file. See document above also.
		"""
		...

	@property
	@abstractmethod
	def additional_analysis(self) -> Dict[str, List[AnalysisType]]:
		"""Specify correspondence of additional analysis per key.
			Each key should match to names described in keys property.

			The values should be return are postfix of files.
			e.g., {'all': [AnalysisType.TRANSCRIPT, AnalysisType.FUSION, AnalysisType.IMMUNE], '5pUMI': []}

		Returns:
			Dict[str, List[AnalysisType]]: Pairs of key and list of AnalysisType.
		"""
		...

	# endregion: Abstract Property
	# ---------------------------------

	# ---------------------------------
	# region: Implemented method

	def __init__(self) -> None:
		for key in self.keys:
			if key not in self.gene_matrices:
				raise CogentError(f'Configuration error: {key} does not match to genematrix.')

			if key not in self.stats_files:
				raise CogentError(f'Configuration error: {key} does not match to stats files.')

			if key not in self.additional_analysis:
				raise CogentError(f'Configuration error: {key} does not match to additional analysis.')

	# endregion: Implemented method
	# ---------------------------------

	# ---------------------------------
	# region: Abstract Method

	# endregion: Abstract method
	# ---------------------------------
