#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Functions to delete unnecessary files from working directory.
# This class is used when --debug option is NOT specified.
#

import glob
import os
import shutil

from common.logger import Logger

from pprint import pprint

def delete_analyzer_temp_files(target_dir: str):
	"""Delete temporary files while analyzer running

	Arguments:
		target_dir {str} -- Target working directory
	"""
	Logger.info_logger('Delete temporary files')

	# Look for deletable files
	delete_files = []
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.featureCounts')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.featureCounts.summary')))
	delete_files.extend(glob.glob(os.path.join(target_dir, 'work_align.csv')))
	delete_files.extend(glob.glob(os.path.join(target_dir, 'split_*')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*_list')))
	# delete_files.extend(glob.glob(os.path.join(target_dir, '*.gtf')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.fq')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.Log.progress.out')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.stdout')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.stderr')))
	delete_files.extend(glob.glob(os.path.join(target_dir, '*.Log.out')))
	# delete_files.extend(glob.glob(os.path.join(target_dir, '*.Log.final.out')))
	delete_files.extend(glob.glob(os.path.join(target_dir, 'stdout')))
	delete_files.extend(glob.glob(os.path.join(target_dir, 'stderr')))
	delete_files.extend(glob.glob(os.path.join(target_dir, 'all_umi_count.txt')))

	for file in delete_files:
		if os.path.isdir(file):
			shutil.rmtree(file)
		else:
			os.remove(file)
