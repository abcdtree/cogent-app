from abc import ABCMeta, abstractmethod
from typing import Dict, List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.analyze import AnalyzeStats
from common.util.demux import DemuxConst, DemuxSummary
from common.util.const import DebugMode

class BaseReport(metaclass = ABCMeta):

	@abstractmethod
	def create(self, key_list: List[str]):
		...

	@abstractmethod
	def _define_files_path(self, out_dir: str, extras_dir: str, prefix: str, debug_mode: DebugMode):
		...

	@abstractmethod
	def _create_stats_header(self) -> List[str]:
		...

	# ---------------------------------
	# region: Protected method
	def _merge_stats(self, key_list: List[str], in_files: Dict[str, str], out_file: str, summary: Union[Dict[str, DemuxSummary], Dict[str, AnalyzeStats]]) -> bool:
		"""Merge split stats.csv into one file

		Returns:
			bool -- Success flag
		"""
		with open(out_file, 'w') as of:
			of.write(','.join(self._create_stats_header()) + '\n')
			for key in key_list:
				with open(in_files[key], 'r') as in_file:
					of.write(in_file.read())

			# Write additional information
			for key in DemuxConst.to_list():
				obj = summary[key]
				data = []
				if isinstance(obj, DemuxSummary):
					data = [key, obj.name, str(obj.reads_num)]
				else:
					data = [key, obj.sample_name, str(obj.barcoded_reads)]

				data.extend(['NA'] * (len(self._create_stats_header()) - 3))
				of.write(','.join(data) + '\n')

		return True

	def _merge_matrix(self, header: str, key_list: List[str], ensembl_info, in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split genematrix files

		Arguments:
			gene_list {[type]} -- List of genes
			in_files {[type]} -- Split genematrix files
			out_file {[type]} -- Path to output file
			gene_info {[type]} -- Path to gene_info.csv

		Returns:
			bool -- [description]
		"""

		if out_file is None:
			return True

		# load genes from list as reference
		header_values = [header]
		matrix_data = {}
		for ensembl_id in ensembl_info.keys():
			matrix_data[ensembl_id] = []

		try:
			# process each file
			for key in key_list:
				if not key in in_files:
					raise CogentError(f'Result about {key} is not found.')

				# Load all values to dict once
				values_buf = {}
				with open(in_files[key], 'r') as f:
					header_values.append(f.readline().strip().split(',')[1])
					for line in f:
						ensembl_id, value = line.strip().split(',')
						values_buf[ensembl_id] = value

				for ensembl_id in ensembl_info.keys():							# For each EnsemblID in GTF
					if ensembl_id in values_buf:								# When included in result from transcript counting
						matrix_data[ensembl_id].append(values_buf[ensembl_id])
					else:														# When missing in result from transcript counting
						matrix_data[ensembl_id].append('0.00')

			# output
			with open(out_file, 'w') as f:
				f.write(','.join(header_values) + '\n')
				for ensembl_id, values in matrix_data.items():
					# f.write(gene_id + ',' + ','.join(values) + '\n')							# Only Ensembl ID
					f.write(ensembl_info[ensembl_id][0] + ',' + ','.join(values) + '\n')		# Ensembl ID and gene name

			return True
		except KeyError as err:
			Logger.error_both(f'Illegal Ensembl ID: {err}')
			return False

	# endregion: Protected method
	# ---------------------------------




