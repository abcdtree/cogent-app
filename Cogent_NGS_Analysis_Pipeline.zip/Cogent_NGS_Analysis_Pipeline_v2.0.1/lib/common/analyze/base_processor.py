from abc import ABCMeta, abstractmethod
from datetime import datetime
from enum import Enum
from logging import log
from multiprocessing import Process, Manager, Pool
import os
from typing import Any, Dict, Tuple, Union, cast
from os import path

from analyze.tools.bam_processor import BAMProcessor
from analyze.tools.cutadapt import CutAdapt
from analyze.tools.feature_counts import FeatureCounts, FeatureCountsType
from analyze.tools.ribopicker import Ribopicker
from common.util.const import FusionFilter, ReadMode, StrandedMode
from analyze.tools.star import Star
from common.analyze.base_summarize import BaseSummarize

from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.analyze import AnalyzeStats
from common.util.demux import DemuxSummary
from common.util.util import elapsed_time

from run_transcript_analysis.tools.rsem import Rsem
from run_immune_analysis.tools.trust4 import Trust4
from run_fusion_analysis.tools.star_fusion import StarFusion


class BaseProcessor(metaclass = ABCMeta):

	@property
	@abstractmethod
	def results(self) -> Dict[str, BaseSummarize]:
		...

	@abstractmethod
	def _work_per_barcode(self, pid: int, key: str, input_files: tuple, res_dict: Dict[str, BaseSummarize], stats: Union[DemuxSummary, AnalyzeStats]) -> bool:
		...
#	def _work_per_barcode(self, pid: int, key: str, input_files: tuple, demux_summary: DemuxSummary, res_dict: Dict[str, BaseSummarize]) -> bool:

	# Initialize
	def __init__(self, threads_num: int, cores_num: int, experiment: Experiment, logs_dir: str, config_dir: str, default_configs, genome_used: str):

		self.__threads_num = threads_num			# Number of threads for parallelization
		self.__cores_num = cores_num				# Number of cores for each tool
		self.__experiment = experiment				# Experiment type
		self.__config_dir = config_dir

		# Fetch from config
		self.__cutadapt_path = default_configs['cutadapt_loc'][0]
		self.__star_path = default_configs['star_loc'][0]
		self.__fc_path = default_configs['featureCounts_loc'][0]
		self.__samtools_path = default_configs['samtools_loc'][0]
		self.__bam2bed_path = default_configs['bamtobed_loc'][0]
		self.__seqtk_path = default_configs['seqtk_loc'][0]
		self.__ribopicker_path = default_configs['ribopicker_loc'][0]
		self.__perl_path = default_configs['perl_loc'][0]
		self.__rsem_path = default_configs['rsem_loc'][0]
		self.__fusion_path = default_configs['genefusion_loc'][0]
		self.__trust4_path = default_configs['trust4_loc'][0]

		self.__genome_path = default_configs[Config.GENOME_CONFIG_KEY + genome_used][0]
		self.__genome_name = genome_used
		self.__species = default_configs[Config.GENOME_CONFIG_KEY + genome_used][3]['species']


		self.__logs_dir_root = logs_dir

		self._results = {}

	# Process
	def process(self, input_files: Dict[str, Tuple], stats: Union[Dict[str, DemuxSummary], Dict[str, AnalyzeStats]]) -> bool:

		pool = Pool(processes=self.__threads_num)
		try:
			start_time = datetime.now()

			manager = Manager()
			summarize_dict = manager.dict()

			# Run with multiprocessing
			res = []
			pid = 1
			for key, files in input_files.items():
				res.append(
					pool.apply_async(
						self._work_per_barcode,
						args=(pid, key, files, summarize_dict, stats[key])
					))
				pid += 1

			pool.close()
			pool.join()

			self._results = cast(Any, summarize_dict)

			Logger.info_logger(f'Finished processing for all barcodes. Elapsed time: ' + elapsed_time(start_time))

			return all([r.get() for r in res])			# Check and retrun all sub process returned True
		except KeyboardInterrupt:
			Logger.warning_both('Received Ctrl+C to terminate process. Try to terminate subprocesses.')
			pool.terminate()
			pool.join()
			return False

		# finally:
		# 	# Logger.info_logger(f'Finished processing for all barcodes. Elapsed time: ' + elapsed_time(start_time))
		# 	# Check if subprocess is alive (assume stopped process by Ctrl+C)
		# 	if pool.is_alive
		# 	print('Called Here')

	# ---------------------------------
	# region: Protected method
	def _trim(self, key: str, work_dir: str, input_files: tuple) -> Union[CutAdapt, None]:

		cutadapt = CutAdapt(key, work_dir, path.join(self.__logs_dir_root, 'trim'), self.__cutadapt_path, self.__cores_num, self.__config_dir)

		res = None
		if self.__experiment.read_mode == ReadMode.PAIRED:
			res = cutadapt.run(input_r1=input_files[0], input_r2=input_files[1])
		elif self.__experiment.read_mode == ReadMode.READ1:
			res = cutadapt.run(input_r1=input_files[0], input_r2=None)
		elif self.__experiment.read_mode == ReadMode.READ2:
			res = cutadapt.run(input_r1=None, input_r2=input_files[0])
		else:
			return None

		if res:
			return cutadapt
		else:
			return None

	def _align(self, key: str, work_dir: str, input_files: tuple, extra_options: Dict[str, str]) -> Union[Star, None]:

		star = Star(
			key, work_dir, path.join(self.__logs_dir_root, 'align'),
			self.__star_path, self.__cores_num, self.__genome_path,
			extra_options
			)
		res = star.run(input_files[0], input_files[1])

		if res:
			return star
		else:
			return None

	def _feature_counts(self, key: str, work_dir: str, bam_file: str, count_type: FeatureCountsType, use_gtf: str) -> Union[FeatureCounts, None]:

		feature_counts = FeatureCounts(
			key, work_dir, path.join(self.__logs_dir_root, 'feature_counts'),
			self.__fc_path, self.__cores_num, self.__experiment.stranded_mode,
			count_type, use_gtf, self.__experiment.is_paired
			)
		res = feature_counts.run(bam_file)

		if res:
			return feature_counts
		else:
			return None

	def _rsem(self, key: str, work_dir: str, bam_file: str, is_paired: bool, stranded_mode: StrandedMode) -> Union[Rsem, None]:

		rsem = Rsem(
			key, work_dir, path.join(self.__logs_dir_root, 'rsem'),
			self.__rsem_path, self.__cores_num, self.__genome_path, self.__genome_name
			)
		res = rsem.run(bam_file, is_paired, stranded_mode)

		if res:
			return rsem
		else:
			return None

	def _fusion(self, key: str, work_dir: str, chimeric_file: str, filter: FusionFilter) -> Union[StarFusion, None]:

		fusion = StarFusion(
			key, work_dir, path.join(self.__logs_dir_root, 'fusion'),
			self.__fusion_path, self.__cores_num, self.__genome_path,
			self.__species, filter
			)
		res = fusion.run(chimeric_file)

		if res:
			return fusion
		else:
			return None

	def _immune(self, key: str, work_dir: str, input_files: tuple) -> Union[Trust4, None]:

		trust4 = Trust4(
			key, work_dir, path.join(self.__logs_dir_root, 'immune'),
			self.__trust4_path, self.__cores_num, self.__genome_name )
		res = trust4.run(input_files[0], input_files[1])

		if res:
			return trust4
		else:
			return None

	def _bam2csv(self, key: str, work_dir: str, bam_file: str) -> Union[BAMProcessor, None]:

		# create instance for BAM processing
		bam_processor = BAMProcessor(
			key, work_dir, path.join(self.__logs_dir_root, 'bam2csv'),
			self.__cores_num, self.__samtools_path, self.__bam2bed_path
			)
		res = bam_processor.to_csv(bam_file, self.__experiment.uss_mode)

		if res:
			return bam_processor
		else:
			return None

	def _ribopicker(self, key: str, work_dir: str, input_file: str) -> Union[Ribopicker, None]:

		# create instance for riboPicker
		riboPicker = Ribopicker(key, work_dir, self.__ribopicker_path, self.__seqtk_path, self.__perl_path, self.__cores_num)
		res = riboPicker.run(input_file)

		if res:
			return riboPicker
		else:
			return None

	def _clean_work_dir(self, is_keep_log: bool, cutadapt: CutAdapt = None, star: Star = None,
						exon_count: FeatureCounts = None, gene_count: FeatureCounts = None, mito_count: FeatureCounts = None,
						unstrand_count: FeatureCounts = None, ribopicker: Ribopicker = None, rsem: Rsem = None, fusion: StarFusion = None,
						immune: Trust4 = None, bam_processor: BAMProcessor = None) -> bool:

		if not cutadapt is None:
			cutadapt.remove_temp_files()

		if not star is None:
			star.remove_temp_files()

		if not exon_count is None:
			exon_count.remove_temp_files()

		if not gene_count is None:
			gene_count.remove_temp_files()

		if not mito_count is None:
			mito_count.remove_temp_files()

		if not unstrand_count is None:
			unstrand_count.remove_temp_files()

		if not ribopicker is None:
			ribopicker.remove_temp_files()

		if not rsem is None:
			rsem.remove_temp_files()

		if not fusion is None:
			fusion.remove_temp_files()

		if not immune is None:
			immune.remove_temp_files()

		if not bam_processor is None:
			bam_processor.remove_temp_files()

		if not is_keep_log:
			if not cutadapt is None:
				cutadapt.remove_log_files()

			if not star is None:
				star.remove_log_files()

			if not exon_count is None:
				exon_count.remove_log_files()

			if not gene_count is None:
				gene_count.remove_log_files()

			if not mito_count is None:
				mito_count.remove_log_files()

			if not unstrand_count is None:
				unstrand_count.remove_log_files()

			if not rsem is None:
				rsem.remove_log_files()

			if not fusion is None:
				fusion.remove_log_files()

			if not immune is None:
				immune.remove_log_files()

			if not bam_processor is None:
				bam_processor.remove_log_files()

		return True

	# endregion: Protected method
	# ---------------------------------


