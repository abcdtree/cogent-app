from abc import ABCMeta, abstractmethod

class BaseSummarize(metaclass = ABCMeta):

	@abstractmethod
	def create_summary_files(self) -> bool:
		...

	@abstractmethod
	def _create_result_files(self) -> bool:
		...
