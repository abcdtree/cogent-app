from os import path
from enum import Enum
from glob import glob

from typing import Dict, List, Tuple, Union
from posix import listdir	# type: ignore

from common.util.demux import DemuxConst
from common.cogent_error import CogentError

from common.util.demux import get_barcodes_from_summary
from common.logger import Logger

import csv

# from common.util.immune import create_input_for_cogent_ds
import common.util.immune as immune
import common.util.fusion as fusion

class StatsConst(Enum):
	BARCODE = 'Barcode'
	SAMPLE_NAME = 'Sample'
	BARCODED_READS = 'Barcoded_Reads'
	NO_OF_UMI_Reads = 'No_of_Reads_w_UMI'
	NO_OF_UMI = 'No_of_UMIs'
	TRIMMED_READS = 'Trimmed_Reads'
	UNMAPPED_READS = 'Unmapped_Reads'
	MAPPED_READS = 'Mapped_Reads'
	MULTIMAPPED_READS = 'Multimapped_Reads'
	UNIQUE_MAPPED_READS = 'Uniquely_Mapped_Reads'
	EXON_READS = 'Exon_Reads'
	EXON_UMI = 'Exon_nUMIs'
	EXON_USS = 'Exon_nUSSs'
	EXON_UMI_USS = 'Exon_nUMIs_USSs'
	AMBIGUOUS_EXON_READS = 'Ambiguous_Exon_Reads'
	INTRON_READS = 'Intron_Reads'
	INTRON_UMI = 'Intron_nUMIs'
	INTRON_USS = 'Intron_nUSSs'
	INTRON_UMI_USS = 'Intron_nUMIs_USSs'
	AMBIGUOUS_INTRON_READS = 'Ambiguous_Intron_Reads'
	GENE_READS = 'Gene_Reads'
	GENE_UMI = 'Gene_nUMIs'
	GENE_USS = 'Gene_nUSSs'
	GENE_UMI_USS = 'Gene_nUMIs_USSs'
	INTERGENIC_READS = 'Intergenic_Reads'
	NO_OF_GENE = 'No_of_Genes'
	NO_OF_TRANSCRIPTS = 'No_of_Transcripts'
#	NO_OF_FUSIONS = 'No_of_Fusions'
	MITOCHONDRIA_READS = 'Mitochondrial_Reads'
	RIBOSOMAL_READS = 'Ribosomal_Reads'
	STRAND_SPECIFICITY = 'Strand_Specificity'

class AnalyzeStats:

	# Property
	@property
	def key(self) -> str:
		return self.__key

	@property
	def sample_name(self) -> Union[str, None]:
		return self.__values.get(StatsConst.SAMPLE_NAME.value, None)

	@property
	def barcoded_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.BARCODED_READS.value)

	@property
	def no_of_umi(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.NO_OF_UMI.value)

	@property
	def trimmed_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.TRIMMED_READS.value)

	@property
	def unmapped_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.UNMAPPED_READS.value)

	@property
	def mapped_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.MAPPED_READS.value)

	@property
	def multi_mapped_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.MULTIMAPPED_READS.value)

	@property
	def unique_mapped_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.UNIQUE_MAPPED_READS.value)

	@property
	def exon_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.EXON_READS.value)

	@property
	def exon_umi(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.EXON_UMI.value)

	@property
	def exon_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.EXON_USS.value)

	@property
	def exon_umi_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.EXON_UMI_USS.value)

	@property
	def ambiguous_exon_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.AMBIGUOUS_EXON_READS.value)

	@property
	def intron_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.INTRON_READS.value)

	@property
	def intron_umi(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.INTRON_UMI.value)

	@property
	def intron_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.INTRON_USS.value)

	@property
	def intron_umi_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.INTRON_UMI_USS.value)

	@property
	def ambiguous_intron_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.AMBIGUOUS_INTRON_READS.value)

	@property
	def gene_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.GENE_READS.value)

	@property
	def gene_umi(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.GENE_UMI.value)

	@property
	def gene_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.GENE_USS.value)

	@property
	def gene_umi_uss(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.GENE_UMI_USS.value)

	@property
	def intergenic_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.INTERGENIC_READS.value)

	@property
	def no_of_gene(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.NO_OF_GENE.value)

	@property
	def no_of_transcripts(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.NO_OF_TRANSCRIPTS.value)

#	@property
#	def no_of_fusions(self) -> Union[int, None]:
#		return self.__fetch_int_value(StatsConst.NO_OF_FUSIONS.value)

	@property
	def mitochondria_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.MITOCHONDRIA_READS.value)

	@property
	def ribosomal_reads(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.RIBOSOMAL_READS.value)

	@property
	def strand_specificity(self) -> Union[float, None]:
		return self.__fetch_float_value(StatsConst.STRAND_SPECIFICITY.value)

	@property
	def test(self):
		return self.__values


	def __init__(self, key: str, header: List[str], values: List[str]):
		self.__key = key
		self.__values = {}
		for i, col_name in enumerate(header):
			self.__values[col_name] = values[i]

	def __fetch_int_value(self, target: str) -> Union[int, None]:
		value = self.__values.get(target, None)
		if not value is None:
			value = int(value)

		if value == 'NA':
			value = None

		return value

	def __fetch_float_value(self, target: str) -> Union[float, None]:
		value = self.__values.get(target, None)
		if not value is None:
			value = float(value)

		if value == 'NA':
			value = None

		return value

# -------------------------------------
# region: Methods

def load_stats_file(input_dir: str, main_result_prefix: str = None) -> Dict[str, AnalyzeStats]:
	"""Load values in stats file to dictionary
	"""

	# Search stats.csv first
	files = glob(f'{input_dir}/*_stats.csv')
	stats_file = None
	if len(files) == 1:
		stats_file = files[0]
	elif len(files) == 0:
		raise CogentError(f'Cannot find stats.csv in {input_dir}')
	elif len(files) > 1:				# If 2 or more files are found (SSv4+UMI or error)
		if main_result_prefix is not None:
			for f in files:
				if f.endswith(f'{main_result_prefix}_stats.csv'):		# Find correct file name by SSV4+UMI
					stats_file = f
		else:
			raise CogentError(f'Too many stats.csv were found in {input_dir}')

	if stats_file is None:
		raise CogentError(f'Cannot find stats.csv in {input_dir}')

	Logger.info_logger(f'Find stats.csv: {stats_file}')

	# Load values
	stats = {}
	try:
		with open(stats_file, newline='') as csvfile:
			reader = csv.reader(csvfile, skipinitialspace = True)
			header = None
			for row in reader:
				if (len(row) > 0) and (not row[0].startswith('#')):
					if header is None:		# Retrieve header first
						del(row[0])			# Delete first column for "Barocode"
						header = row		# Keep other column names
						continue

					# Process values
					key = row[0]					# Fetch barcode
					del(row[0])						# Keep other column values
					stats[key] = AnalyzeStats(key, header, row)

	except EnvironmentError as err:
		raise CogentError(f"Unable to open file: {files[0]}", 'load_stats_file')

	return stats

#def create_analyze_stats_header(is_use_umi: bool, is_use_uss: bool, is_stranded: bool, do_transcript: bool, use_combined: bool):
def create_analyze_stats_header(is_use_umi: bool, is_use_uss: bool, is_stranded: bool, do_transcript: bool, out_no_umi_reads: bool):
		"""Create list of header strings for stats.csv by branching parameters.
		"""

		headers = [
			StatsConst.BARCODE.value, StatsConst.SAMPLE_NAME.value, StatsConst.BARCODED_READS.value
		]

		if is_use_umi and out_no_umi_reads:
			headers.append(StatsConst.NO_OF_UMI_Reads.value)

		if is_use_umi:
			headers.append(StatsConst.NO_OF_UMI.value)

		headers.extend([
			StatsConst.TRIMMED_READS.value, StatsConst.UNMAPPED_READS.value, StatsConst.MAPPED_READS.value,
			StatsConst.MULTIMAPPED_READS.value, StatsConst.UNIQUE_MAPPED_READS.value,
			StatsConst.EXON_READS.value
		])

		if is_use_umi:
			headers.append(StatsConst.EXON_UMI.value)

		if is_use_uss:
			headers.append(StatsConst.EXON_USS.value)

		if is_use_umi and is_use_uss:
			headers.append(StatsConst.EXON_UMI_USS.value)

		headers.extend([
			StatsConst.AMBIGUOUS_EXON_READS.value, StatsConst.INTRON_READS.value
		])

		if is_use_umi:
			headers.append(StatsConst.INTRON_UMI.value)

		if is_use_uss:
			headers.append(StatsConst.INTRON_USS.value)

		if is_use_umi and is_use_uss:
			headers.append(StatsConst.INTRON_UMI_USS.value)

		headers.extend([
			StatsConst.AMBIGUOUS_INTRON_READS.value, StatsConst.GENE_READS.value
		])

		if is_use_umi:
			headers.append(StatsConst.GENE_UMI.value)

		if is_use_uss:
			headers.append(StatsConst.GENE_USS.value)

		if is_use_umi and is_use_uss:
			headers.append(StatsConst.GENE_UMI_USS.value)

		headers.extend([
			StatsConst.INTERGENIC_READS.value, StatsConst.NO_OF_GENE.value
		])

		if do_transcript:
			headers.append(StatsConst.NO_OF_TRANSCRIPTS.value)

#		if use_combined:
#			headers.append(StatsConst.NO_OF_FUSIONS.value)

		headers.extend([
			StatsConst.MITOCHONDRIA_READS.value, StatsConst.RIBOSOMAL_READS.value
		])

		if is_stranded:
			headers.append(StatsConst.STRAND_SPECIFICITY.value)

		return headers

def get_transcript_bam_files(input_dir: str, barcodes: List[str]) -> Dict[str, tuple]:

	# Search BAM directory first
	bam_dir = path.join(input_dir, 'bam')
	if not path.isdir(bam_dir):
		raise CogentError(f'Cannot find bam directory in {input_dir}')

	# Listup all files in the directory
	file_list = listdir(bam_dir)

	# Find BAM files having each barcode for transcript counting
	bam_files = {}
	for barcode in barcodes:
		if barcode in DemuxConst.to_list():			# Skip for non sample such as Short, Unselected and Undetermined.
			continue

		file_name = f'{barcode}.Aligned.toTranscriptome.out.bam'
		if not file_name in file_list:
			raise CogentError(f'Cannot find transcriptome BAM file for {barcode}')

		bam_files[barcode] = (path.join(bam_dir, file_name),)

	return bam_files

def get_fusion_chimeric_files(input_dir: str, barcodes: List[str]) -> Dict[str, tuple]:

	# Search BAM directory first
	bam_dir = path.join(input_dir, 'bam')
	if not path.isdir(bam_dir):
		raise CogentError(f'Cannot find bam directory in {input_dir}')

	# Listup all files in the directory
	file_list = listdir(bam_dir)

	# Find chimeric files having each barcode for fusion counting
	chimeric_files = {}
	for barcode in barcodes:
		if barcode in DemuxConst.to_list():			# Skip for non sample such as Short, Unselected and Undetermined.
			continue

		file_name = f'{barcode}.Chimeric.out.junction'
		if not file_name in file_list:
			raise CogentError(f'Cannot find fusion_chimeric file for {barcode}')

		chimeric_files[barcode] = (path.join(bam_dir, file_name),)

	return chimeric_files

def get_gene_matrix_file(input_dir: str, search_postfix: Union[Dict[str, str], None]) -> Union[Dict[str, str], None]:

	if search_postfix is None:									# If postfix is NOT specified in experiment class
		# Search all *_genematrix.csv first
		files = glob(f'{input_dir}/*_genematrix.csv')

		if len(files) == 0:
			Logger.error_logger(f'No genematrix was found in {input_dir}.')
			return None

		if len(files) == 1:					# Only 1 file is found (normal)
			return {'1': files[0]}
		else:								# If 2 or more files are found (in case SSv4+UMI)
			Logger.error_logger('Two or more genematrix files were found. It is not correct for this experiment type.')
			return None
	else:														# If postfix is specified in experiment class
		return_file_list = {}
		for key, postfix in search_postfix.items():
			files = glob(f'{input_dir}/*{postfix}')		# List up files with the postfix in the directory

			if len(files) == 0:
				Logger.error_logger(f'No genematrix ends with {postfix} found in {input_dir}.')
				return None
			elif len(files) == 1:
				return_file_list[key] = files[0]				# Add to dict
			else:
				Logger.error_logger(f'Two or more genematrix ends with {postfix} were found.')
				return None

		return return_file_list

def get_stats_file(input_dir: str, search_postfix: Union[Dict[str, str], None]) ->  Union[Dict[str, str], None]:
	if search_postfix is None:
		# Search all *_stats.csv first
		files = glob(f'{input_dir}/*_stats.csv')

		if len(files) == 0:
			Logger.warning_logger(f'No stats.csv was found in {input_dir}.')
			return None

		if len(files) == 1:					# Only 1 file is found (normal)
			return {'1': files[0]}
		else:								# If 2 or more files are found (in case SSv4+UMI)
			Logger.warning_logger('Two or more stats files were found. It is not correct for this experiment type.')
			return None
	else:
		return_file_list = {}
		for key, postfix in search_postfix.items():
			files = glob(f'{input_dir}/*{postfix}')		# List up files with the postfix in the directory

			if len(files) == 0:
				Logger.error_logger(f'No genematrix ends with {postfix} found in {input_dir}.')
				return None
			elif len(files) == 1:
				return_file_list[key] = files[0]				# Add to dict
			else:
				Logger.error_logger(f'Two or more genematrix ends with {postfix} were found.')
				return None

		return return_file_list

def get_gene_info_file(input_dir: str) -> Union[str, None]:
	# Search all *_stats.csv first
	file = f'{input_dir}/gene_info.csv'
	if path.isfile(file):
		return file
	else:
		Logger.warning_logger(f'No gene info file is found in {input_dir}.')
		return None

def get_transcript_matrix_file(input_dir: str) -> Union[str, None]:
	# Search all *_transcript_matrix.csv first
	files = glob(f'{input_dir}/transcript/*_transcript_matrix.csv')

	if len(files) == 0:					# If there is no file, its not an error
		return None

	if len(files) == 1:					# Only 1 file is found (normal)
		return files[0]
	else:								# If 2 or more files are found (SSv4+UMI or error)
		Logger.warning_logger('2 or more transcript matrix were found. It is not correct.')
		return None														# Otherwise, error

def get_transcript_info_file(input_dir: str) -> Union[str, None]:
	# Search all *_stats.csv first
	file = f'{input_dir}/transcript/transcript_info.csv'
	if path.isfile(file):
		return file
	else:
		return None

def get_gene_fusion_dir(input_dir: str, work_dir: str) -> Union[str, None]:
	search_dir = f'{input_dir}/gene_fusion'
	if not path.isdir(search_dir):			# If there is not target directory, its not an error
		return None

	# Check files inside
	files = glob(f'{search_dir}/*_junction_matrix.csv')
	if len(files) == 0:
		Logger.warning_logger('There is gene fusion directory, but no junction matrix was found in the directory.')
		return None
	elif len(files) > 1:
		Logger.warning_logger('There is gene fusion directory, but more then 1 junction matrix were found in the directory.')
		return None

	in_junction_matrix = files[0]

	files = glob(f'{search_dir}/*_spanning_matrix.csv')
	if len(files) == 0:
		Logger.warning_logger('There is gene fusion directory, but no spanning matrix was found in the directory.')
		return None
	elif len(files) > 1:
		Logger.warning_logger('There is gene fusion directory, but more then 1 spanning matrix were found in the directory.')
		return None

	in_spanning_matrix = files[0]

	files = glob(f'{search_dir}/*_stats.csv')
	if len(files) == 0:
		Logger.warning_logger('There is gene fusion directory, but no stats file was found in the directory.')
		return None
	elif len(files) > 1:
		Logger.warning_logger('There is gene fusion directory, but more then 1 stats file were found in the directory.')
		return None

	in_stats = files[0]

	return fusion.create_input_for_cogent_ds(work_dir, in_junction_matrix, in_spanning_matrix, in_stats)

def get_clonotype_dir(input_dir: str, work_dir: str) -> Union[str, None]:
	search_dir = f'{input_dir}/immune'
	if not path.isdir(search_dir):			# If there is not target directory, its not an error
		return None

	# Check files inside
	files = glob(f'{search_dir}/*clonotype_matrix.csv')

	# Remove top3 clonotype matrix
	candidate_files = []
	for f in files:
		if 'top3' not in f:
			candidate_files.append(f)

	if len(candidate_files) == 0:
		Logger.warning_logger('There is clonotype directory, but no matrix was found in the directory.')
		return None
	elif len(candidate_files) > 1:
		Logger.warning_logger('There is clonotype directory, but more then 1 matrix were found in the directory.')
		return None

	in_matrix = candidate_files[0]

	files = glob(f'{search_dir}/*metadata.csv')
	# Remove top3 clonotype matrix
	candidate_files = []
	for f in files:
		if 'top3' not in f:
			candidate_files.append(f)

	if len(candidate_files) == 0:
		Logger.warning_logger('There is clonotype directory, but no metadata was found in the directory.')
		return None
	elif len(candidate_files) > 1:
		Logger.warning_logger('There is clonotype directory, but more then 1 metadata were found in the directory.')
		return None

	in_metadata= candidate_files[0]

	# Create intermediate input and return it
	return immune.create_input_for_cogent_ds(work_dir, in_matrix, in_metadata)

# endregion: Methods
# -------------------------------------
