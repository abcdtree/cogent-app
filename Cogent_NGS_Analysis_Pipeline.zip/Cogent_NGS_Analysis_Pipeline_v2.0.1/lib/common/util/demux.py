from enum import Enum
from glob import glob
from os.path import isdir, isfile
from posix import listdir
from typing import Dict, List, Tuple, Union
from common.cogent_error import CogentError
from common.logger import Logger
from os import path, read

import re
import csv

from common.util.const import ReadMode

class DemuxConst(Enum):
	SHORT = 'Short'
	UNSELECT = 'Unselected'
	UNDETERMINED = 'Undetermined'

	@classmethod
	def to_list(cls) -> List[str]:
		return [cls.SHORT.value, cls.UNSELECT.value, cls.UNDETERMINED.value]

class DemuxSummary:

	# Property
	@property
	def key(self) -> str:
		return self.__key

	@property
	def name(self) -> str:
		return self.__name

	@property
	def reads_num(self) -> int:
		return self.__reads_num

	# @property
	# def umi_num(self) -> int:
	# 	return self.__umi_num

	def __init__(self, key: str, values: List[str]):
		self.__key = key
		self.__name = values[0]
		self.__reads_num = int(values[1])

		# self.__umi_num = -1						# Initialize with error value
		# if len(values) > 2:
		# 	self.__umi_num = int(values[2])

def load_summary_file(file: str) -> Dict[str, DemuxSummary]:
	"""Function: General loader of a csv file.

	Data is assumed to stored row-wise.
	The first column is considered to be a keyword and is stored as the keyword
	in a dictionary. The remaining columns are stored in the form of a list
	and as the value of the keyword.
	The dictionary is returned at the end.
	"""

	summary_data = {}
	try:
		with open(file, newline='') as csvfile:
			configreader = csv.reader(csvfile, skipinitialspace = True)
			for row in configreader:
				if (len(row) > 0) and (not row[0].startswith('#')):
					key = row[0]
					del(row[0])
					summary_data[key] = DemuxSummary(key, row)

	except EnvironmentError as err:
		raise CogentError(f"Unable to open file: {file}", 'load_summary_file')

	return summary_data

def find_summary_file(user_input: str) -> str:
	if isdir(user_input):				# Assume output dir from demux command
		result_file = glob(f'{user_input}/*_counts_all.csv')
		if len(result_file) == 0:
			raise CogentError(f'Cannot find counts_all.csv in {user_input}')
		elif len(result_file) > 1:
			raise CogentError(f'Too many counts_all.csv in {user_input}')

		return result_file[0]
	# elif isfile(user_input):			# Assume text including file list, Nothing to do.
	# 	return None
	else:
		raise CogentError(f'Unexpected user input type', 'find_summary_file')

def get_fastq_dict(demux_dir: str, read_mode: ReadMode) -> Dict[str, Tuple]:

	# Find *_counts_all.csv
	demux_result_file = find_summary_file(demux_dir)
	Logger.info_logger(f'Find counts_all.csv: {demux_result_file}')

	# Load barcodes
	barcode_list = get_barcodes_from_summary(demux_result_file)

	# Listup all files in the directory
	file_list = listdir(demux_dir)

	# Find FASTQ files having each barcode
	fastq_dict = {}
	for barcode in barcode_list:
		# Read1
		r1_file = None
		if read_mode == ReadMode.PAIRED or read_mode == ReadMode.READ1:
			r = re.compile(f'.+_{barcode}_.+_R1\\.fastq.*')			# Catch both with/without .gz
			filter_list = list(filter(r.match, file_list))
			if len(filter_list) == 0:
				raise CogentError(f'Cannot find read1 FASTQ for {barcode}')

			elif len(filter_list) > 1:
				raise CogentError(f'Too many read1 FASTQ for {barcode}')

			r1_file = path.join(demux_dir, filter_list[0])

		# Read2
		r2_file = None
		if read_mode == ReadMode.PAIRED or read_mode == ReadMode.READ2:
			r = re.compile(f'.+_{barcode}_.+_R2\\.fastq.*')				# Catch both with/without .gz
			filter_list = list(filter(r.match, file_list))
			if len(filter_list) == 0:
				raise CogentError(f'Cannot find read2 FASTQ for {barcode}')
			elif len(filter_list) > 1:
				raise CogentError(f'Too many read2 FASTQ for {barcode}')

			r2_file = path.join(demux_dir, filter_list[0])

		if read_mode == ReadMode.PAIRED:
			fastq_dict[barcode] = (r1_file, r2_file)
		elif read_mode == ReadMode.READ1:
			fastq_dict[barcode] = (r1_file,)
		elif read_mode == ReadMode.READ2:
			fastq_dict[barcode] = (r2_file,)
		else:
			fastq_dict[barcode] = ()

	return fastq_dict

def get_barcodes_from_summary(demux_count_file: str) -> List[str]:

	barcode_list = []
	with open(demux_count_file, mode='r') as f:
		for line in f:
			if line.strip() == '':				# Ignore empty line
				continue

			values = line.rstrip().split(',')
			if values[1] == 'Non_sample':
				continue

			if values[0] in barcode_list:
				raise CogentError(f'Duplicate barcodes are found in counts_all.csv.')

			barcode_list.append(values[0])

	return barcode_list