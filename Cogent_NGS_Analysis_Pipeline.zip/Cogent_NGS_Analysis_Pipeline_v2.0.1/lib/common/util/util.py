import csv
import dnaio
import os

from datetime import datetime
from os.path import isdir, isfile
import subprocess
from typing import Dict, List, Tuple, Union
from decimal import Decimal, ROUND_HALF_UP

from common.cogent_error import CogentError
from common.logger import Logger
from common.util.const import ReadMode

from common.util.demux import get_fastq_dict

# -----
# Run system command
def run_system_cmd(cmd: str, stdout_file: str = None, stderr_file: str = None, suppress_error_message: bool = False) -> bool:
	"""Function: Run a system command.

	Stores stdout in outfile and stderr in errfile
	err_message is a message to be logged if the command fails
	"""

	stdout = None
	stderr = None

	try:
		if not stdout_file is None:
			stdout = open(stdout_file, 'w')

		if not stderr_file is None:
			stderr = open(stderr_file, 'w')

		run_cmd = subprocess.run(cmd.split(), stdout=stdout, stderr=stderr, check=True)
	except subprocess.CalledProcessError as err:
		if not suppress_error_message:
			Logger.error_logger(str(err))
		return False
	finally:
		if not stdout is None:
			stdout.close()
		if not stderr is None:
			stderr.close()

	return True

# -----
# Calculate elapsed time
def elapsed_time(start_time: datetime) -> str:
	"""Create formatted text to show elapsed time. Current time is used automatically to calculate time difference.

	Args:
		start_time (datetime): Start time to calculate elapsed time

	Returns:
		[str]: Fromatted text
	"""
	current_time = datetime.now()
	elapsed_time = current_time - start_time

	# Format text
	seconds = round(elapsed_time.total_seconds() % 60, 2)
	minutes = int(elapsed_time.total_seconds() // 60) % 60
	hours = int(elapsed_time.total_seconds() // 3600)

	format_text = ":".join([f'{hours:02d}h', f'{minutes:02d}m', f'{int(seconds // 1):02d}' + f'{(seconds % 1):.2f}'[1:] + 's'])

	return format_text

# Find

# -----
# Load FASTQ file path
def get_fastq_file_list(user_input: str, read_mode: ReadMode) -> Union[Dict[str, Tuple], None]:

	if isdir(user_input):				# Assume output dir from demux command
		Logger.info_logger("Load path of FASTQ files from input directory (assume demux's result).")
		return get_fastq_dict(user_input, read_mode)
	# elif isfile(user_input):			# Assume text including file list
	# 	Logger.info_logger("Load path of FASTQ files from input list.")
	# 	return get_fastq_file_from_list(user_input, experiment)
	else:
		return None

def get_fastq_file_from_list(file: str, read_mode: ReadMode) -> Union[Dict[str, Tuple], None]:

	# Judge delimiter
	delimiter = None
	correct_columns = -1
	with open(file, mode='r') as f:
		line = f.readline().strip()			# Read first line
		values = line.split(',')			# Try to split with "," first
		if len(values) > 1:
			delimiter = ','
		else:
			values = line.split('\t')		# Try to split with tab
			if len(values) > 1:
				delimiter = '\t'

		if len(values) == 2 and read_mode == ReadMode.PAIRED:
			Logger.error_both(f'Input experiment type assumes paired-end, but single fastq is specified in the file list.')
			return None

		if len(values) == 3 and read_mode != ReadMode.PAIRED:
			Logger.error_both(f'Input experiment type assumes single-end, but paired-end fastq is specified in the file list.')
			return None

		correct_columns = len(values)		# Keep number of columns

	if delimiter == None:
		Logger.error_both(f'Cannot detect delimiter in input file list. Should be CSV or TSV.')
		return None

	# Load file path from file
	fastq_dict = {}
	with open(file, mode='r') as f:
		for line in f:
			if line.strip() == '':				# Ignore empty line
				continue

			values = line.rstrip().split(delimiter)
			if len(values) != correct_columns:
				Logger.error_both(f'Number of columns for each sample are not exactly same in input file list.')
				return None

			if values[0] in fastq_dict:
				Logger.error_both(f'Duplicate keys were found in input file list: {values[0]}')
				return None

			if len(values) == 2:
				fastq_dict[values[0]] = (values[1],)
			else:
				fastq_dict[values[0]] = (values[1], values[2])

			# Check if path exists
			for fastq_path in fastq_dict[values[0]]:
				if not isfile(fastq_path):
					Logger.error_both(f'FASTQ file in the list does not exist: {fastq_path}')
					return None

	return fastq_dict

def count_fastq(in_file: str) -> int:
	count = 0
	with dnaio.open(in_file, mode = 'r') as f:
		for _ in f:	# type: ignore
			count += 1

	return count

def quantize(value: float, size: str = '0.001') -> str:
	return str(Decimal(str(value)).quantize(Decimal(size), rounding=ROUND_HALF_UP))

def remove_dir(target_path: str) -> bool:
	if isdir(target_path):
		try:
			os.removedirs(target_path)
			return True
		except:
			return False
	else:
		return False

def remove_file(target_path: str) -> bool:
	if isfile(target_path):
		try:
			os.unlink(target_path)
			return True
		except:
			return False
	else:
		return False



def load_csv_as_dict(file, key_col = 0, skip_header = False):
	"""Function: General loader of a csv file.

	Data is assumed to stored row-wise.
	The first column is considered to be a keyword and is stored as the keyword
	in a dictionary. The remaining columns are stored in the form of a list
	and as the value of the keyword.
	The dictionary is returned at the end.
	"""

	metadata = {}
	try:
		with open(file, newline='') as csvfile:
			reader = csv.reader(csvfile, skipinitialspace = True)

			if skip_header:
				next(reader)

			for row in reader:
				if (len(row) > 0) and (not row[0].startswith('#')):
					key = row[key_col]
					del(row[key_col])
					metadata[key] = row

	except EnvironmentError as err:
		raise CogentError(f"Unable to open file: {file}", 'load_csv_as_dict')

	return metadata