from enum import Enum, auto
from typing import List

class DebugMode(Enum):
	NONE = 'none'
	MODERATE = 'moderate'
	HIGH = 'high'

	@classmethod
	def to_list(cls) -> List[str]:
		return [cls.NONE.value, cls.MODERATE.value, cls.HIGH.value]

class BamKeepMode(Enum):
	NONE = 'none'
	EACH = 'each'
	SAMPLE = 'sample'
	MERGED = 'merged'

	@classmethod
	def to_list(cls) -> List[str]:
		return [cls.NONE.value, cls.EACH.value, cls.SAMPLE.value, cls.MERGED.value]


def to_debug_mode(value: str) -> DebugMode:
	if value == DebugMode.NONE.value:
		return DebugMode.NONE
	elif value == DebugMode.MODERATE.value:
		return DebugMode.MODERATE
	elif value == DebugMode.HIGH.value:
		return DebugMode.HIGH
	else:
		return DebugMode.NONE

def to_bam_keep_mode(value: str) -> BamKeepMode:
	if value == BamKeepMode.NONE.value:
		return BamKeepMode.NONE
	elif value == BamKeepMode.EACH.value:
		return BamKeepMode.EACH
	elif value == BamKeepMode.SAMPLE.value:
		return BamKeepMode.SAMPLE
	elif value == BamKeepMode.MERGED.value:
		return BamKeepMode.MERGED
	else:
		return BamKeepMode.NONE

class UssMode(Enum):
	NONE = 1
	BOTH = 2
	READ1 = 3
	READ2 = 4

class ReadMode(Enum):
	PAIRED = auto()
	READ1 = auto()
	READ2 = auto()

class StrandedMode(Enum):
	NONE = auto()			# Non stranded.
	FORWARD = auto()		# Stranded. Upstream reads are derived from the forward strand. (featureCount: -s 1, RSEM: --forward-prob 1.0)
	REVERSE = auto()		# Stranded. Upstream reads are derived from the reverse strand. (featureCount: -s 2, RSEM: --forward-prob 0.0)

class NormalizeMethod(Enum):
	CPM = 'cpm'
	TPM = 'tpm'
	FPKM = 'fpkm'

class AnalysisType(Enum):
	GENE = auto()
	TRANSCRIPT = auto()
	FUSION = auto()
	IMMUNE = auto()

class FusionFilter(Enum):
	STAR_FUSION_DEFAULT = '0'
	MAX_SENSITIVE = '1'
	NO_RT_ARTIFACT = '2'
	FULL_MONTY = '3'
	NO_FILTER = '4'

	@classmethod
	def to_list(cls) -> List[str]:
		return [cls.STAR_FUSION_DEFAULT.value, cls.MAX_SENSITIVE.value, cls.NO_RT_ARTIFACT.value, cls.FULL_MONTY.value, cls.NO_FILTER.value]

def to_fusion_filter(value: str) -> FusionFilter:
	if value == FusionFilter.STAR_FUSION_DEFAULT.value:
		return FusionFilter.STAR_FUSION_DEFAULT
	elif value == FusionFilter.MAX_SENSITIVE.value:
		return FusionFilter.MAX_SENSITIVE
	elif value == FusionFilter.NO_RT_ARTIFACT.value:
		return FusionFilter.NO_RT_ARTIFACT
	elif value == FusionFilter.FULL_MONTY.value:
		return FusionFilter.FULL_MONTY
	elif value == FusionFilter.NO_FILTER.value:
		return FusionFilter.NO_FILTER
	else:
		return FusionFilter.MAX_SENSITIVE			# Default is max_sensitive
