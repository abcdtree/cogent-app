from os import mkdir, path
from enum import Enum

from typing import List, Union
import shutil

class StatsConst(Enum):
	BARCODE = 'Barcode'
	SAMPLE_NAME = 'Sample'
	COUNT = 'count'
	FREQUENCY = 'frequency'
	CDR3NT = 'cdr3nt'
	CDR3AA = 'cdr3aa'
	VREGION = 'vregion'
	DREGION = 'dregion'
	JREGION = 'jregion'
	CREGION = 'cregion'
	CID = 'cid'
	CID_FULL_LENGTH = 'cid_full_length'

class ImmuneStats:

	# Property
	@property
	def key(self) -> str:
		return self.__key

	@property
	def sample_name(self) -> Union[int, None]:
		return self.__values.get(StatsConst.SAMPLE_NAME.value, None)

	# count  frequency       CDR3nt  CDR3aa  V       D       J       C       cid     cid_full_length
	@property
	def count(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.COUNT.value)

	@property
	def frequency(self) -> Union[float, None]:
		return self.__fetch_float_value(StatsConst.FREQUENCY.value)

	@property
	def cdr3nt(self) -> Union[str, None]:
		return self.__values.get(StatsConst.CDR3NT.value, None)

	@property
	def cdr3aa(self) -> Union[str, None]:
		return self.__values.get(StatsConst.CDR3AA.value, None)

	@property
	def vregion(self) -> Union[str, None]:
		return self.__values.get(StatsConst.VREGION.value, None)

	@property
	def dregion(self) -> Union[str, None]:
		return self.__values.get(StatsConst.DREGION.value, None)

	@property
	def jregion(self) -> Union[str, None]:
		return self.__values.get(StatsConst.JREGION.value, None)

	@property
	def cregion(self) -> Union[str, None]:
		return self.__values.get(StatsConst.CREGION.value, None)

	@property
	def cid(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.CID.value)

	@property
	def cid_full_length(self) -> Union[int, None]:
		return self.__fetch_int_value(StatsConst.CID_FULL_LENGTH.value)

	@property
	def test(self):
		return self.__values

	def __init__(self, key: str, header: List[str], values: List[str]):
		self.__key = key
		self.__values = {}
		for i, col_name in enumerate(header):
			self.__values[col_name] = values[i]

	def __fetch_int_value(self, target: str) -> Union[int, None]:
		value = self.__values.get(target, None)
		if not value is None:
			value = int(value)

		if value == 'NA':
			value = None

		return value

	def __fetch_float_value(self, target: str) -> Union[float, None]:
		value = self.__values.get(target, None)
		if not value is None:
			value = float(value)

		if value == 'NA':
			value = None

		return value

# -------------------------------------
# region: Methods

def create_input_for_cogent_ds(work_dir: str, in_matrix: str, in_metadata: str) -> str:

	target_dir = path.abspath(path.join(work_dir, 'clonotype'))
	if not path.isdir(target_dir):
		mkdir(target_dir)


	output_matrix = path.join(target_dir, 'clonotype_matrix.csv')
	output_metadata = path.join(target_dir, 'metadata.csv')

	# Copy and edit intermediate matrix accommodate to CogentDS
	shutil.copyfile(in_matrix, output_matrix)
	with open(in_matrix, 'r') as in_f, open(output_matrix, 'w') as out_f:
		lines = in_f.readlines()
		items = lines[0].rstrip().split(',')[1:]
		lines[0] = ",".join([''] + items) + '\n'
		out_f.writelines(lines)

	shutil.copyfile(in_metadata, output_metadata)

	return target_dir

# def load_stats_file(input_dir: str, extra_target: str = None) -> Dict[str, ImmuneStats]:
# 	"""Load values in stats file to dictionary
# 	"""

# 	# Search stats.csv first
# 	files = glob(f'{input_dir}/*_stats.csv')
# 	stats_file = None
# 	if len(files) == 1:
# 		stats_file = files[0]
# 	elif len(files) == 0:
# 		raise CogentError(f'Cannot find stats.csv in {input_dir}')
# 	elif len(files) > 1:				# If 2 or more files are found (SSv4+UMI or error)
# 		if extra_target is not None:
# 			for f in files:
# 				if f.endswith(f'{extra_target}_stats.csv'):		# Find correct file name by SSV4+UMI
# 					stats_file = f
# 		else:
# 			raise CogentError(f'Too many stats.csv were found in {input_dir}')

# 	if stats_file is None:
# 		raise CogentError(f'Cannot find stats.csv in {input_dir}')

# 	# Load values
# 	stats = {}
# 	try:
# 		with open(stats_file, newline='') as csvfile:
# 			reader = csv.reader(csvfile, skipinitialspace = True)
# 			header = None
# 			for row in reader:
# 				if (len(row) > 0) and (not row[0].startswith('#')):
# 					if header is None:		# Retrieve header first
# 						del(row[0])			# Delete first column for "Barocode"
# 						header = row		# Keep other column names
# 						continue

# 					# Process values
# 					key = row[0]					# Fetch barcode
# 					del(row[0])						# Keep other column values
# 					stats[key] = AnalyzeStats(key, header, row)

# 	except EnvironmentError as err:
# 		raise CogentError(f"Unable to open file: {files[0]}", 'load_stats_file')

# 	return stats


'''
#def create_analyze_stats_header(is_use_umi: bool, is_use_uss: bool, is_stranded: bool, do_transcript: bool, use_combined: bool):
def create_immune_stats_header():
		"""Create list of header strings for stats.csv
		   no branching parameters for immune states
		"""

		headers = [
			StatsConst.BARCODE.value,
			StatsConst.SAMPLE_NAME.value,
			StatsConst.COUNT.value,
			StatsConst.FREQUENCY.value,
			StatsConst.CDR3NT.value,
			StatsConst.CDR3AA.value,
			StatsConst.VREGION.value,
			StatsConst.DREGION.value,
			StatsConst.JREGION.value,
			StatsConst.CREGION.value,
			StatsConst.CID.value,
			StatsConst.CID_FULL_LENGTH.value
		]
		# print headers
		return headers


def get_clonotype_tsv_files(input_dir: str, barcodes: List[str]) -> Dict[str, tuple]:

	# Search immune directory first
	immune_dir = path.join(input_dir, 'immune')
	if not path.isdir(immune_dir):
		raise CogentError(f'Cannot find bam directory in {input_dir}')

	# Listup all files in the directory
	file_list = listdir(immune_dir)

	# Find BAM files having each barcode for transcript counting
	clonotype_tsv_files = {}
	for barcode in barcodes:
		if barcode in DemuxConst.to_list():			# Skip for non sample such as Short, Unselected and Undetermined.
			continue

		file_name = f'{barcode}_report.tsv'
		if not file_name in file_list:
			raise CogentError(f'Cannot find clonotype tsv file for {barcode}')

		clonotype_tsv_files[barcode] = (path.join(immune_dir, file_name),)

	return clonotype_tsv_files
'''
# endregion: Methods
# -------------------------------------
