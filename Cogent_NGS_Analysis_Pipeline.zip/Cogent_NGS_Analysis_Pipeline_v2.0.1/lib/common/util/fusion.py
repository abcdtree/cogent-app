from os import mkdir, path
import shutil

# -------------------------------------
# region: Methods

def create_input_for_cogent_ds(work_dir: str, in_junction_matrix: str, in_spanning_matrix: str, in_metadata: str) -> str:

	target_dir = path.abspath(path.join(work_dir, 'gene_fusion'))
	if not path.isdir(target_dir):
		mkdir(target_dir)

	output_junction_matrix = path.join(target_dir, 'gene_fusion.junction_reads.csv')
	output_spanning_matrix = path.join(target_dir, 'gene_fusion.span_frags.csv')
	output_metadata = path.join(target_dir, 'gene_fusion.metadata.csv')

	shutil.copyfile(in_junction_matrix, output_junction_matrix)
	with open(in_junction_matrix,'r') as in_f, open(output_junction_matrix, 'w') as out_f:
		lines = in_f.readlines()
		items = lines[0].rstrip().split(',')[1:]
		lines[0] = ",".join([''] + items) + '\n'
		out_f.writelines(lines)

	shutil.copyfile(in_spanning_matrix, output_spanning_matrix)
	with open(in_spanning_matrix,'r') as in_f2, open(output_spanning_matrix, 'w') as out_f2:
		lines = in_f2.readlines()
		items = lines[0].rstrip().split(',')[1:]
		lines[0] = ",".join([''] + items) + '\n'
		out_f2.writelines(lines)

	shutil.copyfile(in_metadata, output_metadata)

	return target_dir

# endregion: Methods
# -------------------------------------
