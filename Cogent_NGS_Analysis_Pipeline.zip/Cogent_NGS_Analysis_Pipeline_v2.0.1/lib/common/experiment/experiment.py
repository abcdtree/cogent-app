#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Abstract class to define required contents for experiment
#
# Required:
#	-

from abc import ABCMeta, abstractmethod
from typing import Dict, List, Tuple, Union
from analyze.data.report.expression_report import ExpressionReport
from analyze.data.summarize.expression_summarize import ExpressionSummarize
from common.analyze.base_summarize import BaseSummarize
from common.cogent_ds.ds_config_meta import DsConfigMeta
from common.util.const import AnalysisType, DebugMode, NormalizeMethod, ReadMode, StrandedMode, UssMode

class Experiment(metaclass = ABCMeta):

	# ---------------------------------
	# region: Abstract Property (to be implemented in each class)
	@property
	@abstractmethod
	def name(self) -> str:
		"""Experiment type name

		Returns:
			str: Experiment type name
		"""
		...

	@property
	@abstractmethod
	def read_mode(self) -> ReadMode:
		"""Read mode to define which read (R1, R2) or both are input, kept and analyzed.

		Returns:
			ReadMode: Read mode
		"""
		...

	@property
	@abstractmethod
	def check_revcomp(self) -> bool:
		"""Whether check reverse complement about barcodes

		Returns:
			bool: True if check
		"""
		...

	@property
	@abstractmethod
	def dual_index_barcode(self) -> bool:
		"""Whether dual index barcode is used like full-length chemistry

		Returns:
			bool: True if dual index
		"""
		...

	@property
	@abstractmethod
	def use_read2_for_demux(self) -> bool:
		"""Whether use read2 for demultiplexing like Strnd_UMI (PicoV3)

		Returns:
			bool: True if use read2
		"""
		...

	@property
	@abstractmethod
	def umi_length(self) -> Union[int, None]:
		"""UMI length to be cut out

		Returns:
			Union[int, None]: Number of UMI length. None if UMI is disabled.
		"""
		...

	@property
	@abstractmethod
	def is_use_uss(self) -> bool:
		"""Flag to use uss for collaption

		Returns:
			bool: True if use
		"""
		...

	@property
	@abstractmethod
	def uss_mode(self) -> UssMode:
		"""Mode for USS collaption. This option will be ignored when is_use_uss = False.

		Returns:
			UssMode: [description]
		"""
		...

	@property
	@abstractmethod
	def stranded_mode(self) -> StrandedMode:
		"""Mode to specify stranded

		Returns:
			StrandedMode: None, forward or reverse
		"""
		...

	@property
	@abstractmethod
	def norm_method(self) -> NormalizeMethod:
		"""Normalize method for CogentDS analysis (cpm, tpm or fpkm is acceptable)

		Returns:
			NormalizeMethod: Method type to normalize
		"""
		...

	@property
	@abstractmethod
	def support_analysis(self) -> List[AnalysisType]:
		"""Analysis that this experiment type supports (e.g. gene, transcript, fusion or immune)

		Returns:
			List[AnalysisType]: Analysis types
		"""
		...

	@property
	@abstractmethod
	def main_result_prefix(self) -> Union[str, None]:
		"""Use this property only when 2 or more genematrix (and stats.csv) generated from analyze and want to create RDA file from CogentDS.
			Only for SSv4+UMI for now.

		Returns:
			str: name to search (e.g. _all). '_genematrix.csv' and '_stats.csv' will be automatically added.
		"""
		...

	@property
	@abstractmethod
	def cogent_ds_config(self) -> Union[DsConfigMeta, None]:
		"""Use this property to specify configuration for CogentDS to create rda files.
			Return None indicates automatically find genematrix and stats.csv, however, it will be error if there are two ore more genematrix (or stats.csv).
			This property is typically used in SSv4+UMI for now.

		Returns:
			 Union[DsConfigMeta, None]: see document above
		"""
		...


	# endregion: Abstract Property
	# ---------------------------------

	# ---------------------------------
	# region: Implemented Property
	@property
	def is_paired(self) -> bool:
		return self.read_mode == ReadMode.PAIRED

	@property
	def is_use_umi(self) -> bool:
		return not self.umi_length is None

	@property
	def is_stranded(self) -> bool:
		return self.stranded_mode is not StrandedMode.NONE

	@property
	def is_support_gene(self) -> bool:
		return AnalysisType.GENE in self.support_analysis

	@property
	def is_support_transcript(self) -> bool:
		return AnalysisType.TRANSCRIPT in self.support_analysis

	@property
	def is_support_fusion(self) -> bool:
		return AnalysisType.FUSION in self.support_analysis

	@property
	def is_support_immune(self) -> bool:
		return AnalysisType.IMMUNE in self.support_analysis

	# endregion: Implemented Property
	# ---------------------------------

	# ---------------------------------
	# region: Implemented method
	def initialize(self, config_dir: str):
		"""Overwrite this function to initialize class if necessary. Typically for SSv4+UMI only for now.

		Args:
			config_dir (str): Path to config directory
		"""
		return	# Do nothing

	# endregion: Implemented method
	# ---------------------------------

	# ---------------------------------
	# region: Abstract Method

	@abstractmethod
	def get_background_info(self, repository_path: str, input_bcs: List[str], input_index_pos: int) -> Tuple[List[str], Union[str, None], Union[str, None], int]:
		"""Get barcodes or hamming distance references

		Returns:
			Dict[str, Union[str, None]]: Dictionary contains 'bc_map', 'hh1' and 'hh2'. Each key corresponds a file path.
		"""
		...

	@abstractmethod
	def get_barcode(self, read_info, barcode_length: int, umi_length: int) -> Tuple[str, str]:
		"""Get barcode string and UMI string from a read.

		Args:
			read_info (Sequence object from dnaio): Read information including tag, read and quality

		Returns:
			Tuple[str, str]: barcode and UMI
		"""
		...

	@abstractmethod
	def process_read_on_demux(self, read1, read2, barcode: str, barcode_length: int, umi: str):
		"""Function to process reads on demultiplexing part

		Args:
			read1 (Sequence object from dnaio): Read1
			read2 (Sequence object from dnaio): Read2
			barcode (str): Barcode string
			barcode_length (int): Barcode length
			umi (str): UMI string
		"""
		...

	@abstractmethod
	def get_summarize_obj(self, key: str, work_dir: str, do_transcript: bool, debug_mode: DebugMode) -> ExpressionSummarize:
		"""Function to generate summarizing object for expression counting

		Args:
			key (str): Key for the object. Basically it will be barcode.
			work_dir (str): Working directory
			do_transcript (bool): Flag to transcript counting
			debug_mode (DebugMode): Mode for debugging

		Returns:
			BaseSummarize: [description]
		"""
		...

	@abstractmethod
	def get_report_obj(self, summary_objects: Dict[str, BaseSummarize], out_dir: str, out_prefix: str, do_transcript: bool, do_immune: bool, do_fusion: bool, debug_mode: DebugMode) -> ExpressionReport:
		"""Function to generate reporting object to create final output files. Generally, it does merging files from multi-threads processing.

		Args:
			summary_objects (Dict[str, BaseSummarize]): Summary objects dictionary from processor
			out_dir (str): Base path for output directory
			out_prefix (str): Prefix for output files
			do_transcript (bool): Flag if doing transcript analysis
			debug_mode (DebugMode): Debug mode

		Returns:
			BaseReport: Instantiated Reporting object
		"""
		...

	# endregion: Abstract method
	# ---------------------------------
