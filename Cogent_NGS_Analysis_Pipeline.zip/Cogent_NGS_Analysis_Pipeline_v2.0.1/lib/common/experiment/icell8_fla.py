#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to specify ICELL8 Full length analysis
#
# Required:
#	-

from os import path
from typing import Any, Dict, List, Tuple, Union, cast
from analyze.data.report.expression_report import ExpressionReport
from analyze.data.report.normal_report import NormalReport
from analyze.data.summarize.expression_summarize import ExpressionSummarize
from common.analyze.base_report import BaseReport
from common.analyze.base_summarize import BaseSummarize
from common.cogent_ds.ds_config_meta import DsConfigMeta
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import AnalysisType, DebugMode, NormalizeMethod, ReadMode, StrandedMode, UssMode
from demux.barcode_reader import BarcodeReader

from analyze.data.summarize.normal_summarize import NormalSummarize

class FullLength(Experiment):

	# ---------------------------------
	# region: Property
	@property
	def name(self) -> str:
		return 'ICELL8_FLA'

	@property
	def read_mode(self) -> ReadMode:
		return ReadMode.PAIRED

	@property
	def check_revcomp(self) -> bool:
		return True

	@property
	def dual_index_barcode(self) -> bool:
		return True

	@property
	def use_read2_for_demux(self) -> bool:
		return False

	@property
	def umi_length(self) -> Union[int, None]:
		return None

	@property
	def stranded_mode(self) -> StrandedMode:
		return StrandedMode.NONE

	@property
	def is_use_uss(self) -> bool:
		return False

	@property
	def uss_mode(self) -> UssMode:
		return UssMode.NONE

	@property
	def norm_method(self) -> NormalizeMethod:
		return NormalizeMethod.CPM

	@property
	def support_analysis(self) -> List[AnalysisType]:
		return [AnalysisType.GENE, AnalysisType.TRANSCRIPT, AnalysisType.FUSION, AnalysisType.IMMUNE]

	@property
	def main_result_prefix(self) -> Union[str, None]:
		return None

	@property
	def cogent_ds_config(self) -> Union[DsConfigMeta, None]:
		return None

	# endregion: Property
	# ---------------------------------

	# ---------------------------------
	# region: Methods
	def get_background_info(self, repository_path: str, input_bcs: List[str], input_index_pos: int) -> Tuple[List[str], Union[str, None], Union[str, None], int]:

		bc_map = {
			"set_a": path.join(repository_path, 'config', 'barcode_map_full_length_v1.csv'),
			"set_b": path.join(repository_path, 'config', 'barcode_map_full_length_v2.csv')
		}
		hh1 = {
			"set_a": path.join(repository_path, 'config', 'barcode_map_ham_I7_v1.csv'),
			"set_b": path.join(repository_path, 'config', 'barcode_map_ham_I7_v2.csv')
		}

		hh2 = {
			"set_a": path.join(repository_path, 'config', 'barcode_map_ham_I5_v1.csv'),
			"set_b": path.join(repository_path, 'config', 'barcode_map_ham_I5_v2.csv')
		}

		reader_a = BarcodeReader(bc_map["set_a"])
		reader_a.read()
		a_bcs = reader_a.barcode_list
		idx_a_bcs = reader_a.separator_pos

		reader_b = BarcodeReader(bc_map["set_b"])
		reader_b.read()
		b_bcs = reader_b.barcode_list
		idx_b_bcs = reader_b.separator_pos

		if set(input_bcs) <= set(a_bcs) and input_index_pos == idx_a_bcs:
			Logger.info_logger("Detected Full Length Set A Barcodes.")
			return (a_bcs, hh1["set_a"], hh2["set_a"], idx_a_bcs)

		elif set(input_bcs) <= set(b_bcs) and input_index_pos == idx_b_bcs:
			Logger.info_logger("Detected Full Length Set B Barcodes.")
			return (b_bcs, hh1["set_b"], hh2["set_b"], idx_a_bcs)

		elif set(input_bcs) <= set(a_bcs + b_bcs):
			Logger.info_logger("Detected Full Length Set A & B Barcodes.")
			return (a_bcs + b_bcs, None, None, idx_a_bcs)

		else:
			Logger.info_logger("All barcodes not found in Full Length Set A/B background. Background set to selected barcode list, hamming distance maps to be generated denovo.")
			return (input_bcs, None, None, input_index_pos)

	def get_barcode(self, read_info, barcode_length: int, umi_length: int) -> Tuple[str, str]:
		barcode = ''.join(filter(str.isalpha, read_info.name.split()[1].split(':')[-1]))
		return (barcode, 'NA')

	def process_read_on_demux(self, read1, read2, barcode: str, barcode_length: int, umi: str):
		tmp = read1.name.split()
		tmp[0] += "".join(['_', barcode])
		read1.name = " ".join(tmp)

		tmp = read2.name.split()
		tmp[0] += "".join(['_', barcode])
		read2.name = " ".join(tmp)

	def get_summarize_obj(self, key: str, work_dir: str, do_transcript: bool, debug_mode: DebugMode) -> ExpressionSummarize:
		return NormalSummarize(key, work_dir, self, do_transcript, debug_mode)

	def get_report_obj(self, summary_objects: Dict[str, BaseSummarize], out_dir: str, out_prefix: str, do_transcript: bool, do_immune: bool, do_fusion: bool, debug_mode: DebugMode) -> ExpressionReport:
		cast_obj = cast(Dict[str, NormalSummarize], summary_objects)
		return NormalReport(cast_obj, out_dir, out_prefix, self, do_transcript, do_immune, do_fusion, debug_mode)

	# endregion: Methods
	# ---------------------------------