#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Special class accommodate to QIASeq miRNA seq. This class beta version and only for internal use for now.
#
# Required:
#	-

from typing import Dict, List, Tuple, Union, cast
from analyze.data.report.expression_report import ExpressionReport
from analyze.data.report.normal_report import NormalReport
from analyze.data.summarize.expression_summarize import ExpressionSummarize
from analyze.data.summarize.normal_summarize import NormalSummarize
from common.analyze.base_summarize import BaseSummarize
from common.cogent_ds.ds_config_meta import DsConfigMeta
from common.experiment.experiment import Experiment
from common.util.const import AnalysisType, DebugMode, NormalizeMethod, ReadMode, StrandedMode, UssMode

class QIASeqMiRNA(Experiment):

	# ---------------------------------
	# region: Constants
	COMMON_SEQUENCE = 'AACTGTAGGCACCATCAAT'
	# endregion
	# ---------------------------------

	# ---------------------------------
	# region: Property
	@property
	def name(self) -> str:
		return 'QIASeq_miRNA'

	@property
	def read_mode(self) -> ReadMode:
		return ReadMode.READ1

	@property
	def check_revcomp(self) -> bool:
		return True

	@property
	def dual_index_barcode(self) -> bool:
		return False

	@property
	def use_read2_for_demux(self) -> bool:
		return False

	@property
	def umi_length(self) -> Union[int, None]:
		return 12

	@property
	def stranded_mode(self) -> StrandedMode:
		return StrandedMode.FORWARD

	@property
	def is_use_uss(self) -> bool:
		return False

	@property
	def uss_mode(self) -> UssMode:
		return UssMode.NONE

	@property
	def norm_method(self) -> NormalizeMethod:
		return NormalizeMethod.CPM

	@property
	def support_analysis(self) -> List[AnalysisType]:
		return [AnalysisType.GENE, AnalysisType.TRANSCRIPT]

	@property
	def main_result_prefix(self) -> Union[str, None]:
		return None

	@property
	def cogent_ds_config(self) -> Union[DsConfigMeta, None]:
		return None

	# endregion: Property
	# ---------------------------------

	# ---------------------------------
	# region: Methods
	def get_background_info(self, repository_path: str, input_bcs: List[str], input_index_pos: int) -> Tuple[List[str], Union[str, None], Union[str, None], int]:
		return (input_bcs, None, None, input_index_pos)

	def get_barcode(self, read_info, barcode_length: int, umi_length: int) -> Tuple[str, str]:

		# Get barcode from read tag
		barcode = ''.join(filter(str.isalpha, read_info.name.split()[1].split(':')[-1]))

		# Find common sequence and get following bases as UMI
		umi = 'NA'
		if self.COMMON_SEQUENCE in read_info.sequence:
			if read_info.sequence.index(self.COMMON_SEQUENCE) == 0:
				barcode = 'short'
			else:
				start_pos = read_info.sequence.index(self.COMMON_SEQUENCE) + len(self.COMMON_SEQUENCE)	# Calculate start position to get UMI
				umi = read_info.sequence[start_pos:start_pos+umi_length]								# Substring bases
				if 'N' in umi or len(umi) != umi_length:												# Check UMI and if it's length is correct.
					barcode = 'short'
		else:
			barcode = 'N'

		return (barcode, umi)

	def process_read_on_demux(self, read1, read2, barcode: str, barcode_length: int, umi: str):

		# Add barcode and umi information to read tag
		tmp = read1.name.split()
		tmp[0] += '_' + barcode + '_' + umi
		read1.name = " ".join(tmp)

		# trim reads by common sequence
		end_pos = read1.sequence.index(self.COMMON_SEQUENCE)
		read1.sequence = read1.sequence[:end_pos]
		read1.qualities = read1.qualities[:end_pos]

	def get_summarize_obj(self, key: str, work_dir: str, do_transcript: bool, debug_mode: DebugMode) -> ExpressionSummarize:
		return NormalSummarize(key, work_dir, self, do_transcript, debug_mode)

	def get_report_obj(self, summary_objects: Dict[str, BaseSummarize], out_dir: str, out_prefix: str, do_transcript: bool, do_immune: bool, do_fusion: bool, debug_mode: DebugMode) -> ExpressionReport:
		cast_obj = cast(Dict[str, NormalSummarize], summary_objects)
		return NormalReport(cast_obj, out_dir, out_prefix, self, do_transcript, do_immune, do_fusion, debug_mode)

	# endregion: Methods
	# ---------------------------------
