from datetime import datetime
from os import path
import os
import shutil
from typing import Dict, List, Union
from analyze.data.report.expression_report import ExpressionReport
from analyze.data.summarize.normal_summarize import NormalSummarize
from common.cogent_error import CogentError

from common.logger import Logger
from common.experiment.experiment import Experiment
from common.util.analyze import create_analyze_stats_header
from common.util.const import DebugMode
from common.util.demux import DemuxSummary
from common.util.util import elapsed_time, load_csv_as_dict
from run_fusion_analysis.data.fusion_report import FusionReport
from run_immune_analysis.data.immune_report import ImmuneReport
from run_transcript_analysis.data.rsem_report import RsemReport

class NormalReport(ExpressionReport):

	# -----------------------------------------------------------------------------
	# region: Property

	@property
	def exon_stats_file(self) -> str:
		return self.__exon_stats_file

	@property
	def gene_stats_file(self) -> str:
		return self.__gene_stats_file

	@property
	def exon_matrix(self) -> str:
		return self.__exon_matrix

	@property
	def gene_matrix(self) -> str:
		return self.__gene_matrix

	@property
	def exon_umi_uss_matrix(self) -> Union[str, None]:
		return self.__exon_umi_uss_matrix

	@property
	def gene_umi_uss_matrix(self) -> Union[str, None]:
		return self.__gene_umi_uss_matrix

	@property
	def exon_umi_matrix(self) -> Union[str, None]:
		return self.__exon_umi_matrix

	@property
	def gene_umi_matrix(self) -> Union[str, None]:
		return self.__gene_umi_matrix

	@property
	def exon_uss_matrix(self) -> Union[str, None]:
		return self.__exon_uss_matrix

	@property
	def gene_uss_matrix(self) -> Union[str, None]:
		return self.__gene_uss_matrix

	@property
	def umi_dist_file(self) -> str:
		return self.__umi_dist_report

	@property
	def umi_effect_file(self) -> str:
		return self.__umi_effect_report

	@property
	def main_genematrix(self) -> str:
		if self.__experiment.is_use_umi:
			if self.__experiment.is_use_uss:
				if self.__exon_umi_uss_matrix is None:
					raise CogentError('Unable to detect main genematrix.')

				return self.__exon_umi_uss_matrix
			else:
				if self.__exon_umi_matrix is None:
					raise CogentError('Unable to detect main genematrix.')

				return self.__exon_umi_matrix
		else:
			return self.__exon_matrix

	@property
	def main_stats(self) -> str:
		return self.__exon_stats_file

	@property
	def main_transcript_matrix(self) -> Union[str, None]:
		return self.__transcript_matrix

	@property
	def gene_info_file(self) -> str:
		return self.__exon_info_file

	@property
	def transcript_info_file(self) -> Union[str, None]:
		return self.__transcript_info_file

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, summary_objects: Dict[str, NormalSummarize], output_dir: str, prefix: str, experiment: Experiment, do_transcript: bool, do_immune: bool, do_fusion: bool, debug_mode: DebugMode):

		self.__summary_objects = summary_objects
		self.__out_dir = output_dir
		self.__prefix = prefix
		self.__experiment = experiment

		self.__extras_dir = path.join(self.__out_dir, 'extras')													# Extras dir, candidate
		os.makedirs(self.__extras_dir, exist_ok=True)															# Create dir for extra files

		self.__debug_mode = debug_mode

		# For transcript counting
		self.__do_transcript = do_transcript
		self.__trans_dir = path.join(self.__out_dir, 'transcript')
		if do_transcript:
			os.makedirs(self.__trans_dir, exist_ok=True)

		# For immune profiling
		self.__do_immune = do_immune
		self.__immune_dir = path.join(self.__out_dir, 'immune')
		if do_immune:
			os.makedirs(self.__immune_dir, exist_ok=True)

		# For gene fusion analysis
		self.__do_fusion = do_fusion
		self.__fusion_dir = path.join(self.__out_dir, 'gene_fusion')
		if do_fusion:
			os.makedirs(self.__fusion_dir, exist_ok=True)

		# Define file names
		self._define_files_path(output_dir, self.__extras_dir, prefix, experiment, debug_mode)

	# -----------------------------------------------------------------------------
	# region: Implementation for abstract methods

	def create(self, key_list: List[str], exon_gene_info_file: str, intron_gene_info_file: str, transcript_info_file: Union[str, None], demux_summary: Dict[str, DemuxSummary]):
		"""Create final result files from split files.
		"""

		# Create result files
		Logger.info_logger('Started creating report files, matrix files and stats files.')
		start_time = datetime.now()

		# -----
		# stats
		self._merge_stats(			# exon
			key_list, {key:item.exon_stats_file for key, item in self.__summary_objects.items()}, self.__exon_stats_file, summary=demux_summary)
		self._merge_stats(			# including introns
			key_list, {key:item.intron_stats_file for key, item in self.__summary_objects.items()}, self.__gene_stats_file, summary=demux_summary)

		# -----
		# matrix

		# Load gene info
		gene_info = load_csv_as_dict(exon_gene_info_file, key_col=1, skip_header=True)

		# exon
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.exon_counts_file for key, item in self.__summary_objects.items()}, self.__exon_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.exon_umi_uss_counts_file for key, item in self.__summary_objects.items()}, self.__exon_umi_uss_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.exon_umi_counts_file for key, item in self.__summary_objects.items()}, self.__exon_umi_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.exon_uss_counts_file for key, item in self.__summary_objects.items()}, self.__exon_uss_matrix)

		# gene
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.gene_counts_file for key, item in self.__summary_objects.items()}, self.__gene_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.gene_umi_uss_counts_file for key, item in self.__summary_objects.items()}, self.__gene_umi_uss_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.gene_umi_counts_file for key, item in self.__summary_objects.items()}, self.__gene_umi_matrix)
		self._merge_matrix('GeneID', key_list, gene_info, {key:item.gene_uss_counts_file for key, item in self.__summary_objects.items()}, self.__gene_uss_matrix)

		# transcript
		if self.__do_transcript:
			Logger.info_logger('Create report files for transcript expression.')

			if transcript_info_file is None:
				raise CogentError('Cannot detect transcript info file for reporting.')

			# transcript_results = {key:item.transcript_result for key, item in result_objects.items()}
			transcript_results = {}
			for key, item in self.__summary_objects.items():
				if item.transcript_result is None:
					raise CogentError('Cannot detect transcript expression result for reporting.')

				transcript_results[key] = item.transcript_result

			rsem_report = RsemReport(self.__trans_dir, self.__prefix, self.__experiment, False)
			rsem_report.create(key_list, transcript_results, transcript_info_file)

			self.__transcript_matrix = rsem_report.matrix
			self.__transcript_info_file = rsem_report.info_file
		else:
			self.__transcript_matrix = None
			self.__transcript_info_file = None

		# Immune profiling
		if self.__do_immune:
			Logger.info_logger('Create report files for immune profiling.')

			immune_results = {}
			for key, item in self.__summary_objects.items():
				if item.immune_result is None:
					raise CogentError('Cannot detect immune profiling result for reporting.')

				immune_results[key] = item.immune_result

			immune_report = ImmuneReport(self.__immune_dir, self.__prefix, self.__experiment)
			immune_report.create(key_list, immune_results, demux_summary)

			# Need to set to property?

		# Gene fusion
		if self.__do_fusion:
			Logger.info_logger('Create report files for gene fusion.')

			fusion_results = {}
			for key, item in self.__summary_objects.items():
				if item.fusion_result is None:
					raise CogentError('Cannot detect gene fusion result for reporting.')

				fusion_results[key] = item.fusion_result

			fusion_report = FusionReport(self.__fusion_dir, self.__prefix, self.__experiment)
			fusion_report.create(key_list, fusion_results, demux_summary)

		# Create UMI reports
		if self.__experiment.is_use_umi and self.__debug_mode is DebugMode.HIGH:
			Logger.info_logger('Create UMI counting reports.')
			self._merge_umi_report(key_list, {key:item.umi_dist_file for key, item in self.__summary_objects.items()}, self.__umi_dist_report)
			self._merge_umi_effect(key_list, {key:item.umi_effect_file for key, item in self.__summary_objects.items()}, self.__umi_effect_report)

		# Move gene info files to certain directory
		self.__exon_info_file = shutil.move(exon_gene_info_file, self.__out_dir)				# Move gene_info to output dir
		self.__gene_info_file = shutil.move(intron_gene_info_file, self.__extras_dir)			# Move extra gene_info to extra dir

		Logger.info_logger("Successfully completed reporting. Time elapsed: " + elapsed_time(start_time))

	def _define_files_path(self, out_dir: str, extras_dir: str, prefix: str, experiment: Experiment, debug_mode: DebugMode):
		self.__exon_stats_file = path.join(out_dir, prefix + "_stats.csv")
		self.__gene_stats_file = path.join(extras_dir, prefix + "_incl_introns_stats.csv")

		self.__exon_umi_uss_matrix = None
		self.__gene_umi_uss_matrix = None
		self.__exon_umi_matrix = None
		self.__gene_umi_matrix = None
		self.__exon_uss_matrix = None
		self.__gene_uss_matrix = None

		if experiment.is_use_umi:
			self.__exon_matrix = path.join(extras_dir, prefix + "_genematrix.csv")
			self.__gene_matrix = path.join(extras_dir, prefix + "_incl_introns_genematrix.csv")

			if experiment.is_use_uss:
				self.__exon_umi_uss_matrix = path.join(out_dir, prefix + "_umi_uss_genematrix.csv")
				self.__gene_umi_uss_matrix = path.join(extras_dir, prefix + "_incl_introns_umi_uss_genematrix.csv")

				if debug_mode is DebugMode.HIGH:
					self.__exon_umi_matrix = path.join(extras_dir, prefix + "_umi_genematrix.csv")					# only for uss enabled
					self.__gene_umi_matrix = path.join(extras_dir, prefix + "_incl_introns_umi_genematrix.csv")		# because will be created to output dir, if uss disabled

					self.__exon_uss_matrix = path.join(extras_dir, prefix + "_uss_genematrix.csv")
					self.__gene_uss_matrix = path.join(extras_dir, prefix + "_incl_introns_uss_genematrix.csv")
			else:
				self.__exon_umi_matrix = path.join(out_dir, prefix + "_umi_genematrix.csv")
				self.__gene_umi_matrix = path.join(extras_dir, prefix + "_incl_introns_umi_genematrix.csv")

			if debug_mode is DebugMode.HIGH:
				self.__umi_dist_report = path.join(extras_dir, "umi_distribution_report.csv")
				self.__umi_effect_report = path.join(extras_dir, "umi_effect_report.csv")
		else:
			self.__exon_matrix = path.join(out_dir, prefix + "_genematrix.csv")
			self.__gene_matrix = path.join(extras_dir, prefix + "_incl_introns_genematrix.csv")

	def _create_stats_header(self) -> List[str]:
		return create_analyze_stats_header(self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded, self.__do_transcript, False)

	# endregion: Implementation for abstract methods
	# -----------------------------------------------------------------------------
