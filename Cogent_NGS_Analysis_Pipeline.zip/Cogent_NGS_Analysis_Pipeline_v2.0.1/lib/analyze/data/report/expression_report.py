from abc import ABCMeta, abstractmethod
from typing import Dict, List, Union
from common.analyze.base_report import BaseReport
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.demux import DemuxSummary

class ExpressionReport(BaseReport, metaclass = ABCMeta):

	# Re-define for abstract method
	@abstractmethod
	def create(self, key_list: List[str], exon_gene_info_file: str, intron_gene_info_file: str, transcript_info_file: Union[str, None], demux_summary: Dict[str, DemuxSummary] = None):
		...

	# ---------------------------------
	# region: Abstract property
	@property
	@abstractmethod
	def main_genematrix(self) -> str:
		"""Path to genematrix located in output directory and used for CogentDS

		Returns:
			str: Path to file
		"""
		...

	@property
	@abstractmethod
	def main_stats(self) -> str:
		"""Path to stats.csv located in output directory and used for CogentDS

		Returns:
			str: Path to file
		"""
		...

	@property
	@abstractmethod
	def main_transcript_matrix(self) -> Union[str, None]:
		"""Path to transcript matrix used for CogentDS

		Returns:
			Union[str, None]: Path to file
		"""
		...

	@property
	@abstractmethod
	def gene_info_file(self) -> str:
		"""Path to gene_info.csv

		Returns:
			str: Path to file
		"""
		...

	@property
	@abstractmethod
	def transcript_info_file(self) -> Union[str, None]:
		"""Path to transcript_info.csv

		Returns:
			str: Path to file
		"""
		...
	# endregion: Abstract property
	# ---------------------------------

	# ---------------------------------
	# region: Protected method
	def _merge_umi_report(self, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split UMI report into one file

		Arguments:
			in_files {[type]} -- Split files
			out_file {[type]} -- Path to output file

		Returns:
			bool -- Success flag
		"""

		if out_file is None:
			return True

		try:
			# Load each file
			header_values = ['UMI']
			load_data = {}
			for key in key_list:
				if not key in in_files:
					raise CogentError(f'Result about {key} is not found.')

				with open(in_files[key], 'r') as f:
					barcode = f.readline().strip().split(',')[1]		# Retrieve barcode
					header_values.append(barcode)						# Add sample name for header string

					load_data[barcode] = {}
					for line in f:
						umi, value = line.strip().split(',')
						load_data[barcode][umi] = value

			# Summarize UMIs
			umi_set = set()
			for data_set in load_data.values():
				umi_set.update(data_set.keys())

			with open(out_file, 'w') as f:
				f.write(','.join(header_values) + '\n')
				for umi in sorted(list(umi_set)):
					f.write(umi + ',' + ','.join([barcode_umi_data.get(umi, '0') for barcode_umi_data in load_data.values()]) + '\n')

			return True
		except KeyError as err:
			Logger.error_both(f'Illegal barcode or UMI: {err}')
			return False

	def _merge_umi_effect(self, key_list: List[str], in_files: Dict[str, str], out_file: Union[str, None]) -> bool:
		"""Merge split UMI effect report

		Arguments:
			in_files {[type]} -- Split report files
			out_file {[type]} -- Path to output file

		Returns:
			bool -- Success flag
		"""

		if out_file is None:
			return True

		with open(out_file, 'w') as out_stream:

			# write header
			data = ['Barcode', 'GeneID', 'Raw', 'UMI', 'USS', 'UMI&USS', 'UMI/Raw', 'USS/Raw', 'UMI&USS/Raw']
			out_stream.write(','.join(data) + '\n')

			for key in key_list:
				if not key in in_files:
					raise CogentError(f'Result about {key} is not found.')

				with open(in_files[key], 'r') as f:
					out_stream.write(f.read())

		return True

	# endregion: Protected method
	# ---------------------------------




