#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to perform and handle gene expression counting.
# This class holds count stats for each barcode.
#

import csv
from enum import Enum
import re

from typing import List, Union

from common.logger import Logger
from analyze.data.count_stats import CountStats, CountType
from common.cogent_error import CogentError
from common.util.analyze import AnalyzeStats
from common.util.util import quantize

class ResultType(Enum):
	EXON = 'exon'
	GENE = 'gene'

class ExpressionParser:
	"""
	Handles counted values of all barcodes as expression values.
	Also having functions for reporting.
	"""

	# --- constants ---
	# DEMUX_SHORT = 'Short'
	# DEMUX_UNSELECT = 'Unselected'
	# DEMUX_UNDETERMINED = 'Undetermined'

	TYPE_ASSIGNED = 'Assigned'
	TYPE_AMBIGUITY = 'Unassigned_Ambiguity'
	TYPE_NO_FEATURE = 'Unassigned_NoFeatures'
	TYPE_MULTI_MAP = 'Unassigned_MultiMapping'
	TYPE_SINGLETON = 'Unassigned_Singleton'

	# on initialize
	def __init__(self, key: str, is_use_umi: bool, is_use_uss: bool, is_stranded: bool, do_transcript: bool, umi_length: int = None, out_no_umi_reads: bool = False):
		"""Initialize function. Save passed parameters.

		Arguments:
			demux_counts {Dict[str, List]} -- Demux count dictionary loaded from result file of demux sub command.
			use_umi {bool} -- UMI is enabled, or not.
			use_uss {bool} -- USS is enabled, or not.
		"""
		self.__key = key
		self.__is_use_umi = is_use_umi
		self.__is_use_uss = is_use_uss
		self.__is_stranded = is_stranded

		self.__count_stats = CountStats(key)
		self.__align_info = {}

		self.__do_transcript = do_transcript
		self.__num_transcripts = -1

		self.__ignore_umi = None
		if not umi_length is None:
			self.__ignore_umi = 'N' * umi_length			# UMI string to ignore for results. Reads including this UMI are discarded.

		self.__out_no_umi_reads = out_no_umi_reads			# Flag to output number of UMI reads (typically for 5pUMI only)

	# --- methods ---
	# # Add alignment info
	def add_align_info(self, csv_file: str) -> bool:
		"""Register UMI/USS info to this class

		Arguments:
			csv_file {str} -- CSV file parsed from BAM

		Returns:
			bool -- Read successfully, or not
		"""
		try:
			with open(csv_file, newline='') as csvfile:
				reader = csv.reader(csvfile, skipinitialspace = True)

				for row in reader:
					read_name = row[0]

					self.__align_info[read_name] = row[1:]		# Set dict for barcode

			return True
		except EnvironmentError as err:
			raise CogentError(f'Unable to open file: {csv_file}')

	# Add featureCount info for expression
	def add_exon_feature_count(self, data: str):
		"""Process a line from .exon.featureCounts

		Arguments:
			data {str} -- A line from .exon.featureCounts
		"""
		# Split values
		tag, assign_type, dummy, gene = re.split('\t', data.rstrip())
		read_name, barcode, umi = self.__parse_tag(tag)

		if not self.__ignore_umi is None and self.__ignore_umi == umi:		# Ignore reads having specific UMI bases, typically all N
			return

		if assign_type == self.TYPE_SINGLETON:								# skip if singleton, could be unmapped
			return

		# Counting
		if assign_type == self.TYPE_ASSIGNED:
			uss = ''														# Initialize for no UMI mode
			if self.__is_use_umi and self.__is_use_uss:
				umi, uss = self.__align_info[read_name]						# Search for UMI and USS

			self.__count_stats.add_exon_assigned(gene, umi, uss)
		elif assign_type == self.TYPE_AMBIGUITY:
			self.__count_stats.add_exon_ambiguity()
		elif assign_type == self.TYPE_NO_FEATURE:
			self.__count_stats.add_exon_no_features(read_name)
		elif assign_type == self.TYPE_MULTI_MAP:
			self.__count_stats.add_multi_mapping(read_name)
		else:
			raise CogentError(f'Unkown or Not handled assgin type in .exon.featureCount: {(assign_type)}')

	def add_gene_feature_count(self, data: str):
		"""Process a line from .gene.featureCounts

		Arguments:
			data {str} -- A line from .gene.featureCounts
		"""
		# Split values
		tag, assign_type, dummy, gene = re.split('\t', data.rstrip())
		read_name, barcode, umi = self.__parse_tag(tag)

		if not self.__ignore_umi is None and self.__ignore_umi == umi:		# Ignore reads having specific UMI bases, typically all N
			return

		# Check processing on exon by read_name
		if not self.__count_stats.is_in_exon_nofeature(read_name):
			return													# No action when reads processed in exon came

		if assign_type == self.TYPE_SINGLETON:						# skip if singleton, could be unmapped
			return

		# Counting
		if assign_type == self.TYPE_ASSIGNED:
			uss = ''												# Initialize for no UMI mode
			if self.__is_use_umi and self.__is_use_uss:
				umi, uss = self.__align_info[read_name]				# Search for UMI and USS

			self.__count_stats.add_gene_assigned(gene, umi, uss)
		elif assign_type == self.TYPE_AMBIGUITY:
			self.__count_stats.add_intron_ambiguity()
		elif assign_type == self.TYPE_NO_FEATURE:
			self.__count_stats.add_gene_no_features()
		else:
			raise CogentError(f'Unkown or Not handled assgin type in .gene.featureCount: {(assign_type)}')

	# Add featureCount info for mitochondria count
	def add_mito_count(self, data: str):
		"""Process a line from .mito.featureCounts

		Arguments:
			data {str} -- A line from .exon.featureCounts
		"""

		# Split values
		tag, assign_type, dummy, gene = re.split('\t', data.rstrip())
		read_name, barcode, umi = self.__parse_tag(tag)

		if not self.__ignore_umi is None and self.__ignore_umi == umi:		# Ignore reads having specific UMI bases, typically all N
			return

		if assign_type == self.TYPE_SINGLETON:					# skip if singleton
			return

		# Counting
		if assign_type == self.TYPE_ASSIGNED:
			self.__count_stats.add_mitochondria()

	# Add featureCount info for expression
	def add_unstrand_exon_feature_count(self, data: str):
		"""Process a line from .unstrand.exon.featureCounts

		Arguments:
			data {str} -- A line from .unstrand.exon.featureCounts
		"""
		# Split values
		tag, assign_type, dummy, gene = re.split('\t', data.rstrip())
		read_name, barcode, umi = self.__parse_tag(tag)

		if not self.__ignore_umi is None and self.__ignore_umi == umi:		# Ignore reads having specific UMI bases, typically all N
			return

		if assign_type == self.TYPE_SINGLETON:								# skip if singleton, could be unmapped
			return

		# Counting
		if assign_type == self.TYPE_ASSIGNED:
			self.__count_stats.add_unstrand_mapped()
		elif assign_type == self.TYPE_AMBIGUITY:
			self.__count_stats.add_unstrand_mapped()
		elif assign_type == self.TYPE_NO_FEATURE:
			pass
		elif assign_type == self.TYPE_MULTI_MAP:
			pass
		else:
			raise CogentError(f'Unkown or Not handled assgin type in .unstrand.featureCount: {(assign_type)}')

	# Add featureCount info for expression
	def add_umi_count(self, data: str):
		"""Process a line from UMI variation text file

		Arguments:
			data {str} -- A line from UMI variation
		"""
		# Split values
		umi, count = re.split('\t', data.rstrip())

		if not self.__ignore_umi is None and self.__ignore_umi == umi:		# Ignore reads having specific UMI bases, typically all N (when SSv4+UMI)
			self.__count_stats.add_ignored_umi_count(umi, int(count))
		else:
			self.__count_stats.add_umi_count(umi, int(count))				# Register UMI bases and its count

	def add_transcript_count(self, file: Union[str, None]) -> bool:
		try:
			if file is None:
				self.__num_transcripts = 0
				return True

			count = 0
			with open(file, 'r') as f:
				f.readline()		# Skip header
				for line in f:
					values = line.rstrip().split('\t')
					if float(values[4]) > 0:		# 4: expected_count
						count += 1

			self.__num_transcripts = count
		except:
			Logger.error_both(f'Failed to count number of detected transcripts: {file}', self.__key)
			return False

		return True

	#--------------------------------------------------------------------------
	# region: For split mode
	def create_stats_record(self, key: str, out_file: str, sample_name: str, demux_count: int, trim_count: int, ribosomal_ratio: float, result_type: ResultType):
		"""Create a file contains stats info for barcode level.

		Arguments:
			barcode {str} -- Target barcode
			out_file {str} -- Output file path.
			demux_counts {Dict[str, List]} -- Result dictionary from demux sub command.
			trim_counts {Dict[str, List]} -- Count dictionary as a result of trimming
			type_experiment {str} -- Experiment type used.
			result_type {str} -- Type of result [exon/intron]
		"""
		with open(out_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			total_mapped_reads = self.__count_stats.unique_mapped_reads_stats + self.__count_stats.multi_mapped_reads_stats
			unmapped_reads = trim_count - total_mapped_reads

			data = [key, sample_name, str(demux_count)]

			if self.__is_use_umi and self.__out_no_umi_reads:
				data.append(str(self.__count_stats.number_of_umi_reads))		# Number of reads having UMI (typically for SSv4+UMI)

			if self.__is_use_umi:
				data.append(str(len(self.__count_stats.umi_list)))

			data.extend([
				str(trim_count),
				str(unmapped_reads), str(total_mapped_reads),
				str(self.__count_stats.multi_mapped_reads_stats),
				str(self.__count_stats.unique_mapped_reads_stats),
				str(self.__count_stats.exon_reads_stats)
			])

			if self.__is_use_umi:
				data.append(str(self.__count_stats.exon_umi_stats))

			if self.__is_use_uss:
				data.append(str(self.__count_stats.exon_uss_stats))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(self.__count_stats.exon_umi_uss_stats))

			data.extend([
				str(self.__count_stats.exon_ambiguity_stats),
				str(self.__count_stats.intron_reads_stats)
			])

			if self.__is_use_umi:
				data.append(str(self.__count_stats.intron_umi_stats))

			if self.__is_use_uss:
				data.append(str(self.__count_stats.intron_uss_stats))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(self.__count_stats.intron_umi_uss_stats))

			data.extend([
				str(self.__count_stats.intron_ambiguity_stats),
				str(self.__count_stats.gene_reads_stats)
			])

			if self.__is_use_umi:
				data.append(str(self.__count_stats.gene_umi_stats))

			if self.__is_use_uss:
				data.append(str(self.__count_stats.gene_uss_stats))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(self.__count_stats.gene_umi_uss_stats))

			data.append(str(self.__count_stats.intergenic_stats))

			if result_type is ResultType.EXON:
				data.append(str(self.__count_stats.number_of_exon_genes))
			elif result_type is ResultType.GENE:
				data.append(str(self.__count_stats.number_of_genes))
			else:
				data.append('-1')

			if self.__do_transcript:
				data.append(str(self.__num_transcripts))

			data.extend([
				str(self.__count_stats.mito_stats),
				str(int(ribosomal_ratio * self.__count_stats.unique_mapped_reads_stats))	# Multiply unique mapped reads in order to use same equation as CogentDS
			])

			if self.__is_stranded:
				data.append('{:.3}'.format(self.__count_stats.get_strand_specificity()))

			writer.writerows([data])

	def create_trans_stats_record(self, key: str, out_file: str, stats: AnalyzeStats):
		with open(out_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			data = [key, stats.sample_name, str(stats.barcoded_reads)]

			if self.__is_use_umi:
				data.append(str(stats.no_of_umi))

			data.extend([
				str(stats.trimmed_reads), str(stats.unmapped_reads), str(stats.mapped_reads),
				str(stats.multi_mapped_reads), str(stats.unique_mapped_reads), str(stats.exon_reads)
			])

			if self.__is_use_umi:
				data.append(str(stats.exon_umi))

			if self.__is_use_uss:
				data.append(str(stats.exon_uss))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(stats.exon_umi_uss))

			data.extend([
				str(stats.ambiguous_exon_reads),
				str(stats.intron_reads)
			])

			if self.__is_use_umi:
				data.append(str(stats.intron_umi))

			if self.__is_use_uss:
				data.append(str(stats.intron_uss))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(stats.intron_umi_uss))

			data.extend([
				str(stats.ambiguous_intron_reads),
				str(stats.gene_reads)
			])

			if self.__is_use_umi:
				data.append(str(stats.gene_umi))

			if self.__is_use_uss:
				data.append(str(stats.gene_uss))

			if self.__is_use_umi and self.__is_use_uss:
				data.append(str(stats.gene_umi_uss))

			data.extend([
				str(stats.intergenic_reads),
				str(stats.no_of_gene),
				str(self.__num_transcripts),		# Put the number counted in this analysis. Do not use value from analyze command
				str(stats.mitochondria_reads)
			])

			if not stats.ribosomal_reads is None:
				data.append(str(stats.ribosomal_reads))

			if self.__is_stranded:
				data.append('{:.3}'.format(stats.strand_specificity))

			writer.writerows([data])

	def create_matrix_by_exon(self, barcode: str, matrix_file: str, gene_list: List[str], count_type: CountType):
		"""Create a file contains read counts on exon for barcode level.

		Arguments:
			barcode {str} -- Target barcode.
			matrix_file {str} -- Output file path.
			gene_list {List} -- Gene list
			count_type {Count_Type} -- Counting type [exon/intron]
		"""
		if matrix_file is None:
			return

		with open(matrix_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			# write header
			data = ['GeneID', barcode]
			writer.writerows([data])

			# write values (per gene)
			for gene in gene_list:
				data = [gene, str(self.__count_stats.get_count_on_exon(gene, count_type))]
				writer.writerows([data])

	def create_matrix_by_gene(self, barcode, matrix_file: str, gene_list: List, count_type: CountType):
		"""Create a file contains read counts on gene region for barcode level

		Arguments:
			barcode {[type]} -- Target barcode.
			matrix_file {str} -- Output file path.
			gene_list {List} -- Gene list
			count_type {Count_Type} -- Counting type [exon/intron]
		"""
		if matrix_file is None:
			return

		with open(matrix_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			# write header
			data = ['GeneID', barcode]
			writer.writerows([data])

			# write values (per gene)
			for gene in gene_list:
				data = [gene, str(self.__count_stats.get_count_on_gene(gene, count_type))]
				writer.writerows([data])

	def create_umi_report(self, barcode: str, output_file: str):
		"""Create a barcode level umi report.

		Arguments:
			barcode {str} -- Target barcode.
			output_file {str} -- Otput file path.
		"""

		with open(output_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			# write header
			data = ['UMI', barcode]
			writer.writerows([data])

			# write values per each UMI
			for umi in self.__count_stats.umi_list:
				data = [umi, str(self.__count_stats.get_umi_count(umi))]
				writer.writerows([data])

	def create_umi_effect_report(self, barcode: str, output_file: str, gene_list: List):
		"""Create a barcode level UMI effect report.

		Arguments:
			barcode {str} -- Target barcode.
			output_file {str} -- Output file path.
			gene_list {List} -- Gene list
			demux_counts {Dict[str, List]} -- Result dictionary from demux sub command.
		"""

		with open(output_file, 'w') as f:
			writer = csv.writer(f, lineterminator = '\n')

			# write values per each barcode and gene
			sample_name = barcode
			for gene in gene_list:
				raw_count = self.__count_stats.get_count_on_exon(gene, CountType.NORMAL)
				# if raw_count == 0:
				# 	continue

				umi_count = self.__count_stats.get_count_on_exon(gene, CountType.UMI)
				uss_count = self.__count_stats.get_count_on_exon(gene, CountType.USS)
				unique_count = self.__count_stats.get_count_on_exon(gene, CountType.UNIQUE)
				data = [
					sample_name, gene, raw_count, umi_count, uss_count, unique_count,
					self.__calc_divide(raw_count, umi_count),
					self.__calc_divide(raw_count, uss_count),
					self.__calc_divide(raw_count, unique_count),
				]
				writer.writerows([data])

	def create_matrix_by_transcript(self, barcode: str, in_file: Union[str, None], out_file: str):
		if out_file is None:
			return

		if in_file is None:
			with open(out_file, 'w') as out_f:
				writer = csv.writer(out_f, lineterminator = '\n')
				# write header only
				data = ['TranscriptID', barcode]
				writer.writerows([data])
		else:
			with open(in_file, 'r') as in_f, open(out_file, 'w') as out_f:
				writer = csv.writer(out_f, lineterminator = '\n')
				in_f.readline()		# Skip header

				# write header
				data = ['TranscriptID', barcode]
				writer.writerows([data])

				# write values (per transcript)
				for line in in_f:
					values = line.rstrip().split('\t')
					data = [values[0], values[4]]	# Retrieve 0:transcript_id and 4:expected_count
					writer.writerows([data])


	# endregion
	#--------------------------------------------------------------------------

	#--------------------------------------------------------------------------
	# region: Internal functions
	def __parse_tag(self, tag: str):
		"""Function to parse tag of FASTQ.

		Arguments:
			tag {str} -- A tag to parse

		Returns:
			[type] -- Tupple contains read name, barcode and UMI.
		"""

		read_name = ''
		barcode = ''
		umi = ''
		if self.__is_use_umi:
			read_name, barcode, umi = re.split('_', tag)
		else:
			read_name, barcode = re.split('_', tag)[0:2]

		return (read_name, barcode, umi)

	def __calc_divide(self, a: int, b: int) -> float:
		"""Divide with avoiding error.

		Arguments:
			a {int} -- A number to divide
			b {int} -- A number to be divided.

		Returns:
			float -- Result number
		"""
		if a == 0:
			return 1.0
		else:
			return b / a
	# endregion
	#--------------------------------------------------------------------------

