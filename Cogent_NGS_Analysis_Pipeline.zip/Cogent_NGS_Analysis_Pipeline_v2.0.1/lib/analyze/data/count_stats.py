#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# R script to launch CogentDS.
#

from collections import Counter, defaultdict
from typing import Dict, List
from enum import Enum

# ----------
# Enumerations
class CountType(Enum):
	NORMAL = 1
	UNIQUE = 2			# deduplicated by UMI and USS
	UMI = 3
	USS = 4

class CountStats:
	"""
	Holding values of genes, UMI and USS of a barcode.
	Also has functions to access each values for reporting.
	"""

	# --- constants ---

	# --- define functions for property ---
	@property
	def exon_reads_stats(self) -> int:
		return sum(self.__on_exon.values())

	@property
	def exon_umi_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_exon_umi.values())

	@property
	def exon_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_exon_uss.values())

	@property
	def exon_umi_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_exon_umi_uss.values())

	@property
	def intron_reads_stats(self) -> int:
		return sum(self.__on_intron.values())

	@property
	def intron_umi_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_intron_umi.values())

	@property
	def intron_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_intron_uss.values())

	@property
	def intron_umi_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_intron_umi_uss.values())

	@property
	def gene_reads_stats(self) -> int:
		return sum(self.__on_gene.values())

	@property
	def gene_umi_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_gene_umi.values())

	@property
	def gene_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_gene_uss.values())

	@property
	def gene_umi_uss_stats(self) -> int:
		return sum(len(v.keys()) for v in self.__on_gene_umi_uss.values())

	@property
	def multi_mapped_reads_stats(self) -> int:
		return len(self.__multi_mapped.keys())

	@property
	def unique_mapped_reads_stats(self) -> int:
		return self.__unique_mapped

	# def get_ribosomal_stats(self) -> int:
	# 	return self.__ribosomal

	@property
	def mito_stats(self) -> int:
		return self.__mitochondria

	@property
	def exon_ambiguity_stats(self) -> int:
		return self.__exon_ambiguity

	@property
	def intron_ambiguity_stats(self) -> int:
		return self.__intron_ambiguity

	@property
	def intergenic_stats(self) -> int:
		return self.__intergenic

	@property
	def number_of_exon_genes(self) -> int:
		return sum(val > 0 for val in self.__on_exon.values())		# Count up if read count > 0

	@property
	def number_of_genes(self) -> int:
		return sum(val > 0 for val in self.__on_gene.values())		# Count up if read count > 0

	@property
	def umi_list(self) -> List[str]:
		return list(self.__umi_dist.keys())

	@property
	def number_of_umi_reads(self) -> int:
		return sum(self.__umi_dist.values())

	@property
	def number_of_ignored_umi(self) -> int:
		return sum(self.__ignored_umi.values())

	def get_strand_specificity(self) -> float:
		stranded_count = \
			self.exon_reads_stats + self.exon_ambiguity_stats
		# 	self.get_intron_reads_stats() + self. get_intron_ambiguity_stats() + \
		# 	self.get_intergenic_stats()

		if self.__unstrand_count == 0 or stranded_count == 0:
			return 0.0
		else:
			return  stranded_count / self.__unstrand_count

	# On initialize
	def __init__(self, barcode: str):
		"""Initialize all variables for stats

		Arguments:
			barcode {str} -- Barcode string indicates a sample
			rRNA_list {List} -- List of ribosomal genes
		"""

		# --- internal vairables/properties ---
		self.__barcode = barcode
		self.__exon_nofeature_reads = set()				# Hold read names of "Unassigned_NoFeatures" in .exon.featureCount

		# Exon expression
		self.__on_exon = Counter()						# Basic expression value per gene
		self.__on_exon_umi = defaultdict(Counter)		# For dedup by UMI only per gene (debug)
		self.__on_exon_uss = defaultdict(Counter)		# For dedup by USS only per gene (debug)
		self.__on_exon_umi_uss = defaultdict(Counter)	# For dedup result per gene

		# Intron counting
		self.__on_intron = Counter()					# Counting intron reads per gene
		self.__on_intron_umi = defaultdict(Counter)		# For dedup by UMI only per gene (debug)
		self.__on_intron_uss = defaultdict(Counter)		# For dedup by USS only per gene (debug)
		self.__on_intron_umi_uss = defaultdict(Counter)	# For dedup result per gene

		# Gene expression (means exon + intron)
		self.__on_gene = Counter()						# Gene expresson value per gene
		self.__on_gene_umi = defaultdict(Counter)		# For dedup by UMI only per gene (debug)
		self.__on_gene_uss = defaultdict(Counter)		# For dedup by USS only per gene (debug)
		self.__on_gene_umi_uss = defaultdict(Counter)	# For dedup result per gene

		# Count from unstranded
		self.__unstrand_count = 0				# For strand specificity calculation only

		# Other stats
		self.__umi_dist = Counter()						# For stats of UMI distribution (not consider genes)
		self.__ignored_umi = Counter()					# For stats of ignored UMI (not consider genes)

		self.__multi_mapped = Counter()					# For report csv only
		self.__unique_mapped = 0
		# self.__ribosomal = 0
		self.__mitochondria = 0							# mitochondria count
		self.__exon_ambiguity = 0
		self.__intron_ambiguity = 0
		self.__intergenic = 0

	# --- access to each count ---

	# -- Exon related --
	# def get_exon_count(self, gene: str) -> int:
	# 	return self.__on_exon.get(gene, 0)

	def get_exon_umi_count(self, gene: str, umi: str) -> int:
		"""Get number of UMI on exon of target gene.

		Arguments:
			gene {str} -- Gene identifier
			umi {str} -- Target UMI bases

		Returns:
			int -- UMI count
		"""
		return self.__on_exon_umi[gene].get(umi, 0)

	def get_count_on_exon(self, gene: str, count_type: CountType) -> int:
		"""Get number of reads on exon of target gene.
		This function branches counting type by count_type as raw or de-duplicated by UMI/USS/UMI and USS.

		Arguments:
			gene {str} -- Gene identifier
			count_type {Count_Type} -- Counting type

		Returns:
			int -- Read count processed by specific deduplication.
		"""
		if count_type == CountType.NORMAL:
			return self.__on_exon.get(gene, 0)
		elif count_type == CountType.UNIQUE:
			return len(self.__on_exon_umi_uss[gene].values())
		elif count_type == CountType.UMI:
			return len(self.__on_exon_umi[gene].values())
		elif count_type == CountType.USS:
			return len(self.__on_exon_uss[gene].values())
		else:										# may be error
			return -1

	def get_count_on_gene(self, gene: str, count_type: CountType) -> int:
		"""Get number of reads on whole gene region (including intron) of target gene.
		This function branches counting type by count_type as raw or deduplicated by UMI/USS/UMI and USS.

		Arguments:
			gene {str} -- Gene identifier
			count_type {Count_Type} -- Counting type

		Returns:
			int -- Read count processed by specific deduplication.
		"""
		if count_type == CountType.NORMAL:
			return self.__on_gene.get(gene, 0)
		elif count_type == CountType.UNIQUE:
			return len(self.__on_gene_umi_uss[gene].values())
		elif count_type == CountType.UMI:
			return len(self.__on_gene_umi[gene].values())
		elif count_type == CountType.USS:
			return len(self.__on_gene_uss[gene].values())
		else:										# may be error
			return -1

	# UMI count for check distribution
	def get_umi_count(self, umi: str) -> int:
		"""Get number of UMI on exon of target gene.

		Arguments:
			gene {str} -- Gene identifier
			umi {str} -- Target UMI bases

		Returns:
			int -- UMI count
		"""
		return self.__umi_dist.get(umi, 0)

	# --- methods ---

	# Add counts by "Assigned" for exons
	def add_exon_assigned(self, gene: str, umi: str, uss: str):
		"""Count up appropriate values by .exon.featureCounts

		Arguments:
			gene {str} -- Ensembl gene ID
			umi {str} -- UMI sequence
			uss {str} -- USS token
		"""
		# First, count up for exon value
		self.__on_exon.update({gene: 1})									# Add raw count
		self.__on_exon_umi[gene].update({umi: 1})							# Add count UMI only
		self.__on_exon_uss[gene].update({uss: 1})							# Add count USS only
		self.__on_exon_umi_uss[gene].update({str(umi+uss): 1})				# Add count deduplicated by both of UMI and USS

		# Second, count up for gene
		# Because reads assigned to exon are also considered to be assigned to gene.
		# And it'll be skipped when processing .gene.featureCounts
		self.__on_gene.update({gene: 1})									# Add raw count
		self.__on_gene_umi[gene].update({umi: 1})							# Add count UMI only
		self.__on_gene_uss[gene].update({uss: 1})							# Add count USS only
		self.__on_gene_umi_uss[gene].update({str(umi+uss): 1})				# Add count deduplicated by both of UMI and USS

		# Third, record other stats
		self.__unique_mapped += 1											# Count up uniqure mapped reads for stats
		# if gene in self.__rRNA_list:										# Count up rRNA separately
		# 	self.__ribosomal += 1

	# Add counts by "Assigned" for genes
	def add_gene_assigned(self, gene: str, umi: str, uss: str):
		"""Count up appropriate values by .gene.featureCounts.
		Only 'Unassigned_NoFeatures' in .exon.featureCounts supposed to be processed.

		Arguments:
			gene {str} -- Ensembl gene ID
			umi {str} -- UMI sequence
			uss {str} -- USS token
		"""
		# First, count up for intron
		# Exonic reads are skipped outside.
		self.__on_intron.update({gene: 1})									# Add raw count
		self.__on_intron_umi[gene].update({umi: 1})							# Add count UMI only
		self.__on_intron_uss[gene].update({uss: 1})							# Add count USS only
		self.__on_intron_umi_uss[gene].update({str(umi+uss): 1})			# Add count deduplicated by both of UMI and USS

		# Second, count up for gene
		self.__on_gene.update({gene: 1})									# Add raw count
		self.__on_gene_umi[gene].update({umi: 1})							# Add count UMI only
		self.__on_gene_uss[gene].update({uss: 1})							# Add count USS only
		self.__on_gene_umi_uss[gene].update({str(umi+uss): 1})				# Add count deduplicated by both of UMI and USS

		# Do not add to unique mapped, because added in exon_no_featrues already

	# Add counts by "Unassigned_Ambiguity"
	def add_exon_ambiguity(self):
		"""Count up appropriate values by .exon.featureCounts for stats.
		"""
		self.__unique_mapped += 1
		self.__exon_ambiguity += 1

	def add_intron_ambiguity(self):
		"""Count up appropriate values by .gene.featureCounts for stats.
		"""
		self.__intron_ambiguity += 1	# Do not add to unique mapped, because added in exon_no_featrues already

	# Add counts by "Unassigned_NoFeatures"
	def add_exon_no_features(self, read_name: str):
		"""Count up appropriate values by .exon.featureCount for stats.
		And these reads will be processed as intronic reads by processing .gene.featureCounts.
		"""
		self.__unique_mapped += 1
		self.__exon_nofeature_reads.add(read_name)

	def add_gene_no_features(self):
		"""Count up appropriate values by .gene.featureCounts for stats.
		"""
		self.__intergenic += 1		# Do not add to unique mapped, because added in exon_no_featrues already

	# Add counts by "Unassigned_MultiMapping"
	def add_multi_mapping(self, read_name: str):
		"""Count up appropriate values by .exon.featureCounts for stats.
		"""
		self.__multi_mapped.update({read_name: 1})

	# Add counts by mitochondria
	def add_mitochondria(self):
		"""Count up appropriate values by .exon.featureCounts for stats.
		"""
		self.__mitochondria += 1

	# Add counts for UMI distribution
	def add_umi_count(self, umi: str, count: int):
		"""Count up number of UMI for stats.
		"""
		self.__umi_dist.update({umi: count})

	# Add counts for reads ignored by invalid UMI
	def add_ignored_umi_count(self, umi: str, count: int):
		"""Count up number of UMI for stats.
		"""
		self.__ignored_umi.update({umi: count})

	# Check if read_name included in "Unassigend_NoFeatures" in exons
	def is_in_exon_nofeature(self, read_name) -> bool:
		"""Check whether a read is holds as an intronic read or not.
		"""
		return read_name in self.__exon_nofeature_reads

	# Add counts by "Assigned" for exons for calc strand specificity
	def add_unstrand_mapped(self):
		"""Count up appropriate values by .unstrand.featureCounts
		"""
		# Count up for exon value only
		self.__unstrand_count += 1

