from datetime import datetime
from os import path
from typing import List, Tuple, Union

import dnaio
from analyze.data.count_stats import CountType
from analyze.data.expression_parser import ExpressionParser, ResultType
from analyze.data.summarize.expression_summarize import ExpressionSummarize
from common.experiment.experiment import Experiment

from common.logger import Logger
from common.util.const import DebugMode
from common.util.util import elapsed_time

from enum import Enum


class DataType(Enum):
	UMI = '5pUMI'
	ALL = 'all'		# 5pUMI + Internal

class SSv4Summarize(ExpressionSummarize):

	# -----------------------------------------------------------------------------
	# region: Property or Get method

	@property
	def is_separate_umi_stats(self) -> bool:
		return True

	# Stats
	def exon_stats_file(self, data_type: DataType) -> str:
		return path.join(self.__work_dir, f'{data_type.value}_exon_stats.txt')

	def intron_stats_file(self, data_type: DataType) -> str:
		return path.join(self.__work_dir, f'{data_type.value}_incl_introns_stats.txt')

	# Counts for matrix
	def exon_counts_file(self, data_type: DataType) -> str:
		return path.join(self.__work_dir, f'{data_type.value}_exon_counts.txt')

	@property
	def exon_umi_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_exon_umi_counts.txt')

	@property
	def exon_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_exon_uss_counts.txt')

	@property
	def exon_umi_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_exon_umi_uss_counts.txt')

	def gene_counts_file(self, data_type: DataType) -> str:
		return path.join(self.__work_dir, f'{data_type.value}_gene_counts.txt')

	@property
	def gene_umi_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_gene_umi_counts.txt')

	@property
	def gene_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_gene_uss_counts.txt')

	@property
	def gene_umi_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_gene_umi_uss_counts.txt')

	# For more metrics
	@property
	def umi_dist_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_umi_dist.txt')

	@property
	def umi_effect_file(self) -> str:
		return path.join(self.__work_dir, f'{DataType.UMI.value}_umi_effect.txt')

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, key: str, work_dir: str, experiment: Experiment, do_transcript: bool, debug_mode: DebugMode):
		super().__init__(key)

		self.__key = key
		self.__work_dir = work_dir
		self.__experiment = experiment
		self.__debug_mode = debug_mode

		self.__do_transcript = do_transcript

		self.__umi_demux_count = 0
		self.__umi_trim_count = 0
		self.__umi_ribosomal_ratio = 0

	def process_reads_for_umi_stats(self, demux_file: str, trim_file: Union[str, None], ribo_files: Tuple[str, str], umi_length: Union[int, None]):

		if umi_length is None:
			return

		ignore_umi = 'N' *  umi_length
		self.__umi_demux_count = self.__count_umi_tags(demux_file, ignore_umi)

		if trim_file is not None and path.isfile(trim_file):
			self.__umi_trim_count = self.__count_umi_tags(trim_file, ignore_umi)
		else:
			self.__umi_trim_count = self.__umi_demux_count

		if path.isfile(ribo_files[0]) and path.isfile(ribo_files[1]):
			ribo_count = self.__count_umi_tags(ribo_files[0], ignore_umi)
			non_ribo_count = self.__count_umi_tags(ribo_files[1], ignore_umi)

			if ribo_count != 0 or non_ribo_count != 0:
				self.__umi_ribosomal_ratio = ribo_count / (ribo_count + non_ribo_count)

		return

	def create_summary_files(self, sample_name: str, input_reads: int, trim_reads: int, ribosomal_ratio: float,
							fc_file_exon: str, fc_file_gene: str, gene_list: List[str], fc_file_mito: str = None,
							fc_file_unstrand: str = None, uss_info_file: str = None, umi_count_file: str = None,
							trans_count_file: str = None) -> bool:

		start_time = datetime.now()
		umi_parser = ExpressionParser(
			self.__key, self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded, 			# For 5pUMI
			self.__do_transcript, umi_length=self.__experiment.umi_length, out_no_umi_reads=True)
		all_parser = ExpressionParser(self.__key, False, False, self.__experiment.is_stranded, self.__do_transcript)		# For All reads


		# add information for UMI from CSV (BAM parsed)
		if self.__experiment.is_use_uss and not uss_info_file is None:
			Logger.info_logger(f'Start reading alignment info (UMI/USS)', self.__key)
			umi_parser.add_align_info(uss_info_file)

		# -----------------------------
		# Exon counting
		Logger.info_logger(f'Start exon counting for 5pUMI', self.__key)
		res = self._process_exons(fc_file_exon, umi_parser)
		if not res:
			return False

		Logger.info_logger(f'Start exon counting for all reads', self.__key)
		res = self._process_exons(fc_file_exon, all_parser)
		if not res:
			return False

		# -----------------------------
		# mitochondria
		if not fc_file_mito is None:
			Logger.info_logger(f'Start mito counting for 5pUMI', self.__key)
			res = self._process_mitos(fc_file_mito, umi_parser)
			if not res:
				return False

			Logger.info_logger(f'Start mito counting for all reads', self.__key)
			res = self._process_mitos(fc_file_mito, all_parser)
			if not res:
				return False

		# -----------------------------
		# genes (including intron)
		Logger.info_logger(f'Start gene counting for 5pUMI', self.__key)
		res = self._process_genes(fc_file_gene, umi_parser)
		if not res:
			return False

		Logger.info_logger(f'Start gene counting for all reads', self.__key)
		res = self._process_genes(fc_file_gene, all_parser)
		if not res:
			return False

		# -----------------------------
		# Strand specificity calcuration
		if self.__experiment.is_stranded:
			if fc_file_unstrand is None:
				Logger.error_both(f'File for calculating strand specificity set as None', self.__key)
			else:
				Logger.info_logger(f'Start unstrand counting for 5pUMI', self.__key)
				res = self._process_unstrand(fc_file_unstrand, umi_parser)
				if not res:
					return False

				Logger.info_logger(f'Start unstrand counting for all reads', self.__key)
				res = self._process_unstrand(fc_file_unstrand, all_parser)
				if not res:
					return False

		if self.__experiment.is_use_umi:
			Logger.info_logger('Start UMI counting for 5pUMI', self.__key)
			if umi_count_file is None:
				Logger.error_both(f'File for umi variation count set as None', self.__key)
			else:
				res = self._process_umi_counts(umi_count_file, umi_parser)
				if not res:
					return False

		# Transcript counting
		if self.__do_transcript:
			Logger.info_logger(f'Start transcript counting for all reads', self.__key)
			res = all_parser.add_transcript_count(trans_count_file)
			if not res:
				return False

		# output split results for barcode
		self._create_result_files(umi_parser, all_parser, sample_name, input_reads, trim_reads, ribosomal_ratio, gene_list)
		Logger.info_logger("Successfully completed creating summary files for genes. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def _create_result_files(self, umi_parser: ExpressionParser, all_parser: ExpressionParser, sample_name: str, input_count: int, trim_count: int, ribosomal_ratio: float, gene_list: List[str]) -> bool:

		# -----------------------------
		# stats
		umi_parser.create_stats_record(self.__key, self.exon_stats_file(DataType.UMI), sample_name, input_count, self.__umi_trim_count, self.__umi_ribosomal_ratio, ResultType.EXON)
		umi_parser.create_stats_record(self.__key, self.intron_stats_file(DataType.UMI), sample_name, input_count, trim_count, ribosomal_ratio, ResultType.GENE)

		all_parser.create_stats_record(self.__key, self.exon_stats_file(DataType.ALL), sample_name, input_count, trim_count, ribosomal_ratio, ResultType.EXON)
		all_parser.create_stats_record(self.__key, self.intron_stats_file(DataType.ALL), sample_name, input_count, trim_count, ribosomal_ratio, ResultType.GENE)

		# -----------------------------
		# genematrix
		umi_parser.create_matrix_by_exon(self.__key, self.exon_counts_file(DataType.UMI), gene_list, CountType.NORMAL)
		all_parser.create_matrix_by_exon(self.__key, self.exon_counts_file(DataType.ALL), gene_list, CountType.NORMAL)

		if self.__experiment.is_use_umi:
			umi_parser.create_matrix_by_exon(self.__key, self.exon_umi_uss_counts_file, gene_list, CountType.UNIQUE)
			umi_parser.create_matrix_by_exon(self.__key, self.exon_umi_counts_file, gene_list, CountType.UMI)

			if self.__experiment.is_use_uss:
				umi_parser.create_matrix_by_exon(self.__key, self.exon_uss_counts_file, gene_list, CountType.USS)

		umi_parser.create_matrix_by_gene(self.__key, self.gene_counts_file(DataType.UMI), gene_list, CountType.NORMAL)
		all_parser.create_matrix_by_gene(self.__key, self.gene_counts_file(DataType.ALL), gene_list, CountType.NORMAL)

		if self.__experiment.is_use_umi:
			umi_parser.create_matrix_by_gene(self.__key, self.gene_umi_uss_counts_file, gene_list, CountType.UNIQUE)
			umi_parser.create_matrix_by_gene(self.__key, self.gene_umi_counts_file, gene_list, CountType.UMI)

			if self.__experiment.is_use_uss:
				umi_parser.create_matrix_by_gene(self.__key, self.gene_uss_counts_file, gene_list, CountType.USS)

		# UMI reports
		if self.__experiment.is_use_umi and self.__debug_mode is DebugMode.HIGH:
			umi_parser.create_umi_report(self.__key, self.umi_dist_file)
			umi_parser.create_umi_effect_report(self.__key, self.umi_effect_file, gene_list)

		return True

	def __count_umi_tags(self, fastq: str, ignore_umi: str) -> int:

		count = 0
		with dnaio.open(fastq, mode = 'r') as reader:
			for r in reader:	# type: ignore
				umi = r.name.split(' ')[0].split('_')[2]			# Cut out UMI
				if umi != ignore_umi:				# If not ignore UMI (= Internal reads)
					count += 1						# Count up

		return count
