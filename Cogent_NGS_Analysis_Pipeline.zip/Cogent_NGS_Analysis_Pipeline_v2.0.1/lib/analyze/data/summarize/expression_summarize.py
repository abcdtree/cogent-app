from abc import ABCMeta, abstractmethod
from typing import List, Tuple, Union
from analyze.data.expression_parser import ExpressionParser
from common.analyze.base_summarize import BaseSummarize

from common.logger import Logger
from run_fusion_analysis.data.fusion_summarize import FusionSummarize
from run_immune_analysis.data.immune_summarize import ImmuneSummarize
from run_transcript_analysis.data.rsem_summarize import RsemSummarize

class ExpressionSummarize(BaseSummarize):

	def __init__(self, key: str):
		self.__key = key

	# Redefine
	@abstractmethod
	def create_summary_files(self, sample_name: str, input_reads: int, trim_reads: int, ribosomal_ratio: float,
							fc_file_exon: str, fc_file_gene: str, gene_list: List[str], fc_file_mito: str = None,
							fc_file_unstrand: str = None, uss_info_file: str = None, umi_count_file: str = None,
							trans_count_file: str = None) -> bool:
		...

	@abstractmethod
	def _create_result_files(self, parser: ExpressionParser, sample_name: str, input_count: int, trim_count: int, ribosomal_ratio: float, gene_list: List[str]) -> bool:
		...

	@abstractmethod
	def process_reads_for_umi_stats(self, demux_file: str, trim_file: Union[str, None], ribo_files: Tuple[str, str], umi_length: Union[int, None]):
		"""To be implemented in ssv4_summarize.

		Args:
			demux_file (str): FASTQ file from demux command
			trim_file (str): Trimmed FASTQ file from demux
			ribo_files (List[str]): Ribosomal counting results from riboPicker (rrna, non-rrna)
		"""
		...

	@property
	@abstractmethod
	def is_separate_umi_stats(self) -> bool:
		...

	@property
	def transcript_result(self) -> Union[RsemSummarize, None]:
		return self.__transcript_result
	@transcript_result.setter
	def transcript_result(self, result_obj: RsemSummarize):
		self.__transcript_result = result_obj

	@property
	def immune_result(self) -> Union[ImmuneSummarize, None]:
		return self.__immune_result
	@immune_result.setter
	def immune_result(self, result_obj: ImmuneSummarize):
		self.__immune_result = result_obj

	@property
	def fusion_result(self) -> Union[FusionSummarize, None]:
		return self.__fusion_result
	@fusion_result.setter
	def fusion_result(self, result_obj: FusionSummarize):
		self.__fusion_result = result_obj

	# ---------------------------------
	# region: Protected method

	# Process .exon.featureCounts file for exon counting
	def _process_exons(self, file: str, parser: ExpressionParser) -> bool:
		"""Process .exon.featureCounts file for exon counting

		Arguments:
			file {str} -- Path to .exon.featureCounts

		Returns:
			bool -- Processed successfully, or not.
		"""

		try:
			with open(file) as f:
				processed_line = set()
				for line in f:
					if line in processed_line:
						continue
					processed_line.add(line)
					parser.add_exon_feature_count(line)
		except EnvironmentError as err:
			Logger.error_both(f'Unable to open file: {file}', self.__key)
			return False

		return True

	# Process .gene.featureCounts file for intron counting
	def _process_genes(self, file: str, parser: ExpressionParser) -> bool:
		"""Process .gene.featureCounts file for stats

		Arguments:
			barcode {str} -- Barcode sequence
			file {str} -- Path to .gene.featureCounts

		Returns:
			bool -- Processed successfully, or not.
		"""

		try:
			with open(file) as f:
				processed_line = set()
				for line in f:
					if line in processed_line:
						continue
					processed_line.add(line)
					parser.add_gene_feature_count(line)
		except EnvironmentError as err:
			Logger.error_both(f'Unable to open file: {file}', self.__key)
			return False

		return True

	# Process .mito.featureCounts file for mitochondria counting
	def _process_mitos(self, file: str, parser: ExpressionParser) -> bool:
		"""Process .mito.featureCounts file for stats

		Arguments:
			file {str} -- Path to .mito.featureCounts

		Returns:
			bool -- Processed successfully, or not.
		"""

		# Count mitochondria values
		try:
			with open(file) as f:
				processed_line = set()

				for line in f:
					if line in processed_line:
						continue
					processed_line.add(line)
					parser.add_mito_count(line)
		except EnvironmentError as err:
			Logger.error_both(f'Unable to open file: {file}', self.__key)
			return False

		return True

	# Process .unstrand.featureCounts file for calc strand specificity
	def _process_unstrand(self, file: str, parser: ExpressionParser) -> bool:
		"""Process .unstrand.featureCounts file for calc strand specificity

		Arguments:
			result_file {str} -- Path to .unstrand.exon.featureCounts

		Returns:
			bool -- Processed successfully, or not.
		"""

		try:
			with open(file) as f:
				processed_line = set()
				for line in f:
					if line in processed_line:
						continue
					processed_line.add(line)
					parser.add_unstrand_exon_feature_count(line)
		except EnvironmentError as err:
			Logger.error_both(f'Unable to open file: {file}', self.__key)
			return False

		return True

	# Count up UMI variation
	def _process_umi_counts(self, file: str, parser: ExpressionParser) -> bool:
		"""Process UMI variation file

		Arguments:
			result_file {str} -- Path to {barcode}.txt

		Returns:
			bool -- Processed successfully, or not.
		"""

		# Regist UMI values
		try:
			with open(file) as f:
				for line in f:
					parser.add_umi_count(line)
		except EnvironmentError as err:
			Logger.error_both('Unable to open file: %s' % (file), self.__key)
			return False

		return True

	# endregion: Protected method
	# ---------------------------------
