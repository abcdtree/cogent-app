from datetime import datetime
from os import path
from typing import List, Tuple, Union
from analyze.data.count_stats import CountType
from analyze.data.expression_parser import ExpressionParser, ResultType
from analyze.data.summarize.expression_summarize import ExpressionSummarize
from common.experiment.experiment import Experiment

from common.logger import Logger
from common.util.const import DebugMode
from common.util.util import elapsed_time
from run_transcript_analysis.data.rsem_summarize import RsemSummarize

class NormalSummarize(ExpressionSummarize):

	# -----------------------------------------------------------------------------
	# region: Property
	@property
	def is_separate_umi_stats(self) -> bool:
		return False

	@property
	def exon_stats_file(self) -> str:
		return path.join(self.__work_dir, 'exon_stats.txt')

	@property
	def intron_stats_file(self) -> str:
		return path.join(self.__work_dir, 'incl_introns_stats.txt')

	@property
	def exon_counts_file(self) -> str:
		return path.join(self.__work_dir, 'exon_counts.txt')

	@property
	def exon_umi_counts_file(self) -> str:
		return path.join(self.__work_dir, 'exon_umi_counts.txt')

	@property
	def exon_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, 'exon_uss_counts.txt')

	@property
	def exon_umi_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, 'exon_umi_uss_counts.txt')

	@property
	def gene_counts_file(self) -> str:
		return path.join(self.__work_dir, 'gene_counts.txt')

	@property
	def gene_umi_counts_file(self) -> str:
		return path.join(self.__work_dir, 'gene_umi_counts.txt')

	@property
	def gene_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, 'gene_uss_counts.txt')

	@property
	def gene_umi_uss_counts_file(self) -> str:
		return path.join(self.__work_dir, 'gene_umi_uss_counts.txt')

	@property
	def umi_dist_file(self) -> str:
		return path.join(self.__work_dir, 'umi_dist.txt')

	@property
	def umi_effect_file(self) -> str:
		return path.join(self.__work_dir, 'umi_effect.txt')

	@property
	def transcript_result(self) -> Union[RsemSummarize, None]:
		return self.__transcript_result
	@transcript_result.setter
	def transcript_result(self, result_obj: RsemSummarize):
		self.__transcript_result = result_obj

	# endregion: Property
	# -----------------------------------------------------------------------------

	def __init__(self, key: str, work_dir: str, experiment: Experiment, do_transcript: bool, debug_mode: DebugMode):
		super().__init__(key)

		self.__key = key
		self.__work_dir = work_dir
		self.__experiment = experiment
		self.__debug_mode = debug_mode

		self.__do_transcript = do_transcript

	def process_reads_for_umi_stats(self, demux_file: str, trim_file: Union[str, None], ribo_files: Tuple[str, str], umi_length: Union[int, None]):
		return 	# Do Nothing

	def create_summary_files(self, sample_name: str, input_reads: int, trim_reads: int, ribosomal_ratio: float,
							fc_file_exon: str, fc_file_gene: str, gene_list: List[str], fc_file_mito: str = None,
							fc_file_unstrand: str = None, uss_info_file: str = None, umi_count_file: str = None,
							trans_count_file: str = None) -> bool:

		start_time = datetime.now()
		parser = ExpressionParser(self.__key, self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded, self.__do_transcript)

		# add information for UMI from CSV (BAM parsed)
		if self.__experiment.is_use_uss and not uss_info_file is None:
			Logger.info_logger(f'Start reading alignment info (UMI/USS)', self.__key)
			parser.add_align_info(uss_info_file)

		# Exon counting
		Logger.info_logger(f'Start exon counting', self.__key)
		res = self._process_exons(fc_file_exon, parser)
		if not res:
			return False

		# mitochondria
		if not fc_file_mito is None:
			Logger.info_logger(f'Start mito counting', self.__key)
			res = self._process_mitos(fc_file_mito, parser)
			if not res:
				return False

		# genes (including introns)
		Logger.info_logger(f'Start gene counting', self.__key)
		res = self._process_genes(fc_file_gene, parser)
		if not res:
			return False

		if self.__experiment.is_stranded:
			Logger.info_logger(f'Start unstrand counting', self.__key)

			if fc_file_unstrand is None:
				Logger.error_both(f'File for calculating strand specificity set as None', self.__key)
			else:
				res = self._process_unstrand(fc_file_unstrand, parser)
				if not res:
					return False

		if self.__experiment.is_use_umi:
			Logger.info_logger('Start UMI counting for', self.__key)
			if umi_count_file is None:
				Logger.error_both(f'File for umi variation count set as None', self.__key)
			else:
				res = self._process_umi_counts(umi_count_file, parser)
				if not res:
					return False

		# Transcript counting
		if self.__do_transcript:
			Logger.info_logger(f'Start transcript counting', self.__key)
			res = parser.add_transcript_count(trans_count_file)
			if not res:
				return False

		# output split results for barcode
		self._create_result_files(parser, sample_name, input_reads, trim_reads, ribosomal_ratio, gene_list)
		Logger.info_logger("Successfully completed creating summary files for genes. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def _create_result_files(self, parser: ExpressionParser, sample_name: str, input_count: int, trim_count: int, ribosomal_ratio: float, gene_list: List[str]) -> bool:

		# stats
		parser.create_stats_record(self.__key, self.exon_stats_file, sample_name, input_count, trim_count, ribosomal_ratio, ResultType.EXON)
		parser.create_stats_record(self.__key, self.intron_stats_file, sample_name, input_count, trim_count, ribosomal_ratio, ResultType.GENE)

		# genematrix
		parser.create_matrix_by_exon(self.__key, self.exon_counts_file, gene_list, CountType.NORMAL)
		if self.__experiment.is_use_umi:
			parser.create_matrix_by_exon(self.__key, self.exon_umi_uss_counts_file, gene_list, CountType.UNIQUE)
			parser.create_matrix_by_exon(self.__key, self.exon_umi_counts_file, gene_list, CountType.UMI)

			if self.__experiment.is_use_uss:
				parser.create_matrix_by_exon(self.__key, self.exon_uss_counts_file, gene_list, CountType.USS)

		parser.create_matrix_by_gene(self.__key, self.gene_counts_file, gene_list, CountType.NORMAL)
		if self.__experiment.is_use_umi:
			parser.create_matrix_by_gene(self.__key, self.gene_umi_uss_counts_file, gene_list, CountType.UNIQUE)
			parser.create_matrix_by_gene(self.__key, self.gene_umi_counts_file, gene_list, CountType.UMI)

			if self.__experiment.is_use_uss:
				parser.create_matrix_by_gene(self.__key, self.gene_uss_counts_file, gene_list, CountType.USS)

		# UMI reports
		if self.__experiment.is_use_umi and self.__debug_mode is DebugMode.HIGH:
			parser.create_umi_report(self.__key, self.umi_dist_file)
			parser.create_umi_effect_report(self.__key, self.umi_effect_file, gene_list)

		return True

