import os
import shutil

from typing import Dict,  Union
from os import path, unlink
from datetime import datetime

from analyze.tools.cutadapt import CutAdapt
from analyze.tools.feature_counts import  FeatureCounts, FeatureCountsType
from analyze.tools.umi_counter import UmiCounter
from common.analyze.base_processor import BaseProcessor

from common.cogent_error import CogentError
from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import BamKeepMode, DebugMode, FusionFilter, ReadMode
from common.util.demux import DemuxSummary
from common.util.util import elapsed_time
from common.analyze.base_summarize import BaseSummarize
from run_fusion_analysis.data.fusion_summarize import FusionSummarize
from run_immune_analysis.data.immune_summarize import ImmuneSummarize

from run_transcript_analysis.data.rsem_summarize import RsemSummarize
from run_transcript_analysis.tools.rsem import Rsem

class AnalysisProcessor(BaseProcessor):

	# ---------------------------------
	# region: Constants
	RSEM_WORKSPACE = 'rsem'
	FUSION_WORKSPACE = 'star_fusion'
	IMMUNE_WORKSPACE = 'trust4'
	# endregion
	# ---------------------------------

	@property
	def results(self) -> Dict[str, BaseSummarize]:
		return self._results

	@property
	def exon_info_file(self) -> str:
		return self.__exon_info_file

	@property
	def gene_info_file(self) -> str:
		return self.__gene_info_file

	@property
	def transcript_info_file(self) -> Union[str, None]:
		return self.__transcript_info_file

	# Initialize
	def __init__(self, threads_num: int, cores_num: int, experiment: Experiment, skip_trim: bool,
				work_dir: str, logs_dir: str, bam_dir: str, config_dir: str, default_configs, genome_used: str,
				keep_bam: BamKeepMode, do_transcript: bool, do_immune: bool, do_fusion: bool, debug_mode: DebugMode, ex_star_option: Dict[str, str]):

		super().__init__(threads_num, cores_num, experiment, logs_dir, config_dir, default_configs, genome_used)

		self.__experiment = experiment				# Experiment type
		self.__skip_trim = skip_trim
		self.__debug_mode = debug_mode
		self.__ex_star_option = ex_star_option

		self.__gtf_path = default_configs[Config.GENOME_CONFIG_KEY + genome_used][1]
		self.__mito_gtf = default_configs[Config.GENOME_CONFIG_KEY + genome_used][2]
		if self.__mito_gtf is None:
			Logger.warning_logger('Mitochondria gtf is not found. Skip mito counting and value will be 0 for all barcodes.')

		self.__work_dir_root = work_dir
		self.__logs_dir_root = logs_dir

		self.__exon_info_file = path.join(self.__work_dir_root, 'gene_info.csv')
		self.__gene_info_file = path.join(self.__work_dir_root, 'gene_info_incl_introns.csv')

		self.__bam_dir = bam_dir
		self.__keep_bam = keep_bam
		self.__do_transcript = do_transcript
		self.__do_immune = do_immune
		self.__do_fusion = do_fusion
		self.__transcript_info_file = None
		if do_transcript:
			self.__transcript_info_file = path.join(self.__work_dir_root, 'transcript_info.csv')

		if (skip_trim):
			Logger.info_logger('Trimming steps is skipped.')

	# Impl of abstract method
	def _work_per_barcode(self, pid: int, key: str, input_files: tuple, res_dict: Dict[str, BaseSummarize], demux_summary: DemuxSummary) -> bool:

		start_time = datetime.now()

		# ---------- Setup for this key ---------- #
		work_dir = path.join(self.__work_dir_root, key)
		Logger.add_logger(key, path.join(self.__logs_dir_root, f'{key}_log.txt'))
		Logger.info_logger(f'Started processing for {key}.', key)

		try:
			os.makedirs(work_dir)		# Create sub-folder
		except OSError as err:
			raise CogentError(f'Unable to create directory: {work_dir}')

		# ---------- Trimming ---------- #
		cutadapt = None
		if self.__skip_trim:
			Logger.info_logger(f'Skip trimming step.', key)
		else:
			cutadapt = self._trim(key, work_dir, input_files)
			if cutadapt is None:
				Logger.error_both(f'Failed trimming for {key}')
				return False

		# ---------- Files to input next steps ---------- #
		fastq_files = None
		if self.__skip_trim:
			if self.__experiment.read_mode == ReadMode.PAIRED:
				fastq_files = (input_files[0], input_files[1])
			elif self.__experiment.read_mode == ReadMode.READ1:
				fastq_files = (input_files[0], None)
			elif self.__experiment.read_mode == ReadMode.READ2:
				fastq_files = (None, input_files[0])
			else:
				fastq_files = (None, None)
		else:
			if cutadapt is None:
				Logger.error_both(f'Unexpected error. cutadapt should not be None here: {key}.')
				return False

			fastq_files = (cutadapt.trimmed_read1, cutadapt.trimmed_read2)

		# ---------- Alignment ---------- #
		star = self._align(key, work_dir, fastq_files, self.__ex_star_option)
		if star is None:
			Logger.error_both(f'Failed alignment for {key}')
			return False

		# ---------- Convert Bam to CSV ---------- #
		bam_processor = None
		if self.__experiment.is_use_umi and self.__experiment.is_use_uss:
			bam_processor = self._bam2csv(key, work_dir, star.genome_bam)
			if bam_processor is None:
				Logger.error_both(f'Failed convert BAM to CSV for {key}')
				return False

		# ---------- Counting on Exon ---------- #
		exon_count = self._feature_counts(key, work_dir, star.genome_bam, FeatureCountsType.EXON, self.__gtf_path)
		if exon_count is None:
			Logger.error_both(f'Failed featureCounts on exon for {key}')
			return False

		# ---------- Counting on Gene ---------- #
		gene_count = self._feature_counts(key, work_dir, star.genome_bam, FeatureCountsType.GENE, self.__gtf_path)
		if gene_count is None:
			Logger.error_both(f'Failed featureCounts on gene for {key}')
			return False

		# ---------- Counting on Mitochondria ---------- #
		mito_count = None
		if not self.__mito_gtf is None:
			mito_count = self._feature_counts(key, work_dir, star.genome_bam, FeatureCountsType.MITOCHONDRIA, self.__mito_gtf)
			if mito_count is None:
				Logger.error_both(f'Failed featureCounts on mitochondria for {key}')
				return False

		# ---------- Counting for strand specificity calculation ---------- #
		unstrand_count = None
		if self.__experiment.is_stranded:
			unstrand_count = self._feature_counts(key, work_dir, star.genome_bam, FeatureCountsType.NON_STRAND_EXON, self.__gtf_path)
			if unstrand_count is None:
				Logger.error_both(f'Failed featureCounts on unstrand counting for {key}')
				return False

		# ---------- Transcript counting ---------- #
		rsem = None
		if self.__do_transcript:
			rsem = self._rsem(key, path.join(work_dir, self.RSEM_WORKSPACE), star.transcript_bam, self.__experiment.is_paired, self.__experiment.stranded_mode)
			if rsem is None:
				Logger.error_both(f'Failed RSEM for {key}')
				return False

		# ---------- Immune Profiling ---------- #
		trust4 = None
		if self.__do_immune:
			trust4 = self._immune(key, path.join(work_dir, self.IMMUNE_WORKSPACE), input_files)		# Use FASTQ files after demux (before trimming)
			if trust4 is None:
				Logger.error_both(f'Failed TRUST4 for {key}')
				return False

		# ---------- Fusion Gene ---------- #
		star_fusion = None
		if self.__do_fusion:
			star_fusion = self._fusion(
				key, path.join(work_dir, self.FUSION_WORKSPACE), star.fusion_chimeric, 	# Use chimeric file after alignment
				FusionFilter.MAX_SENSITIVE)												# Use default filtering level
			if star_fusion is None:
				Logger.error_both(f'Failed STAR-Fusion for {key}')
				return False

		# ---------- Calculate ribosomal percentage ---------- #
		riboPicker = self._ribopicker(key, work_dir, input_files[0])
		if riboPicker is None:
			Logger.error_both(f'Failed ribosomal counting for {key}')
			return False

		# ---------- Count UMI variation ---------- #
		umi_count_file = None
		if self.__experiment.is_use_umi:
			counter = UmiCounter()
			umi_count_file = counter.count(key, input_files[0], work_dir)

			if umi_count_file is None:
				Logger.error_logger(f'No UMI found in {key}. Please check experiment type used in demux.')
				return False

		# ---------- Summarize ---------- #
		trimmed_reads_num = demux_summary.reads_num			# Initialize with input number of reads
		if not cutadapt is None:
			trimmed_reads_num = cutadapt.trimmed_reads_num

		# Summarize for main analysis (gene expression)
		summarize = self.__experiment.get_summarize_obj(key, work_dir, self.__do_transcript, self.__debug_mode)
		if summarize.is_separate_umi_stats:					# Branch for generating UMI specific stats (typically for SSv4+UMI)
			summarize.process_reads_for_umi_stats(
				input_files[0], fastq_files[0],
				(riboPicker.rrna_fastq, riboPicker.non_rrna_fastq),
				self.__experiment.umi_length
				)

		summarize.create_summary_files(
			demux_summary.name, demux_summary.reads_num, trimmed_reads_num, riboPicker.ribosomal_ratio,
			exon_count.result_file, gene_count.result_file, exon_count.gene_id_list,
			mito_count.result_file if not mito_count is None else None,
			unstrand_count.result_file if not unstrand_count is None else None,
			bam_processor.result_csv if not bam_processor is None else None,
			umi_count_file,
			rsem.result_file if not rsem is None else None
			)

		# Summarize for transcript analysis
		if self.__do_transcript:
			if rsem is None:
				Logger.error_both(f'Unexpected error. rsem should not be None here: {key}.')
				return False

			transcript_summary = RsemSummarize(key, work_dir, False)
			transcript_summary.create_summary_files(rsem.result_file, self.__experiment.is_use_umi, self.__experiment.is_use_uss, self.__experiment.is_stranded)

			summarize.transcript_result = transcript_summary		# Set result object to parent summary object

		# Summarize for immune analysis
		if self.__do_immune:
			if trust4 is None:
				Logger.error_both(f'Unexpected error. trust4 should not be None here: {key}.')
				return False

			immune_summary = ImmuneSummarize(key, work_dir)
			immune_summary.create_summary_files(demux_summary.name, demux_summary.reads_num, trust4.clonotype_tsv_file)

			summarize.immune_result = immune_summary

		# Summarize for gene fusion
		if self.__do_fusion:
			if star_fusion is None:
				Logger.error_both(f'Unexpected error. star_fusion should not be None here: {key}.')
				return False

			fusion_summary = FusionSummarize(key, work_dir)
			fusion_summary.create_summary_files(demux_summary.name, demux_summary.reads_num, star_fusion.result_file)

			summarize.fusion_result = fusion_summary

		# ---------- Generate gene info files ---------- #
		self.__create_info_files(key, work_dir, exon_count, gene_count, rsem)

		# ---------- Clean working directory (first time) ---------- #
		star.manage_bam_file(self.__keep_bam, self.__bam_dir)
		if self.__debug_mode is DebugMode.NONE:
			self._clean_work_dir(
				False, cutadapt=cutadapt, star=star, exon_count=exon_count, gene_count=gene_count, mito_count=mito_count,
				unstrand_count=unstrand_count, ribopicker=riboPicker, rsem=rsem, immune=trust4, fusion=star_fusion, bam_processor=bam_processor
				)
		elif self.__debug_mode is DebugMode.MODERATE:
			self._clean_work_dir(True, cutadapt=cutadapt, star=star, exon_count=exon_count, gene_count=gene_count, mito_count=mito_count,
				unstrand_count=unstrand_count, ribopicker=riboPicker, rsem=rsem, immune=trust4, fusion=star_fusion, bam_processor=bam_processor
				)

		# Keep summarized class for return
		res_dict[key] = summarize

		Logger.info_logger(f'Finished processing. Elapsed time: ' + elapsed_time(start_time), key)		# For an independent log file
		Logger.info_logger(f'Finished processing for {key} in ' + elapsed_time(start_time))				# For main log file

		return True

	# ---------------------------------
	# region: Internal function

	def __create_info_files(self, key: str, work_dir: str, exon: FeatureCounts, gene: FeatureCounts, trans: Union[Rsem, None]):

		# ----------
		# Exon (gene)
		if not path.isfile(self.__exon_info_file):									# Check if already created by other process
			Logger.info_logger('Generate the gene (exon) information file for use in CogentDS', key)

			# Create temporary file in each working directory
			temp_file = f'{work_dir}/temp_exon_info.csv'
			exon.create_gene_info_file(self.__gtf_path, temp_file)

			# Copy the file if possible
			if not path.isfile(self.__exon_info_file):								# Check file exists again
				shutil.copyfile(temp_file, self.__exon_info_file)
				Logger.info_logger(f'Generated the gene (exon) information file for use in CogentDS in the process for {key}')

			# Remove temp file
			unlink(temp_file)

		# ----------
		# Including intron (gene)
		if not path.isfile(self.__gene_info_file):									# Check if already created by other process
			Logger.info_logger('Generate the gene (including intron) information file for use in CogentDS', key)

			# Create temporary file in each working directory
			temp_file = f'{work_dir}/temp_gene_info.csv'
			gene.create_gene_info_file(self.__gtf_path, temp_file)

			# Copy the file if possible
			if not path.isfile(self.__gene_info_file):								# Check file exists again
				shutil.copyfile(temp_file, self.__gene_info_file)
				Logger.info_logger(f'Generated the gene (including intron) information file for use in CogentDS in the process for {key}')

			# Remove temp file
			unlink(temp_file)

		# ----------
		# Transcript
		if not trans is None and not self.__transcript_info_file is None:
			if not path.isfile(self.__transcript_info_file) and not trans.result_file is None:				# Check if already created by other process
				Logger.info_logger('Generate the transcript information file for use in CogentDS', key)

				# Create temporary file in each working directory
				temp_file = f'{work_dir}/temp_transcript_info.csv'
				trans.create_transcript_info_file(self.__gtf_path, temp_file)

				# Copy the file if possible
				if not path.isfile(self.__transcript_info_file):					# Check file exists again
					shutil.copyfile(temp_file, self.__transcript_info_file)
					Logger.info_logger(f'Generated the transcript information file for use in CogentDS in the process for {key}')

				# Remove temp file
				unlink(temp_file)


	# endregion: Internal function
	# ---------------------------------

