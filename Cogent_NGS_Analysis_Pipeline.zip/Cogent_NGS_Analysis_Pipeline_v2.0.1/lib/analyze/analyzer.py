#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script of analyze sub-command.
#
# Script to perform counting analysis for exons and genes by fastq input data.
# This script receives output from demux command as input, then analyze according to
# specified experiment type (deems type of kit).
#

# -----------------------------------------------------------------------------
# region: Script Info

SCRIPT_NAME = "analyzer"
# VERSION = "1.5a"
MAIN_DESC = """
	Perform counting analysis for exons and genes by fastq input data.
	"""

# Do not put indent, because it effects for output.
SUB_DESC="""
description:
  Script to perform counting analysis for exons and genes by fastq input data.
  The input to this script are files output by Cogent demux.
  The fastq files are expected to contain the barcode info in the read name.
  Optionally it can also contain UMI info following the BC.
  The modules currently included are:
    - Trimming (cutadapt)
    - Alignment (STAR)
    - Counting (featureCounts)
    - Summarization (TBUSA)
    - Reporting (TBUSA, CogentDS)
"""
# endregion
# -----------------------------------------------------------------------------

# ---------- import modules ---------- #

from os import path
from os.path import isdir
import shutil
import sys
import os
import multiprocessing
from typing import Dict, List, Union

from analyze.analysis_processor import AnalysisProcessor
from analyze.tools.bam_merger import BamMerger
from analyze.tools.cogent_ds import CogentDS
from analyze.tools.star import Star
from common.cogent_error import CogentError
from common.config import Config

from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.util import get_fastq_file_list
from common.util.const import BamKeepMode, DebugMode, to_bam_keep_mode, to_debug_mode

from common.util.demux import find_summary_file, load_summary_file

from pprint import pprint

# -----------------------------------------------------------------------------
# region: Function

# Check all input requirements
def check_requirements(user_args, experiment: Experiment, genome_pref: Dict) -> bool:

	res = True

	# Check if number of threads requested is available
	Logger.info_logger(f'Detected number of CPUs: {multiprocessing.cpu_count()}')
	if multiprocessing.cpu_count() < user_args.threads_num * user_args.cores_num:
		Logger.info_logger(f'Input "threads x cores" is {user_args.threads_num * user_args.cores_num}. It exceeds installed number of CPUs.')

		if multiprocessing.cpu_count() < user_args.threads_num:
			user_args.threads_num = multiprocessing.cpu_count()

		# Check total number again
		if multiprocessing.cpu_count() < user_args.threads_num * user_args.cores_num:
			user_args.cores_num = int(multiprocessing.cpu_count() / user_args.threads_num)

		Logger.info_logger(f'Changed number of threads as {user_args.threads_num } and cores as {user_args.cores_num}.')

	# Check if input path (directory or text) exist
	if not isdir(user_args.input):
		Logger.error_both('Input directory does not exist.')
		res = False

	# Check if analysis is supported
	if not experiment.is_support_gene:
		Logger.error_both('The experiment type does not support gene analysis.')
		res = False

	if user_args.do_transcript and not experiment.is_support_transcript:
		Logger.error_both('The experiment type does not support transcript analysis.')
		res = False

	if user_args.do_fusion and not experiment.is_support_fusion:
		Logger.error_both('The experiment type does not support fusion analysis.')
		res = False

	if user_args.do_fusion and not genome_pref['fusion']:
		Logger.error_both('The genome does not support fusion analysis.')
		res = False

	if user_args.do_immune and not experiment.is_support_immune:
		Logger.error_both('The experiment type does not support immune analysis.')
		res = False

	if user_args.do_immune and not genome_pref['immune']:
		Logger.error_both('The genome does not support immune analysis.')
		res = False

	return res

def adjust_threads(user_args, samples_num: int):
	if user_args.threads_num > samples_num:
		total_num = user_args.threads_num * user_args.cores_num
		user_args.threads_num = samples_num
		user_args.cores_num = int(total_num / user_args.threads_num)
		Logger.info_logger(f'Number of threads exceeds the number of input samples. Adjusted number of threads as {user_args.threads_num } and cores as {user_args.cores_num}.')

def clean_work_dir(work_dir: str, key_list: List[str], debug_mode: DebugMode) -> bool:
	try:
		if debug_mode is DebugMode.NONE:					# Remove all files and directories
			shutil.rmtree(work_dir)
		else:
			for key in key_list:
				shutil.rmtree(path.join(work_dir, key))		# Remove only working directory per barcode. Keep log directory.

		return True
	except:
		Logger.error_both('Failed to clean working directory')
		return False


# endregion: Function
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# region: Main Function
def run(user_args, experiment: Experiment, config_dir: str, default_configs, first_log: str):

	# ---------- setup | parse/check user options ---------- #
	if user_args.out_dir.endswith('/'):
		user_args.out_dir = user_args.out_dir.rstrip('/')

	user_args.out_prefix = path.split(user_args.out_dir)[1]			# save child directory as prefix for output file names
	user_args.debug_mode = to_debug_mode(user_args.debug_mode)
	user_args.keep_bam = to_bam_keep_mode(user_args.keep_bam)

	# ---------- setup | output directory ---------- #
	work_dir = ''
	logs_dir = ''
	bam_dir = ''
	if path.isdir(user_args.out_dir):
		print(f'Error: Analysis dir already exists: {user_args.out_dir}', file=sys.stderr)
		return False
	else:
		# Create require directories
		target_dir = None
		try:
			target_dir = user_args.out_dir
			os.makedirs(target_dir)

			work_dir = path.join(user_args.out_dir, 'work')
			target_dir = work_dir
			os.makedirs(target_dir)

			logs_dir = path.join(work_dir, 'logs')
			target_dir = logs_dir
			os.makedirs(target_dir)

			bam_dir = path.join(user_args.out_dir, 'bam')
			target_dir = bam_dir
			os.makedirs(target_dir)

			if not user_args.skip_trim:
				target_dir = path.join(logs_dir, 'trim')
				os.mkdir(target_dir)

			target_dir = path.join(logs_dir, 'align')
			os.mkdir(target_dir)

			if experiment.is_use_umi and experiment.is_use_uss:
				target_dir = path.join(logs_dir, 'bam2csv')
				os.mkdir(target_dir)

			target_dir = path.join(logs_dir, 'feature_counts')
			os.mkdir(target_dir)

			if user_args.do_transcript:
				target_dir = path.join(logs_dir, 'rsem')
				os.mkdir(target_dir)

			if user_args.do_immune:
				target_dir = path.join(logs_dir, 'immune')
				os.mkdir(target_dir)

			if user_args.do_fusion:
				target_dir = path.join(logs_dir, 'fusion')
				os.mkdir(target_dir)

		except OSError as err:
			print(f'Unable to create directory: {target_dir}', file=sys.stderr)
			return False

	# ---------- setup | logger ---------- #
	Logger.initialize(SCRIPT_NAME, path.join(user_args.out_dir, f'{user_args.out_prefix}_{SCRIPT_NAME}.log'))
	Logger.info_logger(first_log)
	Logger.info_logger("Command name: " + SCRIPT_NAME)
	Logger.info_logger("Original call : " + " ".join(sys.argv))

	# ---------- setup | define local resources ---------- #
	# Write config to log
	tmp_conf = ""
	for k,v in default_configs.items():
		tmp_conf = tmp_conf + "  --" + str(k) + "," + ",".join([str(vl) for vl in v]) + "\n"
	Logger.info_logger("Configs loaded as: \n" + tmp_conf)

	# ---------- setup | check requirement ---------- #
	if not check_requirements(user_args, experiment, default_configs[Config.GENOME_CONFIG_KEY + user_args.genome_used][3]):
		return False

	star = None
	in_files = None
	try:
		# ---------- setup | Find counts_all.csv ---------- #
		demux_count_file = find_summary_file(user_args.input)						# file path or None is OK

		# ---------- setup | Load FASTQ file paths ---------- #
		in_files = get_fastq_file_list(user_args.input, experiment.read_mode)		# Check input files exist and load its path
		if in_files is None:
			return False

		# --- Load demuxed count results
		demux_summary = None
		if demux_count_file is None:
			return False
		else:
			demux_summary = load_summary_file(demux_count_file)

		# ---------- Adjust threads and cores again ---------- #
		adjust_threads(user_args, len(in_files.keys()))

		# ---------- Load extra STAR options ---------- #
		ex_star_option = Star.parse_star_option(user_args.star_params)

		# ---------- Load genome to shared memory ---------- #
		genome_dir = default_configs[Config.GENOME_CONFIG_KEY + user_args.genome_used][0]
		star = Star('', work_dir, logs_dir, default_configs['star_loc'][0], user_args.cores_num, genome_dir, ex_star_option)
		res = star.load_genome()
		if not res:
			return False

		# ---------- Process ---------- #
		analysisProcessor = AnalysisProcessor(
			user_args.threads_num, user_args.cores_num, experiment, user_args.skip_trim,
			work_dir, logs_dir, bam_dir, config_dir, default_configs, user_args.genome_used,
			user_args.keep_bam, user_args.do_transcript, user_args.do_immune, user_args.do_fusion,
			user_args.debug_mode, ex_star_option
			)

		res = analysisProcessor.process(in_files, demux_summary)
		if not res:
			return False

		# ---------- Merge all result files ---------- #
		report_obj = experiment.get_report_obj(
			analysisProcessor.results, user_args.out_dir, user_args.out_prefix,
			user_args.do_transcript, user_args.do_immune, user_args.do_fusion,
			user_args.debug_mode)
		report_obj.create(
			list(in_files.keys()), analysisProcessor.exon_info_file, analysisProcessor.gene_info_file,
			analysisProcessor.transcript_info_file, demux_summary=demux_summary
		)

		# ---------- BAM file management ---------- #
		if user_args.keep_bam is BamKeepMode.NONE:
			shutil.rmtree(bam_dir)
		else:
			merger = BamMerger(user_args.threads_num * user_args.cores_num, default_configs)
			merger.merge(demux_summary, bam_dir, user_args.keep_bam)

		# ---------- CogentDS | analysis / report ---------- #
		cogent_ds = CogentDS(
			work_dir, user_args.out_dir, logs_dir, experiment.norm_method.value, default_configs['rscript_loc'][0],
			user_args.out_dir, user_args.threads_num * user_args.cores_num, user_args.debug_mode, experiment.cogent_ds_config
			)
		res = cogent_ds.call_from_analyze()
		if not res:
			Logger.warning_logger('An issue was detected at CogentDS part, but continue the pipeline.')

	except CogentError as e:
		if e.function is None:
			Logger.error_both(f'{e.message}')
		else:
			Logger.error_both(f'{e.message} (at {e.function})')

		return False
	except KeyboardInterrupt:
		Logger.warning_both('Received Ctrl+C to terminate process.')
	finally:
		# ---------- Remove genome from shared memory ---------- #
		if not star is None:
			res = star.remove_genome()
			if not res:
				Logger.warning_both('Could not remove genome info from shared memory.')

	# ---------- Remove temporary files (final) ---------- #
	if not user_args.debug_mode is DebugMode.HIGH:
		if in_files is not None:
			if not clean_work_dir(work_dir, list(in_files.keys()), user_args.debug_mode):
				return False

	return True

# #endregion
# -----------------------------------------------------------------------------