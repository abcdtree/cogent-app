from datetime import datetime
import os
from typing import Dict, List, Union
from common.cogent_error import CogentError
from common.config import Config

from common.logger import Logger
from common.util.const import BamKeepMode
from common.util.util import elapsed_time, remove_dir, remove_file, run_system_cmd
from os import path, rename, unlink

class Star:

	# ---------------------------------
	# region: Property
	@property
	def COMMON_PARAMS(self) -> List[str]:
		return [
			'--outSAMtype', 'BAM Unsorted',
			'--genomeLoad', 'LoadAndKeep'
			]

	@property
	def COMBINED_PARAMS(self) -> List[str]:
		return [
			'--outSAMtype', 'BAM Unsorted',
			'--genomeLoad', 'LoadAndKeep',
			'--outReadsUnmapped', 'Fastx',
			# '--twopassMode', 'Basic',
			'--outSAMstrandField', 'intronMotif',
			'--chimSegmentMin', '12',
			'--chimJunctionOverhangMin', '8',
			'--chimOutJunctionFormat', '1',
			'--alignSJDBoverhangMin', '10',
			'--alignMatesGapMax', '100000',
			'--alignIntronMax', '100000',
			'--alignSJstitchMismatchNmax', '5 -1 5 5',
			'--outSAMattrRGline', 'ID:GRPundef',
			'--chimMultimapScoreRange', '3',
			'--chimScoreJunctionNonGTAG', '-4',
			'--chimMultimapNmax', '20',
			'--chimNonchimScoreDropMin', '10',
			'--peOverlapNbasesMin', '12',
			'--peOverlapMMp', '0.1',
			'--alignInsertionFlush', 'Right',
			'--alignSplicedMateMapLminOverLmate', '0',
			'--alignSplicedMateMapLmin', '30'
			]

	@property
	def ENCODE_PARAMS(self) -> List[str]:
		return [
			'--outSAMtype', 'BAM Unsorted',
			'--genomeLoad', 'LoadAndKeep',
			'--outReadsUnmapped', 'Fastx',
			'--outSAMstrandField', 'intronMotif',
			'--chimSegmentMin', '12',
			'--chimJunctionOverhangMin', '8',
			'--chimOutJunctionFormat', '1',
			'--alignSJDBoverhangMin', '10',
			'--alignMatesGapMax', '1000000',
			'--alignIntronMax', '1000000',
			'--alignSJstitchMismatchNmax', '5 -1 5 5',
			'--outSAMattrRGline', 'ID:GRPundef',
			'--chimMultimapScoreRange', '3',
			'--chimScoreJunctionNonGTAG', '-4',
			'--chimMultimapNmax', '20',
			'--chimNonchimScoreDropMin', '10',
			'--peOverlapNbasesMin', '12',
			'--peOverlapMMp', '0.1',
			'--alignInsertionFlush', 'Right',
			'--alignSplicedMateMapLminOverLmate', '0',
			'--alignSplicedMateMapLmin', '30',
			# '--outSAMunmapped', 'Within',
			'--outSAMattributes', 'NH HI AS NM MD',
			'--alignSJoverhangMin', '8',
			'--alignIntronMin', '20',
			'--outFilterType', 'BySJout',
			'--outFilterMultimapNmax', '20',
			'--outFilterMismatchNmax', '999',
			'--outFilterMismatchNoverReadLmax', '0.04',
			'--sjdbScore', '1'
			]

	@property
	def genome_bam(self) -> str:
		return self.__genome_bam

	@property
	def transcript_bam(self) -> str:
		return self.__transcript_bam

	@property
	def fusion_chimeric(self) -> str:
		return self.__fusion_chimeric

	# endregion: Property
	# ---------------------------------

	# ---------------------------------
	# region: Class method
	@classmethod
	def parse_star_option(cls, user_arg: Union[str, None]) -> Dict[str, str]:

		if user_arg is None:
			return {}

		res_dict = {}
		for option in user_arg.split(','):
			if '=' not in option:		# Ignore if delimiter is not included
				continue

			name, value = option.split('=', 1)
			res_dict[name] = value

		# Output parsed options to log file
		if len(res_dict) > 0:
			options = "\n".join([f'  --{key} = {value}' for key, value in res_dict.items()])
			Logger.info_logger("Detected extra STAR parameters: \n" + options)

		return res_dict

	# endregion: Class method
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, star_path: str, cores_num: int, genome_dir: str, extra_options: Dict[str, str]):
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__star_path = star_path
		self.__cores_num = cores_num
		self.__genome_dir = path.join(genome_dir, Config.STAR_INDEX_NAME)

		self.__extra_options = extra_options
		self.__use_combined = True

	def load_genome(self) -> bool:

		start_time = datetime.now()

		prefix = 'LoadGenome.'

		# Common options
		command = [
			self.__star_path,
			'--genomeDir', self.__genome_dir,
			'--genomeLoad', 'LoadAndExit',
			'--outFileNamePrefix', path.join(self.__work_dir, prefix)
		]

		log_stdout = path.join(self.__log_dir, f'load_genome_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'load_genome_stderr.txt')

		command_str = ' '.join(command)
		if not run_system_cmd(command_str, log_stdout, log_stderr):
			Logger.error_both('Failed to load genome.')
			return False

		# Remove temporary files
		remove_dir(path.join(self.__work_dir, prefix + '_STARtmp'))				# When STAR v2.7.3a
		remove_file(path.join(self.__work_dir, prefix + 'Aligned.out.sam'))
		remove_file(path.join(self.__work_dir, prefix + 'Log.progress.out'))
		remove_file(path.join(self.__work_dir, prefix + 'Log.final.out'))		# When STAR v2.7.8a
		remove_file(path.join(self.__work_dir, prefix + 'SJ.out.tab'))			# When STAR v2.7.8a

		# Move log file
		os.rename(path.join(self.__work_dir, prefix + 'Log.out'), path.join(self.__log_dir, prefix + 'Log.out'))

		Logger.info_logger("Loaded STAR genome to shared memory. Elapsed time: " + elapsed_time(start_time))

		return True

	def remove_genome(self) -> bool:

		start_time = datetime.now()

		prefix = 'RemoveGenome.'

		# Common options
		command = [
			self.__star_path,
			'--genomeDir', self.__genome_dir,
			'--genomeLoad', 'Remove',
			'--outFileNamePrefix', path.join(self.__work_dir, prefix)
		]

		log_stdout = path.join(self.__log_dir, f'remove_genome_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'remove_genome_stderr.txt')

		command_str = ' '.join(command)
		if not run_system_cmd(command_str, log_stdout, log_stderr):
			# Logger.error_both('Failed to remove genome.')
			return False

		# Remove temporary files
		remove_dir(path.join(self.__work_dir, prefix + '_STARtmp'))				# When STAR v2.7.3a
		remove_file(path.join(self.__work_dir, prefix + 'Aligned.out.sam'))
		remove_file(path.join(self.__work_dir, prefix + 'Log.progress.out'))
		remove_file(path.join(self.__work_dir, prefix + 'Log.final.out'))		# When STAR v2.7.8a
		remove_file(path.join(self.__work_dir, prefix + 'SJ.out.tab'))			# When STAR v2.7.8a

		# Move log file
		os.rename(path.join(self.__work_dir, prefix + 'Log.out'), path.join(self.__log_dir, prefix + 'Log.out'))

		Logger.info_logger("Removed STAR genome from shared memory. Elapsed time: " + elapsed_time(start_time))

		return True

	# Run command
	def run(self, input_r1: str = None, input_r2: str = None) -> bool:
		start_time = datetime.now()
		Logger.info_logger("Started alignment with STAR", self.__key)

		if input_r1 is None and input_r2 is None:
			raise CogentError('Both read1 and read2 for alignment are None.')

		# Setup files
		align_prefix = path.join(self.__work_dir, self.__key + ".")
		out_genome_bam = align_prefix + 'Aligned.out.bam'						# Assume output bam file name
		out_transcript_bam = align_prefix + 'Aligned.toTranscriptome.out.bam'
		out_chimeric = align_prefix + 'Chimeric.out.junction'				# Assume output Chimeric file name

		in_file_list = []
		if not input_r1 is None:
			in_file_list.append(input_r1)

		if not input_r2 is None:
			in_file_list.append(input_r2)

		log_stdout = path.join(self.__log_dir, f'{self.__key}_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'{self.__key}_stderr.txt')

		# Common options
		command = [
			self.__star_path,
			'--genomeDir', self.__genome_dir,
			'--outFileNamePrefix', align_prefix,
			'--runThreadN', str(self.__cores_num),
			'--quantMode', 'TranscriptomeSAM'
		]

		if self.__use_combined:
			command += self.COMBINED_PARAMS
			# command += self.ENCODE_PARAMS
		else:
			command += self.COMMON_PARAMS

		# Input files
		command += ['--readFilesIn'] + in_file_list
		if in_file_list[0].endswith('.gz'):
			command += ['--readFilesCommand', 'zcat']

		# Add extra options
		for key, value in self.__extra_options.items():
			command += [f'--{key}', value]

		command_str = ' '.join(command)
		Logger.info_logger("Launched STAR using command: " + command_str, self.__key)
		if not run_system_cmd(command_str, log_stdout, log_stderr):
			return False

		self.__genome_bam = out_genome_bam
		self.__transcript_bam = out_transcript_bam
		self.__fusion_chimeric = out_chimeric
		Logger.info_logger("Successfully completed alignment. Elapsed time: " + elapsed_time(start_time), self.__key)

		# ---

		return True

	def manage_bam_file(self, keep_bam: BamKeepMode, bam_dir: Union[str, None]) -> bool:
		try:
			if keep_bam is BamKeepMode.NONE or bam_dir is None:
				unlink(self.genome_bam)
				unlink(self.transcript_bam)
				unlink(self.fusion_chimeric)
			else:
				rename(self.genome_bam, path.join(bam_dir, path.basename(self.genome_bam)))
				rename(self.transcript_bam, path.join(bam_dir, path.basename(self.transcript_bam)))
				rename(self.fusion_chimeric, path.join(bam_dir, path.basename(self.fusion_chimeric)))
		except:
			Logger.error_both(f'Failed to manage bam file for {self.__key}', self.__key)
			return False

		return True

	def remove_temp_files(self) -> bool:
		try:
			unlink(path.join(self.__work_dir, f'{self.__key}.Log.final.out'))
			unlink(path.join(self.__work_dir, f'{self.__key}.Log.out'))
			unlink(path.join(self.__work_dir, f'{self.__key}.Log.progress.out'))
			unlink(path.join(self.__work_dir, f'{self.__key}.SJ.out.tab'))

			if self.__use_combined:
				unlink(path.join(self.__work_dir, f'{self.__key}.Unmapped.out.mate1'))

				# Only when paired-end
				target_file = path.join(self.__work_dir, f'{self.__key}.Unmapped.out.mate2')
				if path.isfile(target_file):
					unlink(target_file)

		except:
			Logger.error_both(f'Failed to remove temporary files of alignment for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_stdout.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of alignment for {self.__key}', self.__key)
			return False

		return True

