from datetime import datetime
import gzip
from typing import List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.util import count_fastq, elapsed_time, run_system_cmd
from os import path, unlink

class CutAdapt:

	# ---------------------------------
	# region: Property
	@property
	def COMMON_PARAMS(self) -> List[str]:
		return [
			'-m', '15',
			'--trim-n',
			'--max-n', '0.7',
			'-q', '20'
			]
	@property
	def trimmed_reads_num(self) -> int:
		return self.__num_result_reads

	@property
	def trimmed_read1(self) -> Union[str, None]:
		return self.__output_read1

	@property
	def trimmed_read2(self) -> Union[str, None]:
		return self.__output_read2

	# endregion: Property
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, cutadapt_path: str, cores_num: int, config_dir: str):
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__cutadapt_path = cutadapt_path
		self.__cores_num = cores_num
		self.__num_result_reads = -1
		self.__adapter_fasta = path.join(config_dir, 'adapters.fasta')

		self.__output_read1 = None
		self.__output_read2 = None

	# Run command
	def run(self, input_r1: str = None, input_r2: str = None) -> bool:
		start_time = datetime.now()
		Logger.info_logger("Started trimming module", self.__key)

		if input_r1 is None and input_r2 is None:
			raise CogentError('Both read1 and read2 for trimming are None.')

		# Setup files
		in_file_list = []
		out_file_list = []
		output_r1 = None
		output_r2 = None
		if not input_r1 is None:
			output_r1 = path.join(self.__work_dir, 'trimmed_R1.fastq.gz')
			in_file_list.append(input_r1)
			out_file_list.append(output_r1)
			self.__output_read1 = output_r1

		if not input_r2 is None:
			output_r2 = path.join(self.__work_dir, 'trimmed_R2.fastq.gz')
			in_file_list.append(input_r2)
			out_file_list.append(output_r2)
			self.__output_read2 = output_r2

		log_stdout = path.join(self.__log_dir, f'{self.__key}_stdout.txt')
		log_stderr = path.join(self.__log_dir, f'{self.__key}_stderr.txt')

		# Common options
		command = [
			self.__cutadapt_path,
			'-j', str(self.__cores_num),
		]
		command += self.COMMON_PARAMS

		# Output files
		command += [
			'-o', out_file_list[0],
			'-a', 'file:' + self.__adapter_fasta
			]
		if len(out_file_list) > 1:
			command += [
				'-p', out_file_list[1],
				'-A', 'file:' + self.__adapter_fasta
				]

		# Input files
		command += in_file_list

		command_str = ' '.join(command)
		Logger.info_logger("Launched cutadapt using command: " + command_str, self.__key)
		if not run_system_cmd(command_str, log_stdout, log_stderr):
			return False

		# Count trimmed fastq
		self.__num_result_reads = count_fastq(out_file_list[0])

		Logger.info_logger("Successfully completed trimming. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def remove_temp_files(self) -> bool:
		try:
			if not self.trimmed_read1 is None:
				unlink(self.trimmed_read1)

			if not self.trimmed_read2 is None:
				unlink(self.trimmed_read2)
		except:
			Logger.error_both(f'Failed to remove temporary files of trimming for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_stdout.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of trimming for {self.__key}', self.__key)
			return False

		return True


