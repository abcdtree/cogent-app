#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to perform BAM conversion to csv file when USS is required.
# For the job, samtools and bedtools are used.
#


import csv
from os import path, unlink
from datetime import datetime
from typing import Dict, List, Union

from common.logger import Logger
from common.util.const import BamKeepMode
from common.util.demux import DemuxSummary
from common.util.util import elapsed_time, run_system_cmd

class BamMerger:

	# initialize
	def __init__(self, cores: int, default_configs):
		# setup internal variables
		self.__cores = cores
		self.__samtools_path = default_configs['samtools_loc'][0]

	# ---------------------------------
	# region: Methods

	def merge(self, demux_summary: Dict[str, DemuxSummary], bam_dir: str, keep_bam: BamKeepMode) -> bool:

		start_time = datetime.now()
		Logger.info_logger(f"Started BAM merging: {keep_bam.value}")

		if keep_bam is BamKeepMode.NONE or keep_bam is BamKeepMode.EACH:	# Do nothing
			return True

		if keep_bam is BamKeepMode.SAMPLE:
			if not self.__merge_by_sample(demux_summary, bam_dir):
				Logger.error_both(f'Failed to merge BAM files per sample')
				return False
		elif keep_bam is BamKeepMode.MERGED:
			if not self.__merge_all_bams(demux_summary, bam_dir):
				Logger.error_both(f'Failed to merge BAM files into one BAM')
				return False
		else:
			Logger.error_both(f'Unknown BAM keeping mode: {keep_bam.value}')
			return False

		Logger.info_logger("Successfully completed BAM merging. Elapsed time: " + elapsed_time(start_time))

		return True

	def merge_by_list(self, target_list: str, group_name: str, analyze_dir: str, output_dir: str) -> bool:
		start_time = datetime.now()
		Logger.info_both(f"Started BAM merging by list")

		# Load barcodes and groups from list
		barcodes = self.__load_list(target_list, group_name)
		if barcodes is None:
			return False

		# Check BAM file path
		bam_files = self.__check_bam_file(list(barcodes.keys()), analyze_dir)
		if bam_files is None:
			return False

		# Group BAM files by target column
		merge_list = self.__group_by(barcodes, bam_files)

		# Do merging
		res = self.__merge_by_list(merge_list, output_dir)
		if not res:
			return False

		Logger.info_both("Successfully completed BAM merging. Elapsed time: " + elapsed_time(start_time))

		return True

	# endregion: Method
	# ---------------------------------

	# ---------------------------------
	# region: Internal functions

	def __merge_all_bams(self, demux_summary: Dict[str, DemuxSummary], bam_dir: str) -> bool:

		# List files and output to text
		in_bam_list = path.join(bam_dir, 'in_bam_file_list.txt')
		in_files = []
		with open(in_bam_list, 'w') as f:
			for key, info in demux_summary.items():
				if info.name == 'Non_sample':
					continue

				in_bam = path.join(bam_dir, key + '.Aligned.out.bam')
				f.write(in_bam + '\n')
				in_files.append(in_bam)		# Keep file path to remove later

		command = [
			self.__samtools_path, 'merge',
			'-@', str(self.__cores),
			'-b', in_bam_list,
			path.join(bam_dir, 'all_merged.bam')
			]

		if not run_system_cmd(' '.join(command)):
			return False

		# Remove temporary files
		for file in in_files:
			unlink(file)
		unlink(in_bam_list)

		return True

	def __merge_by_sample(self, demux_summary: Dict[str, DemuxSummary], bam_dir: str) -> bool:

		# Summary by sample name
		in_files = {}
		for key, info in demux_summary.items():
			if info.name == 'Non_sample':
				continue

			if not info.name in in_files:
				in_files[info.name] = []

			in_files[info.name].append(path.join(bam_dir, key + '.Aligned.out.bam'))

		# Merge per sample
		for key, files in in_files.items():

			# List files and output to text
			in_bam_list = path.join(bam_dir, 'in_bam_file_list.txt')
			with open(in_bam_list, 'w') as f:
				for bam_file in files:
					f.write(bam_file + '\n')

			command = [
				self.__samtools_path, 'merge',
				'-@', str(self.__cores),
				'-b', in_bam_list,
				path.join(bam_dir, f'{key}.bam')
				]

			if not run_system_cmd(' '.join(command)):
				return False

			# Remove temporary files
			for file in files:
				unlink(file)
			unlink(in_bam_list)

		return True

	def __load_list(self, file: str, target_column: str) -> Union[Dict[str, str], None]:

		# Find the delimiter
		delimiter = None
		with open(file, 'r', newline='') as f:
			header = f.readline()
			header = header.rstrip()

			# Try to split by "," and find columns first
			try:
				values = [x.strip('"') for x in header.split(',')]		# Split and remove double quote
				values.index('Barcode')									# Try to fetch index
				values.index(target_column)
				delimiter = ","											# Set delimiter as ","
				Logger.info_logger('Find delimiter as comma.')
			except ValueError:											# When meet an error, try to split by tab
				try:
					values = [x.strip('"') for x in header.split('\t')]	# Split and remove double quote
					values.index('Barcode')								# Try to fetch index
					values.index(target_column)
					delimiter='\t'
					Logger.info_logger('Find delimiter as tab.')
				except ValueError:
					Logger.error_both(f'Cannot detect delimiter or find required columns [Barcode/{target_column}]')
					return None

		# Open and read
		res = {}
		with open(file, 'r', newline='') as f:
			reader = csv.DictReader(f, delimiter=delimiter)
			for row in reader:
				# Ignore line only when we can find "Sample" column and it is "Non_sample"
				# This is assuming stats.csv output from analyze command
				if 'Sample' in row and row['Sample'] == 'Non_sample':
					continue

				group_name = row[target_column]
				if ' ' in group_name:
					group_name = group_name.replace(' ', '_')

				res[row['Barcode']] = group_name

		Logger.info_both(f'Loaded {len(res.keys())} barcodes.')

		return res

	def __check_bam_file(self, barcode_list: List[str], analyze_dir: str) -> Union[Dict[str, str], None]:

		res = {}
		for barcode in barcode_list:
			target_path = path.abspath(path.join(analyze_dir, 'bam', f'{barcode}.Aligned.out.bam'))
			if not path.isfile(target_path):
				Logger.error_both(f'Cannot find BAM file for {barcode}.')
				return None

			res[barcode] = target_path

		return res

	def __group_by(self, barcodes: Dict[str, str], bam_files: Dict[str, str]) -> Dict[str, List[str]]:

		res = {}
		for barcode, group_name in barcodes.items():
			res.setdefault(group_name, [])
			res[group_name].append(bam_files[barcode])

		Logger.info_both(f'Found {len(res.keys())} groups to merge.')

		return res

	def __merge_by_list(self, merge_list: Dict[str, List[str]], output_dir: str) -> bool:

		# Merge per sample
		for key, files in merge_list.items():

			Logger.info_both(f'Merging BAM files for {key}...')

			# List files and output to text
			in_bam_list = path.join(output_dir, 'in_bam_file_list.txt')
			with open(in_bam_list, 'w') as f:
				for bam_file in files:
					f.write(bam_file + '\n')

			temp_bam = path.join(output_dir, f'temp.bam')
			out_bam = path.join(output_dir, f'{key}.bam')
			temp_log = path.join(output_dir, 'temp.log')

			# Merge
			command = [
				self.__samtools_path, 'merge',
				'-@', str(self.__cores),
				'-b', in_bam_list,
				temp_bam
				]

			if not run_system_cmd(' '.join(command)):
				return False

			# Sort
			command = [
				self.__samtools_path, 'sort',
				'-@', str(self.__cores),
				'-o', out_bam,
				temp_bam
				]

			if not run_system_cmd(' '.join(command), stderr_file=temp_log):
				return False

			# Index
			command = [
				self.__samtools_path, 'index',
				'-@', str(self.__cores),
				out_bam,
				]

			if not run_system_cmd(' '.join(command)):
				return False

			# Remove temporary files
			unlink(temp_bam)
			unlink(in_bam_list)
			unlink(temp_log)

		return True

	# endregion: Internal functions
	# ---------------------------------
