from posix import listdir			# type: ignore
from posixpath import basename		# type: ignore
import shutil
from typing import Tuple, Union, Dict
from common.cogent_ds.ds_config_meta import DsConfigMeta
from common.logger import Logger
from datetime import datetime
from os import path, unlink
from common.util.analyze import get_clonotype_dir, get_gene_fusion_dir, get_gene_info_file, get_gene_matrix_file, get_stats_file, get_transcript_info_file, get_transcript_matrix_file
from common.util.const import AnalysisType, DebugMode
from common.util.util import elapsed_time, run_system_cmd

class CogentDS:

	def __init__(self, work_dir: str, out_dir: str, log_dir: str, norm_method: str, rscript: str, analyze_dir: str, cores: int,
				debug_mode: DebugMode, ds_config: Union[DsConfigMeta, None]):
		self.__work_dir = work_dir
		self.__out_dir = out_dir
		self.__log_dir = log_dir
		self.__rscript = rscript
		self.__cogent_ds = path.join(path.dirname(path.realpath(__file__)), "cogent_ds_report.R")
		self.__cores = cores
		self.__debug_mode = debug_mode
		self.__ds_config = ds_config

		# Fix norm method name
		self.__norm_method = norm_method
		if norm_method == 'fpkm':
			norm_method = 'rpkm'		# Adjust to implementation in CogentDS

		# Find files included in analyze directory
		if ds_config is None:
			self.__gene_matrix = get_gene_matrix_file(analyze_dir, None)
			self.__analyze_stats = get_stats_file(analyze_dir, None)
		else:
			self.__gene_matrix = get_gene_matrix_file(analyze_dir, ds_config.gene_matrices)
			self.__analyze_stats = get_stats_file(analyze_dir, ds_config.stats_files)

		# Logger.info_both(str(self.__gene_matrix))
		# Logger.info_both(str(self.__analyze_stats))

		self.__gene_info = get_gene_info_file(analyze_dir)
		self.__transcript_matrix = get_transcript_matrix_file(analyze_dir)
		self.__transcript_info = get_transcript_info_file(analyze_dir)
		self.__gene_fusion_dir = get_gene_fusion_dir(analyze_dir, work_dir)
		self.__clonotype_dir = get_clonotype_dir(analyze_dir, work_dir)

	# ---------------------------------
	# region: Methods

	def call_from_analyze(self) -> bool:
		if self.__ds_config is None:
			return self.__call()
		else:
			res = True
			for key in self.__ds_config.keys:
				res = res & self.__call(key = key)

			return res

	def call_run_transcript(self, stats: Union[str, None], matrix: str, info: str) -> bool:
		# Use files generated in this command (not from analyze command)
		if self.__ds_config is None:
			return self.__call(
				stats = stats,
				transcript_matrix = matrix,
				transcript_info = info
			)
		else:
			res = True
			for key in self.__ds_config.keys:
				if AnalysisType.TRANSCRIPT in self.__ds_config.additional_analysis[key]:
					res = res & self.__call(					# 2/9/2022 seoj Use same transcript matrix and stats for now.
						stats = stats,							# This is possibly a bug when want to generate two or more tanscript matrices and rda file per each
						transcript_matrix = matrix,				# For SSv4_UMI, we target only all reads. So this works fine.
						transcript_info = info,
						key = key
					)

			return res

	def call_run_gene_fusion(self, gene_fusion_dir: str) -> bool:
		# Use files generated in this command (not from analyze command)
		if self.__ds_config is None:
			return self.__call(
				gene_fusion_dir = gene_fusion_dir
			)
		else:
			res = True
			for key in self.__ds_config.keys:
				if AnalysisType.FUSION in self.__ds_config.additional_analysis[key]:
					res = res & self.__call(
						gene_fusion_dir = gene_fusion_dir,
						key = key
					)

			return res

	def call_run_immune(self, clonotype_dir: str) -> bool:
		# Use files generated in this command (not from analyze command)
		if self.__ds_config is None:
			return self.__call(
				clonotype_dir = clonotype_dir
			)
		else:
			res = True
			for key in self.__ds_config.keys:
				if AnalysisType.IMMUNE in self.__ds_config.additional_analysis[key]:
					res = res & self.__call(
						clonotype_dir = clonotype_dir,
						key = key
					)

			return res

	# endregion: Methods
	# ---------------------------------

	# ---------------------------------
	# region: Internal function
	def __call(self, key = None, stats = None, transcript_matrix = None, transcript_info = None, clonotype_dir = None, gene_fusion_dir = None) -> bool:

		start_time = datetime.now()

		if key is None:
			Logger.info_logger('Started CogentDS reporting module')
		else:
			Logger.info_logger(f'Started CogentDS reporting module for {key}')

		txm_list = None
		gene_fusion_overlay = None
		clonotype_overlay = None
		try:
			# Check requirements. Gene expression analysis results are must.
			if self.__gene_matrix is None or self.__analyze_stats is None or self.__gene_info is None:
				Logger.warning_logger("Unable to call CogentDS. Please check if the directory from analyze command includes correct files.")
				Logger.warning_logger('Skip reporting with CogentDS.')
				return False

			Logger.info_logger("Generate required data list from analyze command")

			Logger.info_logger("Prepare additional analysis data to input.")
			txm_list, tx_info = self.__handle_transcript_result(transcript_matrix, transcript_info, config_key=key)		# Create transcript matrix list
			gene_fusion_overlay = self.__handle_gene_fusion_result(gene_fusion_dir, config_key=key)						# Create gene-fusion overlay
			clonotype_overlay = self.__handle_immune_result(clonotype_dir, config_key=key)								# Create immune profile overlay

			res = True
			# if len(self.__gene_matrix) == 1:
			if self.__ds_config is None or key is None:
				use_key = list(self.__gene_matrix.keys())[0]

				stats_file = path.abspath(self.__analyze_stats[use_key])		# Set automatically detected file fist
				if stats is not None:											# If stats.csv is specified via function call
					stats_file = stats											# Use it as primary

				res = self.__run_cogent_ds(
						self.__gene_matrix[use_key], stats_file,
						txm_list, tx_info, gene_fusion_overlay, clonotype_overlay
						)
			else:
				stats_file = path.abspath(self.__analyze_stats[key])			# Set detected file fist
				if stats is not None:											# If stats.csv is specified via function call
					stats_file = stats											# Use it as primary

				res = self.__run_cogent_ds(
						self.__gene_matrix[key], stats_file,
						txm_list, tx_info, gene_fusion_overlay, clonotype_overlay,
						sub_name=key
						)

			if not res:
				return False

			if key is None:
				Logger.info_logger("Successfully completed reporting using CogentDS. Elapsed time: " + elapsed_time(start_time))
			else:
				Logger.info_logger(f"Successfully completed reporting using CogentDS for {key}. Elapsed time: " + elapsed_time(start_time))

			return True

		except Exception as err:
			Logger.error_logger(f"Unexpected error during CogentDS: {err}")
			return False
		finally:
			if self.__debug_mode is not DebugMode.HIGH:
				if not txm_list is None and txm_list != 'NULL':
					unlink(txm_list)

				if gene_fusion_overlay is not None and gene_fusion_overlay != 'NULL':
					shutil.rmtree(gene_fusion_overlay)

				if clonotype_overlay is not None and clonotype_overlay != 'NULL':
					shutil.rmtree(clonotype_overlay)

	def __run_cogent_ds(self, gm_file: str, stats_file: str, txm_list: str, tx_info: str, gene_fusion_overlay: str, clonotype_overlay: str, sub_name: str = None) -> bool:

		gm_list = path.join(self.__work_dir, "gm_list")
		metadata_list = path.join(self.__work_dir, "metadata_list")

		try:
			output_dir = path.join(self.__out_dir, "cogent_ds")
			log_stdout = path.join(self.__log_dir, 'cogent_ds_stdout.txt')
			log_stderr = path.join(self.__log_dir, 'cogent_ds_stderr.txt')

			if sub_name is not None:
				gm_list = gm_list + '_' + sub_name
				metadata_list = metadata_list + '_' + sub_name
				output_dir = path.join(output_dir, sub_name)
				log_stdout = path.join(self.__log_dir, f'cogent_ds_{sub_name}_stdout.txt')
				log_stderr = path.join(self.__log_dir, f'cogent_ds_{sub_name}_stderr.txt')

			# Create genematrix list
			with open(gm_list, 'w') as f:
				f.write(f'{path.abspath(gm_file)}\n')

			# Create metadata (stat.csv) list
			with open(metadata_list, 'w') as f:
				f.write(f'{path.abspath(stats_file)}\n')

			# Prepare command arguments
			command = [
				self.__rscript, self.__cogent_ds,
				gm_list, self.__gene_info, metadata_list,
				txm_list, tx_info,
				gene_fusion_overlay,
				clonotype_overlay,
				output_dir,
				self.__norm_method,
				str(self.__cores)
			]

			command_str = ' '.join(command)
			if not run_system_cmd(command_str, log_stdout, log_stderr):
				Logger.error_logger("Unable to generate HTML report using CogentDS.")
				Logger.error_logger(f"Check {basename(log_stderr)}.txt for issues")
				return False
			else:
				return True
		except Exception as err:
			Logger.error_logger(f"Unexpected error during CogentDS: {err}")
			return False
		finally:
			if self.__debug_mode is not DebugMode.HIGH:
				if not gm_list is None:
					unlink(gm_list)

				if not metadata_list is None:
					unlink(metadata_list)

	# Judge files to be used from analyze command or from specific command
	def __handle_transcript_result(self, matrix: Union[str, None], info: Union[str, None], config_key: str = None) -> Tuple[str, str]:

		if self.__ds_config is not None and config_key is not None:
			if AnalysisType.TRANSCRIPT not in self.__ds_config.additional_analysis[config_key]:	# Disable using transcript result if transcript is not enabled in config
				Logger.info_logger(f'Transcript analysis is disabled in this key to input CogentDS. key = {config_key}')
				return ('NULL', 'NULL')

		use_matrix = None
		use_info = None
		if matrix is None or info is None:														# If files from current command is None
			if self.__transcript_matrix is not None and self.__transcript_info is not None:		# Try to look for files from analyze command
				Logger.info_logger("Use transcript expression results from analyze command.")
				use_matrix = self.__transcript_matrix
				use_info = self.__transcript_info
		else:																					# Otherwise use files from current command (should be run_transcript_analysis)
			Logger.info_logger("Use transcript expression results from current command.")
			use_matrix = matrix
			use_info = info

		if use_matrix is None or use_info is None:
			Logger.info_logger("No data about transcript expression analysis for CogentDS")
			return ('NULL', 'NULL')

		Logger.info_logger("Generate data list about transcript expression")
		txm_list = path.join(self.__work_dir, "txm_list")
		with open(txm_list, "w") as f:
			f.write(f'{path.abspath(use_matrix)}\n')

		return (txm_list, use_info)

	# Judge files to be used from analyze command or from specific command
	def __handle_gene_fusion_result(self, gene_fusion_dir: Union[str, None], config_key: str = None) -> str:

		if self.__ds_config is not None and config_key is not None:
			if AnalysisType.FUSION not in self.__ds_config.additional_analysis[config_key]:	# Disable using fusion result if fusion is not enabled in config
				Logger.info_logger(f'Fusion analysis is disabled in this key to input CogentDS. key = {config_key}')
				return 'NULL'

		use_gene_fusion_dir = None
		if gene_fusion_dir is None:												# If dir is not specified from current command
			if self.__gene_fusion_dir is not None:
				Logger.info_logger("Use gene fusion results from analyze command.")
				use_gene_fusion_dir = self.__gene_fusion_dir							# Try to use directory may included in analyze dir
		else:
			Logger.info_logger("Use gene fusion results from current command.")
			use_gene_fusion_dir = gene_fusion_dir

		if use_gene_fusion_dir is None:
			Logger.info_logger("No data about gene fusion analysis for CogentDS")
			return 'NULL'

		if not path.isdir(use_gene_fusion_dir):
			Logger.warning_logger("Cannot find correct directory from gene fusion analysis")
			return 'NULL'

		# Check files exist and return value
		files = listdir(use_gene_fusion_dir)		# Listup files in target directory
		if 'gene_fusion.junction_reads.csv' in files and 'gene_fusion.span_frags.csv' in files and 'gene_fusion.metadata.csv' in files:
			if not use_gene_fusion_dir.endswith('/'):
				use_gene_fusion_dir += '/'

			return use_gene_fusion_dir
		else:
			Logger.warning_logger("Cannot find correct files from gene fusion analysis")
			return 'NULL'

	# Judge files to be used from analyze command or from specific command
	def __handle_immune_result(self, clonotype_dir: Union[str, None], config_key: str = None) -> str:

		if self.__ds_config is not None and config_key is not None:
			if AnalysisType.IMMUNE not in self.__ds_config.additional_analysis[config_key]:	# Disable using immune result if immune is not enabled in config
				Logger.info_logger(f'Immune analysis is disabled in this key to input CogentDS. key = {config_key}')
				return 'NULL'

		use_clonotype_dir = None
		if clonotype_dir is None:												# If dir is not specified from current command
			if self.__clonotype_dir is not None:
				Logger.info_logger("Use clonotype results from analyze command.")
				use_clonotype_dir = self.__clonotype_dir						# Try to use directory may included in analyze dir
		else:
			Logger.info_logger("Use clonotype results from current command.")
			use_clonotype_dir = clonotype_dir

		if use_clonotype_dir is None:
			Logger.info_logger("No data about immune analysis for CogentDS")
			return 'NULL'

		if not path.isdir(use_clonotype_dir):
			Logger.warning_logger("Cannot find correct directory from immune analysis")
			return 'NULL'

		# Check files exist and return value
		files = listdir(use_clonotype_dir)		# Listup files in target directory
		if 'clonotype_matrix.csv' in files and 'metadata.csv' in files:
			if not use_clonotype_dir.endswith('/'):
				use_clonotype_dir += '/'

			return use_clonotype_dir
		else:
			Logger.warning_logger("Cannot find correct files from immune analysis")
			return 'NULL'

	# endregion: Internal function
	# ---------------------------------
