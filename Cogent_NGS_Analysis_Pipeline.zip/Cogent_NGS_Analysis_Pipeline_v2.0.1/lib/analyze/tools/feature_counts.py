from datetime import datetime
from enum import Enum
import os
import re
import subprocess
from typing import Dict, List, Union, cast
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.const import StrandedMode
from common.util.util import elapsed_time, run_system_cmd
from os import path, unlink

class FeatureCountsType(Enum):
	EXON = 'exon'
	GENE = 'gene'
	MITOCHONDRIA = 'mito'
	NON_STRAND_EXON = 'unstrand'

class FeatureCounts:

	# ---------------------------------
	# region: Property
	@property
	def COMMON_PARAMS(self) -> List[str]:
		return [
			'--primary',
			'-R', 'CORE',
			'-F', 'GTF',
			'-Q', '0',
			'-B',
			'-g', 'gene_id'
			]

	@property
	def result_file(self) -> str:
		return self.__result_file

	@property
	def gene_info(self) -> Dict[str, str]:
		return self.__gene_info

	@property
	def gene_id_list(self) -> List[str]:
		return list(self.__gene_info.keys())

	# endregion: Property
	# ---------------------------------

	# ---------------------------------
	# region: Class method
	@classmethod
	def create_mito_gtf(cls, chr_file: str, out_dir: str) -> Union[str, None]:
		"""Function: create_mito_gtf for generating mito counts
		"""

		try:
			gtf_file = out_dir + "/mito.gtf"
			output_count = 0

			with open(chr_file, 'r') as ip, open(gtf_file, 'w') as op:
				# Pickup lines of mitochondria and output it as gtf
				for line in ip:
					values = line.rstrip().split('\t')
					if values[0] == 'MT' or values[0] == 'M':
						op.write('%s\t.\tgene\t1\t%s\t.\t+\t.\tgene_id "gMT";\n' % (values[0], values[1]))
						output_count += 1

			if output_count == 0:
				Logger.warning_logger(f'Unable to find mitochondria info in {chr_file}')
				return None
			else:
				if output_count > 1:
					Logger.warning_logger(f'Found multiple mitochondria info in {chr_file}')

				return gtf_file

		except subprocess.CalledProcessError as err:
			Logger.warning_logger("Unable to create mito gtf: " +  str(err))
			return None

	# endregion: Class method
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, log_dir: str, fc_path: str, cores_num: int, stranded_mode: StrandedMode, count_type: FeatureCountsType, gtf_path: str, is_paired: bool):
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__fc_path = fc_path
		self.__cores_num = cores_num
		self.__stranded_mode = stranded_mode
		self.__is_stranded = stranded_mode is not StrandedMode.NONE
		self.__count_type = count_type
		self.__get_path = gtf_path
		self.__is_paired = is_paired

		self.__gene_info = {}

		# Force to non stranded when NON_STRANDED_EXON analysis
		# This mode is for the calculation of strand specificity
		if count_type is FeatureCountsType.NON_STRAND_EXON:
			self.__is_stranded = False

	# Run command
	def run(self, bam_file: str) -> bool:

		start_time = datetime.now()
		Logger.info_logger("Started featureCounts", self.__key)

		log_stderr = path.join(self.__log_dir, f'{self.__key}_{self.__count_type.value}_stderr.txt')

		# -----
		# Generete command string
		fc_out_file = path.join(self.__work_dir, f'{self.__count_type.value}.featureCounts')			# Normal featureCounts output file
		command = [
			self.__fc_path,
			'-T', str(self.__cores_num),
			'-a', self.__get_path,
			'-o', fc_out_file
		]

		if self.__count_type is FeatureCountsType.EXON or self.__count_type is FeatureCountsType.NON_STRAND_EXON:
			command += ['-t', 'exon']
		elif self.__count_type is FeatureCountsType.GENE or self.__count_type is FeatureCountsType.MITOCHONDRIA:
			command += ['-t', 'gene']

		command += self.COMMON_PARAMS

		if self.__is_paired:
			command += ['-p']

		if self.__is_stranded:
			if self.__stranded_mode is StrandedMode.FORWARD:
				command += ['-s', '1']
			elif self.__stranded_mode is StrandedMode.REVERSE:
				command += ['-s', '2']
			else:
				Logger.error_logger('Incorrect setting for strandedness.', self.__key)
				return False

		command += [bam_file]

		# -----
		# Execute
		command_str = ' '.join(command)
		Logger.info_logger(f"Launched featureCounts for {self.__count_type.value} using command: " + command_str, self.__key)
		if not run_system_cmd(command_str, stderr_file=log_stderr):
			return False

		# Rename automatically output file .bam.featureCounts
		# This file is used for counting in CogentAP
		result_file = path.join(self.__work_dir, f'{self.__count_type.value}.bam.featureCounts')
		os.rename(f'{bam_file}.featureCounts', result_file)
		self.__result_file = result_file

		# Load gene ids only from exon results or gene results
		if self.__count_type is FeatureCountsType.EXON or self.__count_type is FeatureCountsType.GENE:
			self.__gene_info = self.__get_gene_info(fc_out_file)

		Logger.info_logger(f"Successfully completed featureCounts for {self.__count_type.value}. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def create_gene_info_file(self, gtf_file: str, out_file: str) -> Union[str, None]:

		try:
			with open (gtf_file) as inp, open(out_file, 'w') as out:
				# out.write("Gene_ID,Gene_Name,Gene_Biotype,Gene_Length\n")
				out.write(','.join(['Gene_ID', 'Ensembl_ID', 'Gene_Name', 'Gene_Biotype', 'Gene_Length']) + '\n')
				prev = 'NA'
				for line in inp:
					#Skip header lines
					if line.startswith('#'):
						continue

					#Process gtf line
					annot = str(line.rstrip().split("\t")[8]).split(";")
					gene_id = ""
					gene_name = ""
					gene_type = ""
					for i in range(0, len(annot)):
						entry = annot[i]
						if "gene_id" in entry:
							gene_id = entry.split('"')[1]
						if "gene_name" in entry:
							gene_name = entry.split('"')[1]
						if "gene_biotype" in entry:
							gene_type = entry.split('"')[1]

					if gene_id == prev:
						continue
					prev = gene_id

					if gene_id == '':
						continue

					if gene_id in self.__gene_info:
						out.write(','.join([gene_id + '_' + gene_name, gene_id, gene_name, gene_type, self.__gene_info[gene_id]]) + '\n')
					else:
						out.write(','.join([gene_id + '_' + gene_name, gene_id, gene_name, gene_type, str(1)]) + '\n')

		except EnvironmentError as err:
			raise CogentError(f"Unable to open files: {gtf_file}, {out_file}", 'create_gene_info_file')

		return out_file

	def __get_gene_info(self, feature_count_file: str) -> Dict[str, str]:
		"""Function: Obtain gene id and length for all genes from the gene
		level output file from featureCounts
		"""
		gene_info = {}
		try:
			Logger.info_logger(f'Start loading gene ids from {feature_count_file}', self.__key)
			with open(feature_count_file) as f:
				#Skip the two header lines
				f.readline()
				f.readline()
				for line in f:
					values = re.split('\t', line.rstrip())
					gene_info[values[0]] = values[5]
		except EnvironmentError as err:
			raise CogentError("Unable to open file: " + feature_count_file + "\n" + str(err))

		return gene_info

	def remove_temp_files(self) -> bool:
		try:
			unlink(path.join(self.__work_dir, f'{self.__count_type.value}.bam.featureCounts'))
			unlink(path.join(self.__work_dir, f'{self.__count_type.value}.featureCounts'))
			unlink(path.join(self.__work_dir, f'{self.__count_type.value}.featureCounts.summary'))
		except:
			Logger.error_both(f'Failed to remove temporary files of featureCounts ({self.__count_type.value}) for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_{self.__count_type.value}_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of featureCounts ({self.__count_type.value}) for {self.__key}', self.__key)
			return False

		return True