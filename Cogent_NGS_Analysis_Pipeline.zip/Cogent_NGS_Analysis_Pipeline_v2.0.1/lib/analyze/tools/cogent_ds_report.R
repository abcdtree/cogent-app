#!/usr/bin/env Rscript

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# R script to launch CogentDS.
#

# ---------- user arguments ---------- #

args = commandArgs(trailingOnly = TRUE)

# -------------------------------------
# Expected arguments from python script
# 1. gm_list
# 2. gene_info
# 3. metadata_list
# 4. txm_list
# 5. transcript_info
# 6. gene_fusion_overlay
# 7. immune_profile_overlay
# 8. output directory
# 9. normalization method
# 10. cores
# -------------------------------------

# -------------------------------------
library('SingleCellExperiment')
library('dplyr')

# Check arguments
txm_list <- NULL
tx_info <- NULL
genefusion_overlay <- NULL
immune_overlay <- NULL
if (args[4] != 'NULL'){
  txm_list <- args[4]
}
if (args[5] != 'NULL'){
  tx_info <- args[5]
}
if (args[6] != 'NULL'){
  genefusion_overlay <- args[6]
}
if (args[7] != 'NULL'){
  immune_overlay <- args[7]
}

# -------------------------------------
# Launch CogentDS
CogentDS::standard_analysis(
    gm_loc = args[1],
    gene_info_loc = args[2],
    metadata_loc = args[3],
    transcript_mat_loc = txm_list,
    transcript_info_loc = tx_info,
    overlay_genefusion_loc = genefusion_overlay,
    overlay_clonotype_loc = immune_overlay,
    output_dir = args[8],
    gm_norm_method = args[9],
    parallel_cores = as.numeric(args[10]),
    grouping_var = "Sample",
    report = TRUE
    )

# CogentDS::standard_analysis(
#     gm_loc = args[1],
#     metadata_loc = args[2],
#     gene_info_loc = args[4],
#     parallel_cores = as.numeric(args[6]),
#     gm_norm_method = args[5],
#     report = as.logical(args[7]),
#     output_dir = args[3],
#     qc_cell_abslowcov = 1, qc_cells_abslowgenecount = 1, qc_gene_cellcount = 1, qc_gene_totcov = 1
#     )
