from datetime import datetime
import gzip
from typing import List, Union
from common.cogent_error import CogentError

from common.logger import Logger
from common.util.util import count_fastq, elapsed_time, run_system_cmd
from os import path, unlink

class Ribopicker:

	# ---------------------------------
	# region: Property
	@property
	def COMMON_PARAMS(self) -> List[str]:
		return [
			'-dbs', 'rrnadb',
			'-id', 'rpick'
			]

	@property
	def extract_num(self) -> int:
		return 10000

	@property
	def ribosomal_ratio(self) -> float:
		if self.__rRNA_count == -1:
			return -1.0
		elif self.__rRNA_count == 0 and self.__non_rRNA_count == 0:
			return 0.0
		else:
			return self.__rRNA_count / (self.__rRNA_count + self.__non_rRNA_count)

	@property
	def rrna_fastq(self) -> str:
		return f'{self.__work_dir}/rpick_rrna.fq'

	@property
	def non_rrna_fastq(self) -> str:
		return f'{self.__work_dir}/rpick_nonrrna.fq'

	# endregion: Property
	# ---------------------------------

	def __init__(self, key: str, work_dir: str, ribopicker_path: str, seqtk_path: str, perl_path: str, cores_num: int):
		self.__key = key
		self.__work_dir = work_dir
		self.__ribopicker_path = ribopicker_path
		self.__seqtk_path = seqtk_path
		self.__perl_path = perl_path
		self.__cores_num = cores_num

		self.__rRNA_count = -1
		self.__non_rRNA_count = -1

	# Run command
	def run(self, input_file: str) -> bool:
		start_time = datetime.now()
		Logger.info_logger("Started ribopicker module", self.__key)

		# Run seqtk
		sub_start_time = datetime.now()
		sub_fastq = f'{self.__work_dir}/sub_sample.fastq'
		command = [self.__seqtk_path, 'sample', input_file, str(self.extract_num)]

		command_str = ' '.join(command)
		Logger.info_logger(f'Started sub sampling using command: {command_str}', self.__key)
		run_system_cmd(command_str, stdout_file=sub_fastq)
		Logger.info_logger(f'Finish sub-sampling. Elapased time: {elapsed_time(sub_start_time)}', self.__key)

		if count_fastq(sub_fastq) == 0:			# If there no reads, terminate process
			self.__rRNA_count = 0				# Set 0 to output value 0 in stats.csv
			self.__non_rRNA_count = 0
			Logger.warning_logger(f'No reads after sub sampling. Abort ribosomal counting.', self.__key)
			return True

		# Run ribopicker
		sub_start_time = datetime.now()

		command = [
			self.__perl_path, self.__ribopicker_path,
			'-f', sub_fastq,
			'-out_dir', self.__work_dir
			]
		command += self.COMMON_PARAMS

		command_str = ' '.join(command)
		Logger.info_logger(f'Started riboPicker using command {command_str}', self.__key)
		run_system_cmd(command_str)
		Logger.info_logger(f'Finish riboPicker. Elapased time: {elapsed_time(sub_start_time)}', self.__key)

		# Count result
		self.__rRNA_count = count_fastq(self.rrna_fastq)
		self.__non_rRNA_count = count_fastq(self.non_rrna_fastq)

		Logger.info_logger("Successfully completed ribosomal counting. Elapsed time: " + elapsed_time(start_time), self.__key)

		return True

	def remove_temp_files(self) -> bool:
		try:
			unlink(path.join(self.__work_dir, f'sub_sample.fastq'))

			if path.isfile(self.rrna_fastq):
				unlink(self.rrna_fastq)

			if path.isfile(self.non_rrna_fastq):
				unlink(self.non_rrna_fastq)
		except:
			Logger.error_both(f'Failed to remove temporary files of riboPciker for {self.__key}', self.__key)
			return False

		return True



