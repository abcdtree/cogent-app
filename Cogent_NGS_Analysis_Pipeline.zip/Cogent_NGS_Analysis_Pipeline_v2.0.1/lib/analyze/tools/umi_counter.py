#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to count UMI variation from demultiplexed FASTQ.
# Output all UMI variations and its count to text file.
#

from os import path
from typing import Union
import dnaio
import io
from datetime import datetime
import multiprocessing

from multiprocessing import Process, Manager, Pool
from collections import Counter, defaultdict

from common.logger import Logger
from common.util.util import elapsed_time


class UmiCounter:
	"""
	Class to count number of UMIs from demux result
	"""

	# -----------------------------------------------------------------------------
	# region: Constants
	DEFAULT_BUFFER_SIZE = 10240000
	DEFAULT_PROCESS_CORE = 8
	# endregion: Constants
	# -----------------------------------------------------------------------------

	# Initialize
	def __init__(self, process_cores: int = -1, buffer_size: int = -1):
		"""Initializing function

		Keyword Arguments:
			process_cores {int} -- Number of cores to use (default: {-1})
			buffer_size {int} -- Buffer size for chunking (default: {-1})
		"""

		self.__process_cores = self.DEFAULT_PROCESS_CORE
		self.__buffer_size = self.DEFAULT_BUFFER_SIZE

		if process_cores > 0:
			if process_cores > multiprocessing.cpu_count():
				self.__process_cores = multiprocessing.cpu_count()		# Fix use cpus not to excced maximum
			else:
				self.__process_cores = process_cores

		if buffer_size > 0:
			self.__buffer_size = buffer_size

	# -----------------------------------------------------------------------------
	# region: Methods
	def count(self, key: str, in_file: str, work_dir: str) -> Union[str, None]:
		"""Count from passed FASTQ and output result to a file.

		Arguments:
			in_file {str} -- FASTQ after demultiplexing
			out_file {str} -- Output file path.
		"""

		start_time = datetime.now()
		Logger.info_logger('Start counting UMI variation', key)

		buf = Counter()
		with dnaio.open(in_file, mode = 'r') as f:
			for record in f: 										# type: ignore
				values = record.name.split(' ')[0].split('_')		# type: ignore Split read name
				if len(values) < 3:									# Ignore if read name does not have UMI
					continue

				barcode, umi = values[1:3]							# Get barcode and UMI
				buf.update({umi: 1})

		# Check if valid UMIs were collected
		if len(buf) == 0:
			Logger.error_logger('No UMI found.', key)
			return None

		# Create each UMI variation
		output_file = path.join(work_dir, 'umi_count.txt')
		with open(output_file, 'w') as f:
			for umi, count in buf.items():
				f.write(f'{umi}\t{count}\n')

		Logger.info_logger("Successfully completed counting UMI variation. Elapsed Time: " + elapsed_time(start_time), key)
		return output_file


	# Old method in v1.0
	def count_by_chunk(self, in_file: str, out_file: str):
		"""Count from passed FASTQ and output result to a file.

		Arguments:
			in_file {str} -- FASTQ after demultiplexing
			out_file {str} -- Output file path.
		"""

		# Create synchronized dictionaly
		manager = Manager()
		pool = Pool(processes=self.__process_cores)
		pool_results = []

		with open(in_file, 'rb') as f:
			for chunk in dnaio.read_chunks(f, buffer_size=self.__buffer_size):
				# Run sub threads for each chunk
				chunk_data = []
				for record in dnaio.open(io.BytesIO(chunk)): # type: ignore
					chunk_data.append(record)

				pool_results.append(pool.apply_async(self.parse_read_name, args=(chunk_data,)))

		pool.close()
		pool.join()

		# Merge all counting
		umi_count = defaultdict(Counter)
		for res in pool_results:
			for barcode, counter in res.get().items():
				umi_count[barcode] += counter

		# Create each UMI variation
		with open(out_file, 'w') as f:
			for barcode, umi_list in umi_count.items():
				for umi, count in umi_list.items():
					f.write(f'{barcode}\t{umi}\t{count}\n')

	def parse_read_name(self, chunk_data):
		"""Parse read name and count up appropriate list.
		This is a function to be used for multiprocessing.

		Arguments:
			chunk_data {[type]} -- Chunked lines from input FASTQ.

		Returns:
			[type] -- Counted result dictionary
		"""

		# Initialize
		count_buf = defaultdict(Counter)

		for record in chunk_data:								# Get each record
			values = record.name.split(' ')[0].split('_')		# Split read name
			if len(values) < 3:									# Ignore if read name does not have UMI
				continue

			barcode, umi = values[1:3]							# Get barcode and UMI
			count_buf[barcode].update({umi: 1})

		return count_buf

	# endregion: Methods
	# -----------------------------------------------------------------------------
