#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to perform BAM conversion to csv file when USS is required.
# For the job, samtools and bedtools are used.
#

import logging
import os
import sys
import codecs
import subprocess

from os import path, unlink
from datetime import datetime
from typing import Union

from common.logger import Logger
from common.util.util import elapsed_time, run_system_cmd
from common.experiment.experiment import UssMode


class BAMProcessor:
	"""
	Process BAM files produced by STAR aligner.
	This class is mainly used to create csv files having read_name, barcode and aligned positions.
	"""

	# --- constants ---
	OUTFILE_NAME = 'umi_uss_info.csv'

	@property
	def result_csv(self) -> str:
		return self.__result_csv

	# initialize
	def __init__(self, key: str, work_dir: str, log_dir: str, cores: int, samtools_path: str, bam2bed_path: str):
		# setup internal variables
		self.__key = key
		self.__work_dir = work_dir
		self.__log_dir = log_dir
		self.__cores = cores
		self.__samtools_path = samtools_path						# Path of tools installed
		self.__bam2bed_path = bam2bed_path						# Path of tools installed

	# --- methods ---

	# create csv
	def to_csv(self, bam_file: str, uss_mode: UssMode) -> bool:
		"""Create CSV file by processing passed BAM file.

		Arguments:
			bam_file {str} -- A mapping result from STAR aligner.

		Keyword Arguments:
			debug {bool} -- Keep temporary files if True. (default: {False})

		Returns:
			str -- Path of created CSV file.
		"""

		try:
			start_time = datetime.now()
			Logger.info_logger('Started BAM processing', self.__key)

			# Check file exists
			if not path.isfile(bam_file):
				Logger.error_both(f'BAM file does not exist: {bam_file}', self.__key)
				return False

			# Extract primary alignments
			extracted_bam = self.__extract_primary(bam_file)
			if extracted_bam is None:
				Logger.error_both(f'Extracting primary alignments failed: {bam_file}', self.__key)
				return False

			# Sort by read name
			sorted_bam = self.__sort_bam(extracted_bam)
			if sorted_bam is None:
				Logger.error_both(f'Sorting BAM failed: {extracted_bam}', self.__key)
				return False

			# Convert to BED
			bed_file = self.__convert_bam_to_bed(sorted_bam)
			if bed_file is None:
				Logger.error_both(f'Converting to BED failed: {sorted_bam}', self.__key)
				return False

			# Strip Barcode and UMI to end of BED files as tags
			csv_file = self.__process_bed(bed_file, uss_mode)
			if csv_file is None:
				Logger.error_both(f'Processing BED file failed: {bed_file}', self.__key)
				return False

			self.__result_csv = csv_file

			Logger.info_logger(f"Successfully complated BAM processing. Elapsed time: " + elapsed_time(start_time), self.__key)
			return True

		except Exception as error:
			Logger.error_both('Unknown error was caused on BAM processing.', self.__key)
			Logger.error_both(str(error), self.__key)
			return False

	def remove_temp_files(self) -> bool:
		try:
			unlink(path.join(self.__work_dir, f'tmp.bam'))
			unlink(path.join(self.__work_dir, f'tmp.sorted.bam'))
			unlink(path.join(self.__work_dir, f'tmp.bed'))
		except:
			Logger.error_both(f'Failed to remove temporary files of BAM processing for {self.__key}', self.__key)
			return False

		return True

	def remove_log_files(self) -> bool:
		try:
			unlink(path.join(self.__log_dir, f'{self.__key}_bam_to_bed_stderr.txt'))
			unlink(path.join(self.__log_dir, f'{self.__key}_sort_stderr.txt'))
		except:
			Logger.error_both(f'Failed to remove log files of BAM processing for {self.__key}', self.__key)
			return False

		return True

	# --- internal functions ---

	# samtools view
	def __extract_primary(self, bam_file: str) -> Union[str, None]:
		"""Extract primary aligned reads with samtools

		Arguments:
			bam_file {str} -- Alignment result file

		Returns:
			str -- Path of extracted BAM file
		"""
		Logger.info_logger('Step1 processing primary_alignments start.', self.__key)

		result_file = self.__work_dir + '/tmp.bam'
		command = [
			self.__samtools_path, 'view',
			'-@', str(self.__cores),
			'-F', '0x100',
			'-b',
			'-o', result_file,
			bam_file
			]

		if not run_system_cmd(' '.join(command)):
			return None

		return result_file

	# samtools sort
	def __sort_bam(self, bam_file: str) -> Union[str, None]:
		"""Sort BAM files contains primary_alignments

		Arguments:
			bam_file {str} -- BAM file from extract_primary

		Returns:
			str -- Path of sorted BAM file
		"""
		Logger.info_logger('Step2 sorting reads start.', self.__key)

		result_file = self.__work_dir + '/tmp.sorted.bam'
		log_stderr = path.join(self.__log_dir, f'{self.__key}_sort_stderr.txt')

		command = [
			self.__samtools_path, 'sort',
			'-@', str(self.__cores),
			'-n',
			'-o', result_file,
			bam_file
			]

		if not run_system_cmd(' '.join(command), stderr_file=log_stderr):
			return None

		return result_file

	# Convert BAM to BED
	def __convert_bam_to_bed(self, bam_file: str) -> Union[str, None]:
		"""Convert sorted BAM files to BED format

		Arguments:
			bam_file {str} -- BAM file from sort_bam

		Returns:
			str -- Path of converted bed file
		"""
		Logger.info_logger('Step3 bamTobed start.', self.__key)

		result_file = self.__work_dir + '/tmp.bed'
		log_stderr = path.join(self.__log_dir, f'{self.__key}_bam_to_bed_stderr.txt')
		command = [
			self.__bam2bed_path, '-bedpe', '-mate1',
			'-i', bam_file
			]

		if not run_system_cmd(' '.join(command), stdout_file=result_file, stderr_file=log_stderr):
			return None

		return result_file

	# process bed file
	def __process_bed(self, bed_file: str, uss_mode: UssMode) -> Union[str, None]:
		"""Process BED file and output CSV file having UMI and USS.

		Arguments:
			bed_file {str} -- Path to bed file for conversion

		Returns:
			str -- Path to output file (CSV)
		"""
		Logger.info_logger('Step4 bed processing start.', self.__key)

		# Check format of passed BED and get umi_flag
		umi_flag = None
		with open(bed_file) as ip:
			first_line = ip.readline()

			if first_line.rstrip() == '':														# Avoid an error for no read. Empty output file will be created.
				Logger.warning_logger('No read was detected in the bed file.', self.__key)
			else:
				temp1 = first_line.rstrip().split('\t')
				temp2 = temp1[6].split("_")

				if len(temp2) == 2:
					umi_flag = False
				elif len(temp2) == 3:
					umi_flag = True
				else:
					Logger.error_both('Unrecognized fastq format. Check usage', self.__key)
					return None

		# Process file
		output_csv = path.join(self.__work_dir, self.OUTFILE_NAME)
		with open(bed_file) as ip, open(output_csv, 'w') as op:
			for line in ip:
				line_split = line.rstrip().split("\t")
				rname_split = line_split[6].split('_')

				out_umi = ''
				if umi_flag:
					out_umi = rname_split[2]
				else:
					out_umi = 'NA'

				out_uss = ''
				if uss_mode is UssMode.BOTH:
					out_uss = '_'.join(line_split[0:6])			# Use aligned position of both
				elif uss_mode is UssMode.READ1:
					out_uss = '_'.join(line_split[0:3])			# Use aligned position of read1
				elif uss_mode is UssMode.READ2:
					out_uss = '_'.join(line_split[3:6])			# Use aligned position of read2
				else:
					Logger.error_logger('Inconsistent configuration for USS. UssMode.NONE is invalid when uss is enabled.', self.__key)
					return None

				op.write(','.join([rname_split[0], out_umi, out_uss]) + '\n')

		return output_csv
