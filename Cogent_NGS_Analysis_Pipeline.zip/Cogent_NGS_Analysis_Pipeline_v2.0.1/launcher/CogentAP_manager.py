#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to manage CogentAP with GUI.
#


# ---------- import modules ---------- #

import argparse
import sys
import os
import datetime
import shutil
import subprocess
import csv
import glob

from gooey import Gooey, GooeyParser

# ---------- fxn | Run cogent demux ---------- #
def cogent_demux(cogent_path, r1, well_list, protocol, out_dir,
				r2 = None, n_processes = 16, background_bcs = None , umi_len = None,
				is_split_fastqs = True, mismatch = 1, is_debug = False, n_writers = 1,
				is_no_gzip = False, und_fq = False, i7_rc = 'Auto', i5_rc = 'Auto',
				read_buffer = 0.01, prog = 10000000):
	try:
		# required
		command = [
			cogent_path, 'demux',
			'-i', r1,
			'-b', well_list,
			'-t', protocol,
			'-o', out_dir
		]

		# Optional
		command += [
			'-n', str(n_processes),
			'-m', str(mismatch),
			'--n_writers', str(n_writers),
			'--i7_rc', str(i7_rc),
			'--i5_rc', str(i5_rc),
			'--read_buffer', str(read_buffer),
			'--prog', str(prog),
		]

		if r2 is not None:
			command += ['-p', r2]
		if umi_len is not None:
			command += ['-u', str(umi_len)]
		if not is_split_fastqs:
			command.append("--no_split_fastqs")
		if is_debug is True:
			command.append("--debug")
		if is_no_gzip is True:
			command.append('--no_gz')
		if und_fq is True:
			command.append('--undetermined_fq')
		if not background_bcs is None:
			command += ["--all_well_barcodes_file", background_bcs]

		c = subprocess.run(command)
		return c.returncode
	except:
		return 1


# ---------- fxn | Run CogentAP analyzer ---------- #
def cogent_analyze(cogent_path, demux_dir, genome, out_dir, protocol, n_processes = 16, is_debug = False, is_skip_trim = False,
					do_transcript = False, do_gene_fusion = False, do_immune_profiling = False):
	try:
		command = [
			cogent_path, 'analyze',
			'-i', demux_dir,
			'-g', genome,
			'--threads', str(n_processes),
			'-o', out_dir,
			'-t', protocol
			# '--normalize', type_of_normalization
		]

		if is_debug is True:
			command += ['--debug', 'high']

		if is_skip_trim is True:
			command.append("--skip_trimming")

		if do_transcript:
			command.append('--transcript')

		if do_gene_fusion:
			command.append('--fusion')

		if do_immune_profiling:
			command.append('--immune')

		c = subprocess.run(command)
		return c.returncode
	except:
		return 1

# ---------- fxn | Search config ---------- #
def load_genomes(base_path: str, genome_dir = 'genomes'):
		# find genomes
		genome_dir = os.path.join(base_path, genome_dir)
		if not os.path.exists(genome_dir):
			print('Error: Genomes are not installed.')
			return None

		# values['genomedir_loc'] = [genome_dir]

		genomes = os.listdir(genome_dir)
		for genome_name in genomes:
			target_path = os.path.join(genome_dir, genome_name) + '/'

			# look for gtf file in genome directory
			files = glob.glob(target_path + '*.gtf')
			if len(files) == 0:
				print('Error: No GTF is found for %s' % (genome_name))
				return None

		return genomes

# ---------- fxn | Define Options ---------- #
def set_runinfo_options(runinfo_group, genome_choices):
	# Global options
	runinfo_group.add_argument('--workflow', metavar = "Workflow",
								help = "Select workflow.", default = 'Demultiplexer & Analyzer',
								choices=['Demultiplexer (split FASTQ files by barcode)',
										'Demultiplexer (do not split FASTQ files by barcode)',
										'Demultiplexer & Analyzer'])

	runinfo_group.add_argument('--input_fastq', metavar = 'R1 FASTQ', widget = 'FileChooser',
								help='Input Read1 (R1) FASTQ file.')

	runinfo_group.add_argument('-p', '--paired_fastq', metavar = 'R2 FASTQ', widget = 'FileChooser',
								help='Input Read2 (R2) FASTQ file.')

	runinfo_group.add_argument('-b', '--barcodes_file', metavar = 'Well-List File',
								dest = 'bcs_file', widget = 'FileChooser',
								help = "Well-list file from ICELL8® cx CellSelect Software (recommended) or custom barcodes \n"
										"file (see User Manual at takarabio.com for details).")

	runinfo_group.add_argument('-t', '--type_of_experiment', dest = 'protocol', metavar = "Protocol",
								help = 'Experimental protocol used.',
								choices = [
									"ICELL8 full-length transcriptome analysis",
									"Plate-based full-length transcriptome analysis (no UMI)",
									"Plate-based full-length transcriptome analysis (with UMI)",
									"ICELL8 3′DE analysis (no UMI)",
									"ICELL8 3′DE analysis (with UMI)",
									"ICELL8 5′DE analysis (human TCR)",
									"Stranded RNA-seq analysis (with UMI)",
									"Stranded RNA-seq analysis (no UMI)"])

	runinfo_group.add_argument('-g', '--genome', dest = 'genome', metavar = 'Genome',
								help = 'Genome species/build.',
								default = genome_choices[0],
								choices = genome_choices)

	runinfo_group.add_argument('-o', '--output_dir', metavar = 'Output Directory',
								default = os.path.expanduser("~"), widget = 'DirChooser',
								help = 'Full path to output directory (e.g., /path/to/output_dir).')

	runinfo_group.add_argument('--prefix', metavar = 'Output Folder',
								default = "analysis",
								help = 'Output folder name (Alphanumerics or underscores only. No special characters.).')

def set_advanced_options(adv_group):
	adv_group.add_argument('-n', '--n_processes', dest = 'n_processes', metavar = "Processes",
						help = 'Number of processes to spawn during execution.',
						default = 16, type = int)

	adv_group.add_argument('-m', '--mismatch', dest = 'mismatch', metavar = "Mismatch",
						help = 'Number of mismatched bases allowed per barcode.',
						choices = ['0', '1'], default = '1')

	adv_group.add_argument('--debug', dest = 'is_debug', metavar = "Keep Temporary Files", action='store_true',
						help = 'Check to save all temporary files (default: temporary files are deleted).')

def set_demux_options(demux_group):
	demux_group.add_argument('-w', '--all_well_barcodes_file', metavar = 'Background Barcode List',
						dest = 'background_barcodes_file', widget = 'FileChooser',
						help = 'Barcodes file used to calculate background contamination from unselected \n '
								'barcodes. This file is built-in for standard protocols (defined by the \n '
								'"Protocol" option under the Run Information tab) but can be customized \n'
								'for rare cases where a custom chip or barcode set is used.',
						default = None)

	demux_group.add_argument('-u', '--umi_length', dest = 'umi_len', metavar = 'UMI Length',
						help = 'Enter a number value of nucleotides in the UMI to override the default value \n'
								'defined by the protocol selected in the Run Information.',
						default = None, type = int)

	demux_group.add_argument('--n_writers', dest = 'n_writers', metavar = 'Number of Writers',
						help = 'Number of writing processes to spawn during execution.', default = 1, type = int)

	demux_group.add_argument('--no_gz', dest = 'no_gz', action = "store_true", metavar = 'Compress Gzip', default = False,
						help = "Check to not compress the output FASTQ files (not recommended).")

	demux_group.add_argument('--undetermined_fq', dest = 'und_fq', metavar = 'Save Undetermined FASTQ Files',
						action = 'store_true',
						help = 'Check to save undetermined/unselected/short reads to an Undetermined FASTQ files. \n'
								'Default is to ignore these reads.')

	demux_group.add_argument('--i7_rc', dest = 'i7_rc', metavar = 'i7 Index',
						help = "Reverse-compliment i7 Index (full-length application only). Enter 'Auto' to detect and \n"
								"autocorrect the reverse complimentation of i5/i7 indices by certain Illumina® \n"
								"sequencers. Otherwise enter 'True' to force processing as reverse complement and \n"
								"'False' to force processing as forward stranded.",
						choices = ["Auto", "True", "False"], default = "Auto")

	demux_group.add_argument('--i5_rc', dest = 'i5_rc', metavar = 'i5 Index',
						help = 'See help for "i7 Index".', choices = ["Auto", "True", "False"], default = "Auto")

	demux_group.add_argument('--prog', dest = 'prog', type = int, metavar = 'Number of Chunk Reads for Progress',
						help = "Number of reads to process before updating status in log file.",
						default = 10000000)

	demux_group.add_argument('--read_buffer', dest = 'read_buffer', metavar = 'Read Buffer',
						help = 'Buffer size of data (in gigabytes) sent to each demultiplexing process.',
						default = 0.01, type = float)

def set_analyze_options(analyze_group):
	# analyze specific
	# analyze_group.add_argument('--normalize', dest='type_norm', metavar = 'Normalize',
	# 					help='Type of normalization desired.', choices=['cpm', 'tpm', 'fpkm'], default='cpm')

	analyze_group.add_argument('--skip_trimming', dest='skip_trim_reads', action = 'store_true', metavar = 'Skip Trimming',
						help = 'Check to skip trimming reads for adapters.', default=False)

	analyze_group.add_argument('--transcripts', dest = 'do_transcript', metavar = 'Transcript Expression Analysis',
						action = 'store_true', help = 'Check to do transcript-level analysis and generate a count matrix.', default=False)

	analyze_group.add_argument('--gene_fusion', dest = 'do_gene_fusion', metavar = 'Gene Fusion Analysis',
						action = 'store_true', help = 'Check to do gene fusion analysis and generate result matrices.', default=False)

	analyze_group.add_argument('--immune_profiling', dest = 'do_immune_profiling', metavar = 'Immune Profiling Analysis',
						action = 'store_true', help = 'Check to do immune profiling analysis and generate result matrices.', default=False)

# ---------- fxn | Check arguments ---------- #
def check_args(args, is_analyzer):
	args.output_dir = os.path.join(args.output_dir, args.prefix)

	if args.input_fastq is None:
		print('Must input R1 FASTQ', flush = True)
		sys.exit(1)

	if args.bcs_file is None:
		print("Must enter Well-list file from CellSelect Software in Demultiplexer Options", flush = True)
		sys.exit(1)

	if args.genome is None and is_analyzer is True:
		print("Must select genome.", flush = True)
		sys.exit(1)

	if args.protocol is None:
		print("Must select protocol.", flush = True)
		sys.exit(1)

	if args.output_dir is None:
		print('Must enter Output Directory', flush = True)
		sys.exit(1)

	if args.prefix is None:
		print('Must enter Output Folder', flush = True)
		sys.exit(1)

	if os.path.isfile(os.path.join(args.tools_dir, "cogent")) is False:
		print("Cogent Analysis Pipeline not found.", flush = True)
		sys.exit(1)

	# Convert protocol name to option name
	protocols = {
		'ICELL8 full-length transcriptome analysis': 'ICELL8_FLA',
		"ICELL8 3′DE analysis (no UMI)": 'ICELL8_3DE',
		"ICELL8 3′DE analysis (with UMI)": 'ICELL8_3DE_UMI',
		"ICELL8 5′DE analysis (human TCR)": 'ICELL8_5DE',
		'Stranded RNA-seq analysis (with UMI)': 'Stranded_UMI',
		'Plate-based full-length transcriptome analysis (no UMI)': 'SMARTSeq_FLA',
		'Stranded RNA-seq analysis (no UMI)': 'Stranded',
		'Plate-based full-length transcriptome analysis (with UMI)': 'SMARTSeq_FLA_UMI'
	}
	args.protocol = protocols[args.protocol]

# ---------- main ---------- #

@Gooey(program_name = 'Cogent™ NGS Analysis Pipeline',
	   program_description = 'GUI launcher: enter options below.',
	   show_success_modal = False,
	   header_show_subtitle = True,
	   default_size = (600, 650),
	   required_cols = 1, optional_cols = 1, tabbed_groups = True, advanced = True)
def main():

	# ---------- start | print time ---------- #
	print("start pipeline | " + str(datetime.datetime.now()), flush = True)

	# ---------- set | root directory ---------- #
	root_dir = os.path.dirname(os.path.realpath(sys.argv[0]))

	# ---------- load | local_tool_config ---------- #
	genome_choices = load_genomes(os.path.dirname(sys.executable))
	if genome_choices is None:
		print('Error when loading configs.', flush = True)
		sys.exit(1)

	# ---------- load | genome options ---------- #
	if len(genome_choices) == 0:
		print("Cannot find installed genomes.", flush = True)
		sys.exit(1)

	# ---------- configure | gooey parser - options ---------- #
	parser = GooeyParser()

	runinfo_group = parser.add_argument_group(
		"Run Information", "",
		gooey_options={'show_border': False, 'columns': 1}
	)

	adv_group = parser.add_argument_group(
		"Advanced Options", "",
		gooey_options={'show_border': False, 'columns': 1}
	)

	demux_group = parser.add_argument_group(
		"Demuxer Options", "",
		gooey_options={'show_border': False, 'columns': 1}
	)

	analyze_group = parser.add_argument_group(
		"Analyzer Options", "",
		gooey_options={'show_border': False, 'columns': 1}
	)

	# Set options
	set_runinfo_options(runinfo_group, genome_choices)
	set_advanced_options(adv_group)
	set_demux_options(demux_group)
	set_analyze_options(analyze_group)

	# ---------- run | parse args ---------- #
	args = parser.parse_args()

	# ---------- set | tools dir ---------- #
	args.tools_dir = os.path.join(os.path.dirname(os.path.realpath(sys.executable)))

	# ---------- set | workflow ---------- #
	if args.workflow == "Demultiplexer (split FASTQ files by barcode)":
		is_demuxer = True
		is_analyzer = False
		is_split_fastqs = True
	elif args.workflow == "Demultiplexer (do not split FASTQ files by barcode)":
		is_demuxer = True
		is_analyzer = False
		is_split_fastqs = False
	elif args.workflow == "Demultiplexer & Analyzer":
		is_demuxer = True
		is_analyzer = True
		is_split_fastqs = True
	else:
		is_demuxer = False
		is_analyzer = False
		is_split_fastqs = True

	# ---------- check | args ---------- #
	check_args(args, is_analyzer)

	# ---------- run | demuxer ---------- #
	c = 0
	if is_demuxer is True:
		print("running | cogent demux", flush = True)

		c = cogent_demux(
			cogent_path = os.path.join(args.tools_dir, "cogent"),
			r1 = args.input_fastq,
			r2 = args.paired_fastq,
			well_list = args.bcs_file,
			protocol = args.protocol,
			out_dir = os.path.join(args.output_dir, "demux"),
			n_processes = args.n_processes,
			background_bcs = args.background_barcodes_file,
			umi_len = args.umi_len,
			is_split_fastqs = is_split_fastqs,
			mismatch = args.mismatch,
			is_debug = args.is_debug,
			n_writers = args.n_writers,
			is_no_gzip = args.no_gz,
			und_fq = args.und_fq,
			i7_rc = args.i7_rc,
			i5_rc = args.i5_rc,
			read_buffer = args.read_buffer,
			prog = args.prog
		)

		if c != 0:
			print("error | cogent demux", flush = True)
			return 1


	# ---------- run | analyzer ---------- #
	if is_analyzer is True:

		print("running | cogent analyze", flush = True)

		if c == 1:
			print("error | issue with demultiplexed FASTQ file(s)", flush = True)
			return 1

		c = cogent_analyze(
			cogent_path = os.path.join(args.tools_dir, 'cogent'),
			demux_dir=os.path.join(args.output_dir, "demux"),
			genome = args.genome,
			protocol = args.protocol,
			n_processes = args.n_processes,
			out_dir = os.path.join(args.output_dir, "analysis"),
			# type_of_normalization = args.type_norm,
			is_debug = args.is_debug,
			is_skip_trim = args.skip_trim_reads,
			do_transcript=args.do_transcript,
			do_gene_fusion=args.do_gene_fusion,
			do_immune_profiling=args.do_immune_profiling
		)

		if c != 0:
			print("error | cogent analyze", flush = True)
			return 1

	# ---------- cleanup | structure output dir ---------- #

	if is_analyzer is True:

		try:
			shutil.move(os.path.join(args.output_dir, "analysis", "cogent_ds"), args.output_dir)

			if args.protocol == "SMARTSeq_FLA_UMI":
				html_file = os.path.join(args.output_dir, "cogent_ds", "5pUMI", "CogentDS.report.html")
				if os.path.isfile(html_file):
					shutil.move(html_file, os.path.join(args.output_dir, "CogentDS.5pUMI.report.html"))

				html_file = os.path.join(args.output_dir, "cogent_ds", "all", "CogentDS.report.html")
				if os.path.isfile(html_file):
					shutil.move(html_file, os.path.join(args.output_dir, "CogentDS.all.report.html"))
			else:
				shutil.move(os.path.join(args.output_dir, "cogent_ds", "CogentDS.report.html"), args.output_dir)

			# shutil.move(os.path.join(args.output_dir, "analysis", "analysis_stats.csv"), args.output_dir)
			stats_files = glob.glob(os.path.join(args.output_dir, "analysis", 'analysis_*_stats.csv'))
			for file in stats_files:
				shutil.move(file, args.output_dir)

			shutil.move(os.path.join(args.output_dir, "analysis", "gene_info.csv"), args.output_dir)

			matrix_files = glob.glob(os.path.join(args.output_dir, "analysis", 'analysis_*genematrix.csv'))
			for file in matrix_files:
				shutil.move(file, args.output_dir)

			if args.do_transcript:
				shutil.move(os.path.join(args.output_dir, "analysis", 'transcript'), args.output_dir)

			if args.do_gene_fusion:
				shutil.move(os.path.join(args.output_dir, "analysis", 'gene_fusion'), args.output_dir)

			if args.do_immune_profiling:
				shutil.move(os.path.join(args.output_dir, "analysis", 'immune'), args.output_dir)

		except Exception as e:
			print("error | configuring output directory")
			print(e)
			return 1

	return 0


if __name__ == '__main__':

	c = main()

	if c == 1:
		print("end pipeline | error | " + str(datetime.datetime.now()), flush = True)
		sys.exit(1)
	else:
		print("end pipeline | success | " + str(datetime.datetime.now()), flush = True)
