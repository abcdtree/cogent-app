#!/bin/bash

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a setup script for installing dependencies and genomes to be used with the CogentAP.
# This setup script is ONLY for Linux OS systems / servers.
# The script will make use of the conda environment CogentAP_tools/, the Installer created.
# Typically, pipelines use RAM and Disk storage commensurate to the data being analyzed.
# Requirements can be found in the pipeline's user manual.
# Requirements are only guidelines and will be higher with larger data sizes.
#

# Set action when received Ctrl+C
trap "kill 0" SIGINT

# ---------- Script info ---------- #

SCRIPT_NAME='cogent_setup'

USAGE='bash CogentAP_setup.sh [command] [options...]\n\n'
USAGE=${USAGE}'bash CogentAP_setup.sh install\n'
USAGE=${USAGE}'bash CogentAP_setup.sh genome_install [genome name]\n'

TOOL_NAME='CogentAP'
COGENT_AP_URL='https://www.takarabio.com/products/next-generation-sequencing/bioinformatics-tools/cogent-ngs-analysis-pipeline'
COGENT_DS_VERSION="v1.5.0"
HELPTEXT='Contact Takara Bio Technical Support\n'
SCRIPTDIR=`dirname "$(readlink -f "$0")"`

if [ $# -lt 1 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'update' ]; then
    printf "Error: This version of CogentAP does not support updating from the command line.\n"
    printf "Available updates can be found at: $COGENT_AP_URL\n"
    exit 1
elif [ $1 != 'install' ] && [ $1 != 'genome_install' ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'install' ] && [ $# -ne 1 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'genome_install' ] && [ $# -ne 2 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
# ---------- Genome install ---------- #
elif [ $1 == 'genome_install' ]; then
    {
        # Set values from option
        genome_name=$2

        printf 'Start installing genome: %s\n' $genome_name

        # Check launched path
        if [ ! -e "${TOOL_NAME}_tools" ]; then
            printf 'Error: Please move to the path where %s is installed or check if pipeline is installed correctly.\n' $TOOL_NAME
            exit 1
        fi

        log_file="${TOOL_NAME}_genome_install.log"

        echo "Genome Install log:" > $log_file
        echo "========================" >> $log_file
        echo "TIME - Start:" `date +'%Y-%m-%d %r'` >> $log_file
        echo "Genome name to install: ${genome_name}" >> $log_file

        # Download and extract genome index
        printf "Downloading...\n"
        if ${PWD}/${TOOL_NAME}_tools/bin/sshpass -v -p thatsgoodscience sftp -o HostKeyAlgorithms=+ssh-rsa,ssh-dss -o PreferredAuthentications=password -o PubkeyAuthentication=no -o StrictHostKeyChecking=no cogentap@fileshare.takarabio.com:download/genomes/${genome_name}.tar.gz genomes/ >> $log_file; then
            cd genomes
            printf "Extracting...\n"
            tar xzf ${genome_name}.tar.gz
            rm ${genome_name}.tar.gz
            cd ..

            printf "Successfully installed genome.\n"
            echo "Successfully installed genome." >> $log_file
            echo "TIME - Completion:" `date +'%Y-%m-%d %r'` >> $log_file
            exit 0
        else
            printf "Failed to install genome. Please check genome name and password.\n"
            printf "Or please try to download genome file manually according to user manual."
            echo "Failed to install genome." >> $log_file
            echo "TIME:" `date +'%Y-%m-%d %r'` >> $log_file
            exit 1
        fi

        exit 1
}
elif [ $1 == 'install' ]; then
    # Proceed with Install (rest of script)
    :
else
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
fi

# ---------- Install ---------- #

log_file="${TOOL_NAME}_install.log"
echo "Install log:" > $log_file
echo "========================" >> $log_file
echo "TIME - Start:" `date +'%Y-%m-%d %r'` >> $log_file

# Revise log_file path as absolute
log_file=`readlink -f ${log_file}`

# ====================
# Function
# ====================
current_pid=-1
# Waiting animation
function spinner() {
  local i=0
  local spin='/-\|'
  local n=${#spin}
  while true; do
      sleep 0.3
      printf "\r  %-30s: ${spin:i++%n:1} " "$*"
  done
}

# $1: Name
function start() {
    spinner $1 & current_pid=$!
    echo -e "\n# --------------------" >> $log_file
    echo "# Start installing ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
}

# $1: Name
function success() {
    kill $current_pid
    wait $current_pid 2> /dev/null

    printf "\r  %-30s: Success\n" "${1}"
    echo "Success: Installed ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
}

# $1: Name
function fail() {
    kill $current_pid
    wait $current_pid 2> /dev/null

    printf "\r  %-30s: Error\n" "${1}"
    printf "  Unable to install ${1}\n"
    echo "Error: Unable to install ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
    printf "\n"
    printf "$HELPTEXT"

    # Remove environment and directory
    conda remove -y -p $ENV_NAME --all >> $log_file
    rm -rf $EXT_DIR
}

# Prerequisites
# Install conda (Anaconda3 or Miniconda3 is recommended) and add it to PATH variable
# For more details:
# https://docs.conda.io/projects/conda/en/stable/user-guide/install/index.html
# wget https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh
# bash Miniconda3-latest-Linux-x86_64.sh
# Open a new terminal window, to use the updated PATH variable

printf "Installation of %s in progress...\n" "${TOOL_NAME}"

# ===========
# Check conda
# ===========
if conda --version; then
    printf 'Success: conda found\n'
else
    printf 'Error: conda not found\n'
    printf 'Please install Miniconda3 or Anaconda3 and add it to PATH variable\n'
    printf 'Check here for instructions: https://docs.conda.io/projects/conda/en/stable/user-guide/install/index.html\n'
    exit 1
fi

# ===========================
# Create environment in conda
# ===========================

ENV_NAME="${TOOL_NAME}_tools"
printf 'Creating a new environment in conda...\n'
if conda create -y --prefix ./$ENV_NAME python=3.8 git; then
    printf "Success: Created conda env %s.\n" "$ENV_NAME"
else
    printf 'Error: Unable to create conda env\n'
    printf $HELPTEXT
    conda remove -y -p ./$ENV_NAME --all
    exit 1
fi

# ====================
# Tools environment
# ====================
EXT_DIR="ext"                          # Directory to install external tools that are not able to be installed from conda
mkdir ${EXT_DIR}

# ====================
# Install packages with cogent_ap_env.yaml
# ====================
printf '## Install required tools and modules from conda ##\n'
echo -e "## Install required tools and modules from conda ##\n" >> $log_file

start "conda tools and modules with exact versions"
if conda env update -v -p $ENV_NAME --file $PWD/config/env/cogent_ap_env.exact.yaml >> $log_file; then
    success "conda tools and modules with exact versions"
else
    fail "conda tools and modules with exact versions"
    exit 1
fi

start "conda tools and modules with flexible versions"
if conda env update -v -p $ENV_NAME --file $PWD/config/env/cogent_ap_env.flexible.yaml >> $log_file; then
    success "conda tools and modules with flexible versions"
else
    fail "conda tools and modules with flexible versions"
    exit 1
fi

# ====================
# Install other library
# ====================
printf '\n'
printf '## Install system tools ##\n'
echo -e "## Install system tools ##\n" >> $log_file
tools="gcc g++ gfortran"
for tool in $tools;
    do
        start "${tool}"
        if ln -s $PWD/$ENV_NAME/bin/x86_64-conda_cos6-linux-gnu-$tool $PWD/$ENV_NAME/bin/$tool; then
            success $tool
        else
            fail $tool
            exit 1
        fi
    done

# ====================
# External tools
# ====================
printf '\n'
printf '## Install external tools ##\n'
echo -e "## Install external tools ##\n" >> $log_file

# ====================
# Install riboPicker
# ====================
start "riboPicker"

cwd=`pwd`
cd ${EXT_DIR}

# Download program
RP_NAME=ribopicker-standalone-0.4.3
if ${cwd}/${ENV_NAME}/bin/sshpass -v -p thatsgoodscience sftp -o HostKeyAlgorithms=+ssh-rsa,ssh-dss -o PreferredAuthentications=password -o PubkeyAuthentication=no -o StrictHostKeyChecking=no cogentap@fileshare.takarabio.com:download/riboPicker/${RP_NAME}.tar.gz ./ >> $log_file; then
    tar xzf ${RP_NAME}.tar.gz
    rm ${RP_NAME}.tar.gz
    success "riboPicker"
else
    cd ${cwd}
    printf "## Unable to download {$RP_NAME}.tar.gz ##\n"
    echo -e "## Unable to download {$RP_NAME}.tar.gz ##\n" >> $log_file
    fail 'riboPicker'
    exit 1
fi

echo "" >> $log_file

# Download database
start "ribosomal RNA database"
RP_DB_FILE=rrnadb_2012-01-17.tar.gz
if ${cwd}/${ENV_NAME}/bin/sshpass -v -p thatsgoodscience sftp -o HostKeyAlgorithms=+ssh-rsa,ssh-dss -o PreferredAuthentications=password -o PubkeyAuthentication=no -o StrictHostKeyChecking=no cogentap@fileshare.takarabio.com:download/riboPicker/${RP_DB_FILE} ${RP_NAME}/db/ >> $log_file; then
    cd ${RP_NAME}/db/
    tar xzf ${RP_DB_FILE}
    rm ${RP_DB_FILE}
    success "ribosomal RNA database"
    cd ..
else
    cd ${cwd}
    fail 'ribosomal RNA database'
    exit 1
fi

# Modify constants
abs_path=`pwd`
sed -e "s|use constant DB_DIR => 'db/';|use constant DB_DIR => '${abs_path}/db/';|" riboPickerConfig.pm > tmp1.pm
sed -e "s|use constant PROG_DIR => './';|use constant PROG_DIR => '${abs_path}/';|" tmp1.pm > tmp2.pm
mv tmp2.pm riboPickerConfig.pm
rm tmp1.pm
cd ${cwd}

# ====================
# Install STAR-Fusion
# ====================
start "STAR-Fusion"

cwd=`pwd`
cd ${EXT_DIR}

# Download package
STAR_FUSION=STAR-Fusion-v1.10.0.FULL.tar.gz
if wget https://github.com/STAR-Fusion/STAR-Fusion/releases/download/v1.10.0/${STAR_FUSION} >> $log_file; then
    tar xzf ${STAR_FUSION}
    rm ${STAR_FUSION}
    success "STAR-Fusion"
else
    cd ${cwd}
    fail 'STAR-Fusion'
    exit 1
fi

cd ${cwd}

# ====================
# conda activate
# Tools require conda environment and installed library should be placed after this section
# ====================
CONDA_BIN=`dirname \`which conda\``
CONDA_SH=`dirname $CONDA_BIN`/etc/profile.d/conda.sh
source $CONDA_SH
conda activate ${ENV_NAME} >> $log_file;
export CONDA_OVERRIDE_GLIBC=2.17

# ====================
# Install TRUST4
# ====================
start "TRUST4"

# Set variable for Makefile
CFLAGS="-g -Wall -O2 -I`readlink -f ${ENV_NAME}/include` -L`readlink -f ${ENV_NAME}/lib`"
CXXFLAGS="-O3 -I`readlink -f ${ENV_NAME}/include` -L`readlink -f ${ENV_NAME}/lib`"

cwd=`pwd`
cd ${EXT_DIR}
if wget https://github.com/liulab-dfci/TRUST4/archive/refs/tags/v1.0.4.tar.gz >> $log_file; then
    echo "Success: Downloaded TRUST4 package:" `date +'%Y-%m-%d %r'` >> $log_file
    tar xzf v1.0.4.tar.gz
    cd TRUST4-1.0.4
else
    cd ${cwd}
    conda deactivate >> $log_file;
    fail "TRUST4 - downloading"
    exit 1
fi

# Compile samtools first
cd samtools-0.1.19
if make CFLAGS="${CFLAGS}" >> $log_file; then
    echo "Success: Compiled samtools in advance:" `date +'%Y-%m-%d %r'` >> $log_file
    cd ..
else
    cd ${cwd}
    conda deactivate >> $log_file;
    fail "TRUST4 - samtools"
    exit 1
fi

# Compile TRUST4 package
if make CXXFLAGS="${CXXFLAGS}" >> $log_file; then
    cd ..
    rm v1.0.4.tar.gz
    success "TRUST4"
else
    cd ${cwd}
    conda deactivate >> $log_file;
    fail "TRUST4"
    exit 1
fi

cd ${cwd}

# Clear variable
CFLAGS=
CXXFLAGS=

# ====================
# conda deactivate
# ====================
conda deactivate >> $log_file;

# ====================
# Install CogentDS
# ====================
printf '\n'
printf '## Install CogentDS ##\n'
echo -e "## Install CogentDS ##\n" >> $log_file

start "CogentDS R package"

# Pull local tar/unzip paths to feed to R
echo "PATH=${PWD}/${ENV_NAME}/bin:$PATH" >> ${PWD}/${ENV_NAME}/lib/R/etc/Renviron
tar_path="${PWD}/${ENV_NAME}/bin/tar"
unzip_path="${PWD}/${ENV_NAME}/bin/unzip"
cmd="${PWD}/${ENV_NAME}/bin/Rscript"
cmd="${cmd} -e 'options(unzip = \"${unzip_path}\")'"
cmd="${cmd} -e 'Sys.setenv(TAR=\"${tar_path}\")'"
cmd="${cmd} -e 'devtools::install_local(\"CogentDS-1.5.0.zip\","
cmd="${cmd} upgrade=\"never\",dependencies=c(\"Depends\",\"Imports\"))'"
eval $cmd >> $log_file
if [ $? -eq 0 ]; then
    success "CogentDS"
else
    # fail "CogentDS"
    kill $current_pid
    wait $current_pid 2> /dev/null

    printf 'Error\n'
    printf '  Warning: Unable to install CogentDS, but proceeding with installation.\n'
fi

# Check and create genome directory
printf '\n'
printf '## Genomes directory ##\n'
gendir="$PWD/genomes"
if [ ! -e $gendir ]; then
    if mkdir $gendir; then
        printf '  %-30s: Success\n' "Creating genomes directory"
    else
        printf '  %-30s: Error\n' "Creating genomes directory"
        printf '  Unable to create genomes directory\n'
    fi
else
    printf '  Skip to create genomes directory.\n'
    echo 'Skip to create genomes directory.' >> $log_file
fi

printf "\n"
printf "Successfully installed %s pipeline and dependencies.\n" "$TOOL_NAME"
echo "Successfully installed all dependencies." >> $log_file

printf 'Please setup genomes next.\n'
echo "TIME - Completion:" `date +'%Y-%m-%d %r'` >> $log_file

exit 0
