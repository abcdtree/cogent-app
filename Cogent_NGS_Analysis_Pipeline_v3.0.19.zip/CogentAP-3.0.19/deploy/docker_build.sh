#!/bin/bash

CWD=`pwd`
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

# PROD
# ACCOUNT=065229861997

# DEV
ACCOUNT=684377419114

(cd $SCRIPT_DIR/.. && COMMIT_ID=`git rev-parse --short HEAD`; IMAGE_ID=${ACCOUNT}.dkr.ecr.us-east-2.amazonaws.com/cogent-nf-worker:${COMMIT_ID}; docker build . -t $IMAGE_ID -f deploy/Dockerfile && echo finished building $IMAGE_ID;)
