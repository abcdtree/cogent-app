#!/bin/bash

CWD=`pwd`
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )

(cd $SCRIPT_DIR/.. && COMMIT_ID=`git rev-parse --short HEAD`; zip -r $CWD/cogent.${COMMIT_ID}.zip -x=.git/** -x=test/** -x=test/ -x=.git/ -x=genomes/** -x=genomes/ -x=deploy/** -x=deploy/ -x=.nextflow/** -x=.nextflow/ -x=work/** -x=work/ -x=.* .)
