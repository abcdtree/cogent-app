#!/bin/bash

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a setup script for installing dependencies and genomes to be used with the CogentAP.
# This setup script is ONLY for Linux OS systems / servers.
# The script will make use of the conda environment CogentAP_tools/, the Installer created.
# Typically, pipelines use RAM and Disk storage commensurate to the data being analyzed.
# Requirements can be found in the pipeline's user manual.
# Requirements are only guidelines and will be higher with larger data sizes.
#

# Set action when received Ctrl+C
trap "kill 0" SIGINT

# ---------- Script info ---------- #

SCRIPT_NAME='cogent_setup'

USAGE='bash CogentAP_setup.sh [command] [options...]\n\n'
USAGE=${USAGE}'bash CogentAP_setup.sh install\n'
USAGE=${USAGE}'bash CogentAP_setup.sh genome_install [genome name]\n'

TOOL_NAME='CogentAP'
COGENT_AP_URL='https://www.takarabio.com/products/next-generation-sequencing/bioinformatics-tools/cogent-ngs-analysis-pipeline'
COGENT_DS_VERSION="v1.5.0"
HELPTEXT='Contact Takara Bio Technical Support\n'
SCRIPTDIR=`dirname "$(readlink -f "$0")"`

if [ $# -lt 1 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'update' ]; then
    printf "Error: This version of CogentAP does not support updating from the command line.\n"
    printf "Available updates can be found at: $COGENT_AP_URL\n"
    exit 1
elif [ $1 != 'install' ] && [ $1 != 'genome_install' ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'install' ] && [ $# -ne 1 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
elif [ $1 == 'genome_install' ] && [ $# -ne 2 ]; then
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
# ---------- Genome install ---------- #
elif [ $1 == 'genome_install' ]; then
    {
        # Set values from option
        genome_name=$2

        printf 'Start installing genome: %s\n' $genome_name

        # Check launched path
        if [ ! -e "${TOOL_NAME}_tools" ]; then
            printf 'Error: Please move to the path where %s is installed or check if pipeline is installed correctly.\n' $TOOL_NAME
            exit 1
        fi

        log_file="${TOOL_NAME}_genome_install.log"

        echo "Genome Install log:" > $log_file
        echo "========================" >> $log_file
        echo "TIME - Start:" `date +'%Y-%m-%d %r'` >> $log_file
        echo "Genome name to install: ${genome_name}" >> $log_file

        # Download and extract genome index
	mkdir -p genomes/
        printf "Downloading and extracting...\n"
	if (wget -O - -o $log_file https://cogent-genomes.s3.us-east-2.amazonaws.com/3.0/${genome_name}.tar.gz | tar -xzf - -C genomes/ 2>$log_file); then
            printf "Successfully installed genome.\n"
            echo "Successfully installed genome." >> $log_file
            echo "TIME - Completion:" `date +'%Y-%m-%d %r'` >> $log_file
            exit 0
        else
            printf "Failed to install genome. Please check genome name.\n"
            printf "Or please try to download genome file manually according to user manual."
            echo "Failed to install genome." >> $log_file
            echo "TIME:" `date +'%Y-%m-%d %r'` >> $log_file
            exit 1
        fi

        exit 1
}
elif [ $1 == 'install' ]; then
    # Proceed with Install (rest of script)
    :
else
    printf "Error: Check usage:\n"
    echo -e $USAGE
    exit 1
fi

# ---------- Install ---------- #

log_file="${TOOL_NAME}_install.log"
echo "Install log:" > $log_file
echo "========================" >> $log_file
echo "TIME - Start:" `date +'%Y-%m-%d %r'` >> $log_file

# Revise log_file path as absolute
log_file=`readlink -f ${log_file}`

# ====================
# Function
# ====================
current_pid=-1
# Waiting animation
function spinner() {
  local i=0
  local spin='/-\|'
  local n=${#spin}
  while true; do
      sleep 0.3
      printf "\r  %-30s: ${spin:i++%n:1} " "$*"
  done
}

# $1: Name
function start() {
    spinner $1 & current_pid=$!
    echo -e "\n# --------------------" >> $log_file
    echo "# Start installing ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
}

# $1: Name
function success() {
    kill $current_pid
    wait $current_pid 2> /dev/null

    printf "\r  %-30s: Success\n" "${1}"
    echo "Success: Installed ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
}

# $1: Name
function fail() {
    kill $current_pid
    wait $current_pid 2> /dev/null

    printf "\r  %-30s: Error\n" "${1}"
    printf "  Unable to install ${1}\n"
    echo "Error: Unable to install ${1}:" `date +'%Y-%m-%d %r'` >> $log_file
    printf "\n"
    printf "$HELPTEXT"

    # Remove environment and directory
    conda remove -y -p $ENV_NAME --all >> $log_file
    rm -rf $EXT_DIR
}

# Prerequisites
# Install conda/mamba (Miniforge mamba is recommended, but Anaconda3 or Miniconda3 are also supported).
# For more details:
# https://mamba.readthedocs.io/en/latest/installation/mamba-installation.html
# wget https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh
# bash https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Linux-x86_64.sh
# eval "$(/root/miniforge3/bin/conda shell.YOUR_SHELL_NAME hook)"

printf "Installation of %s in progress...\n" "${TOOL_NAME}"

# ===========
# Check conda
# ===========
if conda --version; then
    printf 'Success: conda found\n'
else
    printf 'Error: conda not found\n'
    printf 'Please install conda/mamba\n'
    printf 'Check here for instructions: https://mamba.readthedocs.io/en/latest/installation/mamba-installation.html\n'
    exit 1
fi

if mamba --version; then
    printf 'Success: mamba found\n'
    export CONDA_CMD=mamba
else
    printf 'Warning: mamba not found! Running without mamba may be signicantly slower.\n'
    printf 'Check here for installation instructions: \n'
    read -p "Do you want to proceed without mamba? " -n 1 -r
    echo    # (optional) move to a new line
    if [[ ! $REPLY =~ ^[Yy]$ ]]
    then
        printf 'User requested to stop installation.'
        exit 1
    fi
    printf 'Proceeding without mamba.'
    export CONDA_CMD=conda
fi

# ===========================
# Create environment in conda
# ===========================

ENV_NAME="${TOOL_NAME}_tools"
printf 'Creating a new environment in conda...\n'
if $CONDA_CMD create -y --prefix ./$ENV_NAME python=3.10; then
    printf "Success: Created conda env %s.\n" "$ENV_NAME"
else
    printf 'Error: Unable to create conda env\n'
    printf $HELPTEXT
    $CONDA_CMD remove -y -p ./$ENV_NAME --all
    exit 1
fi

# ====================
# Install packages with cogent_ap_env.yaml
# ====================
printf '## Install required tools and modules from conda ##\n'
echo -e "## Install required tools and modules from conda ##\n" >> $log_file

start "conda tools and modules"
if $CONDA_CMD env update -v -p $ENV_NAME --file $PWD/cogent_ap_env.yaml >> $log_file; then
    success "conda tools and modules"
else
    fail "conda tools and modules"
    exit 1
fi

# Check and create genome directory
printf '\n'
printf '## Genomes directory ##\n'
gendir="$PWD/genomes"
if [ ! -e $gendir ]; then
    if mkdir $gendir; then
        printf '  %-30s: Success\n' "Creating genomes directory"
    else
        printf '  %-30s: Error\n' "Creating genomes directory"
        printf '  Unable to create genomes directory\n'
    fi
else
    printf '  Skip to create genomes directory.\n'
    echo 'Skip to create genomes directory.' >> $log_file
fi

printf "\n"
printf "Successfully installed %s pipeline and dependencies.\n" "$TOOL_NAME"
echo "Successfully installed all dependencies." >> $log_file

printf 'Please setup genomes next. Pre-indexed genomes can be downloaded by running "bash CogentAP_setup.sh genome_install ${NAME}", where ${NAME} is hg38 or mm39.\n'
echo "TIME - Completion:" `date +'%Y-%m-%d %r'` >> $log_file

exit 0
