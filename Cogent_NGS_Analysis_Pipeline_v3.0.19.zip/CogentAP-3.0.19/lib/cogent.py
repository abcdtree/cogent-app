#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# This is a main script for CogentAP.
# This script receives one sub-command and parameters for that.
# Then appropriate task according to the sub-command is run.
#

import argparse
import importlib
import importlib.util
import os
import sys
from datetime import datetime
from ensurepip import version
from os import path
from typing import Dict, List, Union

import common.arguments as arguments
import demux.demuxer as demuxer
import select_barcode.select_barcode as select_barcode
from common.config import Config
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.util import elapsed_time

# -----------------------------------------------------------------------------
# region: Script Info
SCRIPT_NAME = "cogent"
DESCRIPTION = """
	Script to perform NGS analysis. Please see helps of each command for details.
"""
# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Commands Definition
SUB_COMMANDS = {
    "demux": [demuxer.MAIN_DESC, demuxer.SUB_DESC],
    "select_barcode": [select_barcode.MAIN_DESC, select_barcode.SUB_DESC],
}
# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Functions

# # Get version str
# def get_version() -> str:
# 	# Reads version number from VERSION file
# 	try:
# 		install_dir = os.path.join(os.path.dirname(__file__), '..')
# 		with open(os.path.join(install_dir, 'VERSION')) as f:
# 			version_no = f.read().strip()
# 			return version_no
# 	except:
# 		print('Error: Cannot open VERSION file.', file=sys.stderr)
# 		return 'ERROR'

# # Print command versions
# def print_versions():
# 	"""Print versions of Cogent
# 	"""

# 	# Reads version number from VERSION file
# 	version_str = get_version()
# 	if version_str != 'ERROR':
# 		print('v%s' % (version_str))


# Prepare arguments
def prepare_arguments(
    command: str, required, optional, experiment_names: List[str]
) -> bool:
    """Prepare arguments according to passed command

    Arguments:
            command {str} -- sub command
            default_configs {Dict[str, List[str]]} -- load data from local_config.csv

    Returns:
            bool -- success, or not
    """

    if command == "demux":
        arguments.prepare_demux(required, optional, experiment_names)
    elif command == "select_barcode":
        arguments.prepare_select_barcode(required, optional)
        
    return True


# Run commands
def run_command(
    command: str,
    input_args,
    config_dir: str,
    first_log: str,
    experiment_dict: Dict[str, Experiment],
) -> bool:
    experiment = None

    if command in ["demux"]:
        experiment = experiment_dict.get(input_args.type_exp, None)
        if experiment == None:
            print("Error: Incorrect experiment type", file=sys.stderr)
            return False

        experiment.initialize(config_dir)

    if command == "demux" and not experiment is None:
        return demuxer.run(
            input_args, experiment, first_log, os.path.join(config_dir, "..")
        )
    elif command == "select_barcode":
        return select_barcode.run(input_args, first_log)
    else:
        return False


def initialize_experiments(
    experiment_def: Dict[str, str]
) -> Union[Dict[str, Experiment], None]:
    classes = {}
    for class_name, module_name in experiment_def.items():
        module_path = f"common.experiment.{module_name}"
        spec = importlib.util.find_spec(module_path)
        if not spec is None:
            module = importlib.import_module(module_path)

            try:
                c = getattr(module, class_name)
                class_instance = c()
                classes[class_instance.name] = class_instance
            except AttributeError as e:
                print(f"Cannot load experiment class for {class_name}", file=sys.stderr)
                return None
        else:
            print(f"Cannot find module for {module_name}", file=sys.stderr)
            return None

    return classes


# endregion
# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# region: Main
if __name__ == "__main__":
    # Initialize Logger and output starting information
    first_log = "Started script execution: %s " % (SCRIPT_NAME)

    config_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../config")
    config = Config((os.path.realpath(__file__)), config_dir)

    # -----
    # Initialize all experiment type classes
    experiment_dict = initialize_experiments(config.get_experiments())
    if experiment_dict is None:
        sys.exit(1)

    # -----
    # Preapre arguments, parsers
    parser = argparse.ArgumentParser(description=DESCRIPTION, usage=SCRIPT_NAME)
    arguments.prepare_cogent(parser)

    # sub parsers (sub commands)
    sub_parsers = parser.add_subparsers(title="commands", dest="sub_command")
    for cmd, cmd_help in SUB_COMMANDS.items():
        sub_parser = sub_parsers.add_parser(
            cmd,
            help=cmd_help[0],
            description=cmd_help[1],
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        optional = sub_parser._action_groups.pop()  # change order of groups
        required = sub_parser.add_argument_group(
            "required arguments"
        )  # add required first
        sub_parser._action_groups.append(optional)  # re-set optional again
        if not prepare_arguments(cmd, required, optional, list(experiment_dict.keys())):
            sys.exit(1)

    # Parse arguments
    input_args = parser.parse_args()  # parse
    # if input_args.show_version:
    # 	print_versions()
    # 	sys.exit(0)

    if input_args.sub_command is None:  # If no command comes
        parser.print_help()
        sys.exit(0)

    # Run according to command
    start_time = datetime.now()
    res = run_command(
        input_args.sub_command, input_args, config_dir, first_log, experiment_dict
    )

    # Suppose Logger is initialized inside
    if res:
        if Logger.initialized():
            Logger.info_logger("Successfully completed script execution.")
            Logger.info_logger("Total elapsed time: " + elapsed_time(start_time))
        sys.exit(0)
    else:
        if Logger.initialized():
            Logger.error_both("Pipeline finished with error.")
        sys.exit(1)

# endregion
# -----------------------------------------------------------------------------
