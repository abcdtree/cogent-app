#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to generate gene list file from salmon outputs
# This script receives the output folder from salmon as input
#
# -----------------------------------------------------------------------------
import argparse
import os
from collections import defaultdict
import sys
import pathlib
import pandas as pd

DESCRIPTION = """Generate gene and transcript list files from salmon outputs."""

###
# Script information
###

# script info
SCRIPT_NAME = "create_gene_list.py"
VERSION = "3.0.19"


###
# Parse and define arguments
###


def _parse_command_line_args(sys_argv):
    """Takes in command line parameters and parses them for use

    Args:
        sys_argv: command line input

    Returns:
        args (list) : input argument values
    """
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    required = parser.add_argument_group("required arguments")

    required.add_argument(
        "-t",
        "--type",
        dest="type",
        help="File type - one of genes/transcripts.",
        required=True,
    )

    required.add_argument(
        "-r",
        "--result_dir",
        dest="result_dir",
        help="Directory to save the result file in",
        required=True,
    )

    required.add_argument(
        "-o",
        "--output_file",
        dest="output_file",
        help="Name of the result file to be created",
        required=True,
    )

    required.add_argument(
        "-g",
        "--gtf_file",
        dest="gtf_file",
        help="Path to gtf file",
        required=True,
    )

    args, unknown = parser.parse_known_args(sys_argv)
    return args

def parse_string(s, key):
    # Split the string into parts by semi-colon
    parts = s.split(';')

    # Initialize an empty dictionary
    d = {}

    # Iterate over each part
    for part in parts:
        # Strip leading/trailing whitespace
        part = part.strip()

        # Check if the part contains a space (indicating a key-value pair)
        if ' ' in part:
            # Split on the first space
            k, v = part.split(' ', 1)
            # Remove the quotes around the value
            v = v.strip('"')
        else:
            # If no space is found, this is a standalone key with no value
            k = part
            v = None

        # If the key already exists in the dictionary, raise an exception
        d[k] = v

    # Return the value associated with the requested key
    return d.get(key)


# ---------- main ---------- #
def main(sys_argv):
    args = _parse_command_line_args(sys_argv)

    type = args.type
    result_dir = args.result_dir
    info_file_name = args.output_file
    gtf_file = args.gtf_file


    gtf_df = pd.read_csv(gtf_file, sep='\t', header=None, comment='#')
    gtf_df.columns = ['seqname', 'source', 'feature', 'start', 'end', 'score', 'strand', 'frame', 'attribute']


    # set header for info file based on input
    info_file_header = ""


    if type == "genes":
        info_file_header = "Gene_ID, Gene_Name, Gene_Biotype, Gene_Length"
        gene_df = gtf_df[gtf_df.feature=="gene"].reset_index(drop=True)
        gene_df['Gene_ID'] = gene_df['attribute'].apply(lambda x: parse_string(x, 'gene_id'))
        gene_df['Gene_Name'] = gene_df['attribute'].apply(lambda x: parse_string(x, 'gene_name'))
        gene_df['Gene_Biotype'] =  gene_df['attribute'].apply(lambda x: parse_string(x, 'gene_biotype'))
        gene_df['Gene_Name'] = gene_df['Gene_Name'].replace('', pd.NA).fillna(gene_df['Gene_ID'])
        gene_df['Gene_Length'] = gene_df['end'] - gene_df['start'] + 1
        result_df = gene_df.filter([i.strip() for i in info_file_header.split(',')])
    elif type == "transcripts":
        info_file_header = "Transcript_ID, Transcript_Name, Gene_ID, Gene_Name, Transcript_Biotype, Transcript_Length"
        transcript_df = gtf_df[gtf_df.feature=="transcript"].reset_index(drop=True)
        transcript_df['Transcript_ID'] = transcript_df['attribute'].apply(lambda x: parse_string(x, 'transcript_id'))
        transcript_df['Gene_Name'] = transcript_df['attribute'].apply(lambda x: parse_string(x, 'gene_name'))
        transcript_df['Transcript_Name'] = transcript_df['attribute'].apply(lambda x: parse_string(x, 'transcript_name'))
        transcript_df['Transcript_Biotype'] = transcript_df['attribute'].apply(lambda x: parse_string(x, 'transcript_biotype'))
        transcript_df['Gene_ID'] = transcript_df['attribute'].apply(lambda x: parse_string(x, 'gene_id'))
        transcript_df['Gene_Name'] = transcript_df['Gene_Name'].replace('', pd.NA).fillna(transcript_df['Gene_ID'])
        transcript_df['Transcript_Name'] = transcript_df['Transcript_Name'].replace('', pd.NA).fillna(transcript_df['Transcript_ID'])
        transcript_df['Transcript_Length'] = transcript_df['end'] - transcript_df['start'] + 1
        result_df = transcript_df.filter([i.strip() for i in info_file_header.split(',')])

    # writing out the gene/intron/transcript info file
    pathlib.Path(os.path.join(result_dir)).mkdir(
        parents=True, exist_ok=True
    )
    output_info_file = os.path.join(result_dir, info_file_name)
    result_df.to_csv(output_info_file, index=False)


if __name__ == "__main__":
    main(sys.argv[1:])
