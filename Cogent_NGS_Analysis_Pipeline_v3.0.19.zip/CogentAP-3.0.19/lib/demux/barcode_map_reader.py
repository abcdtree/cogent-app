import re
from typing import Dict, List, Set, Union

from common.cogent_error import CogentError
from common.logger import Logger


class BarcodeMapReader:
    COL_BARCODE = "Barcode"
    COL_NAME = "Name"

    @property
    def barcode_list(self) -> List[str]:
        return list(self.__barcode_info.keys())

    @property
    def barcode_set(self) -> Set[str]:
        return set(self.__barcode_info.keys())

    @property
    def barcode_dist(self) -> Dict[str, str]:
        return self.__barcode_info

    def __init__(self, in_file: str) -> None:
        self.__input_file = in_file
        self.__barcode_info = {}

    def read(self) -> bool:
        is_format = self.is_formatted()
        if not is_format:
            return False

        return self.__load()

    def is_formatted(self, suppress_warning: bool = False) -> bool:
        res = True

        with open(self.__input_file, "r") as f:
            header = f.readline().rstrip()

            pos_barcode = -1
            pos_name = -1

            # Check separator
            sep = self.__find_separator(header, suppress_warning)
            if sep is None:
                res = False
            else:
                values = header.split(sep)
                if self.COL_BARCODE not in values:
                    Logger.error_logger(
                        f'No "{self.COL_BARCODE}" column in user input barcode map file.'
                    )
                    res = False
                elif self.COL_NAME not in values:
                    Logger.error_logger(
                        f'No "{self.COL_NAME}" column in user input barcode map file.'
                    )
                    res = False
                else:
                    pos_barcode = values.index(self.COL_BARCODE)
                    pos_name = values.index(self.COL_NAME)

            if res:
                # Check duplicates in the file
                barcodes = set()
                names = set()
                for line in f:
                    line = line.rstrip()
                    if line == "":  # Skip if empty line
                        continue

                    values = line.split(sep)
                    check_bc = values[pos_barcode]
                    check_name = values[pos_name]

                    if check_bc in barcodes:
                        Logger.error_logger(
                            f'Barcode "{check_bc}" is duplicated in user input barcode map file.'
                        )
                        res = False
                    else:
                        barcodes.add(check_bc)

                    if check_name in names:
                        Logger.error_logger(
                            f'Name "{check_name}" is duplicated in user input barcode map file.'
                        )
                        res = False
                    else:
                        names.add(check_name)
        return res

    # ---------------------------------
    # region: Internal functions
    def __load(self) -> bool:
        try:
            with open(self.__input_file) as f:
                # Load header
                header = f.readline().rstrip()
                sep = self.__find_separator(header, True)

                if sep is None:
                    return False

                values = header.split(sep)
                pos_barcode = values.index(self.COL_BARCODE)
                pos_name = values.index(self.COL_NAME)

                for line in f:
                    line = line.rstrip()
                    if line == "":  # Skip if empty line
                        continue

                    values = line.split(sep)
                    self.__barcode_info[values[pos_barcode]] = re.sub(
                        r"\W+", "", re.sub(r" |-", "_", values[pos_name])
                    )

        except EnvironmentError as err:
            raise CogentError(
                "Unable to open file: " + self.__input_file + "\n" + str(err), "__load"
            )

        Logger.info_logger(
            f"Loaded {len(self.__barcode_info)} barcodes from map file: {self.__input_file}"
        )

        return True

    def __find_separator(
        self, data: str, suppress_warning: bool = False
    ) -> Union[str, None]:
        sep = None
        values = re.split(r"\t", data)  # Try to split \t
        if len(values) > 1:
            sep = "\t"
        else:
            values = re.split(",", data)
            if len(values) > 1:
                sep = ","
            else:
                if not suppress_warning:
                    Logger.warning_both(
                        f"Cannot detect separator in barcode file: {self.__input_file}"
                    )

        return sep

    # endregion: Internal functions
    # ---------------------------------
