#!/usr/bin/env python3

import csv
import io
import itertools
import multiprocessing
import os
import re
import resource
import shutil
import subprocess
import sys
import traceback
from collections import Counter, defaultdict
from multiprocessing import Manager, Pipe, Pool, Process, Queue
from multiprocessing.connection import Connection
from os import path, unlink
from typing import Any, Dict, List, Set, Tuple, Union, cast

import dnaio
from common.cogent_error import CogentError
from common.experiment.experiment import Experiment
from common.logger import Logger
from common.util.const import ReadMode
from common.util.ordered_set import OrderedSet
from demux.barcode_map_reader import BarcodeMapReader
from demux.barcode_reader import BarcodeFileType, BarcodeReader
from demux.barcode_selector import BarcodeSelector
from demux.editor import Editor
from xopen import xopen

SCRIPT_NAME = "demuxer"
REPO_NAME = "CogentAP"
MAIN_DESC = """
        De-multiplex barcoded reads from sequence data stored in FASTQ files.
    """

# Do not put indent, because it is required for proper help display.
SUB_DESC = """
description:
  Script to de-multiplex barcoded reads from sequence data stored in FASTQ files. User options are
  designed to simplify de-multiplexing for experiments derived from Takara protocols. Barcode
  (and optionally UMI) sequences are extracted and stored in the read name. Users may specify whether the
  resulting de-multiplexed data are merged, or split into individual barcode-level files.
"""


# -----------------------------------------------------------------------------
# region : CONSTANT
KEYWORD_SHORT = "Short"
KEYWORD_UNSELECT = "Unselected"
KEYWORD_UNDETERMINED = "Undetermined"
# endregion
# -----------------------------------------------------------------------------


# ---------- fxn | load background barcodes ---------- #
def load_bg(
    bcs: Set[str],
    idx,
    experiment: Experiment,
    repo_path: str,
    user_background_file: str,
):
    try:
        hh1 = None
        hh2 = None
        bc_map = None
        idx_map = None

        if user_background_file is None:
            bc_map, hh1, hh2, idx_map = experiment.get_background_info(
                repo_path, bcs, idx
            )
        else:
            Logger.info_logger("Use user input backgournd barcodes file.")
            barcode_reader = BarcodeReader(user_background_file)
            barcode_reader.read()
            bc_map = barcode_reader.barcode_set
            idx_map = barcode_reader.separator_pos

        if bcs.issuperset(bc_map):
            Logger.info_logger("Loaded chip barcode map file.")
            if hh1 is None:
                Logger.info_logger("Generating hamming distance maps denovo.")
                hh1, hh2 = ham_denovo(bc_map=bc_map, idx=idx)
            else:
                Logger.info_logger("Loading hamming distance maps from source.")
                hh1 = ham_hash(ham_map=hh1)
                hh2 = ham_hash(ham_map=hh2)
        else:
            Logger.info_logger(
                "All barcodes not found in background. Background set to selected barcode list, computing hamming distance maps denovo."
            )
            bc_map = bcs
            idx_map = idx
            hh1, hh2 = ham_denovo(bc_map=bc_map, idx=idx)

        check_bcs(bcs, idx, bc_map, idx_map)

        return bc_map, idx, hh1, hh2
    except EnvironmentError as err:
        raise CogentError("Unable to open barcode map file \n" + str(err), "load_bg")


# ---------- fxn | check i5/i7 for reverse complement ---------- #


def check_rc(
    bcs: Set[str],
    experiment: Experiment,
    r1_file,
    r2_file,
    umi_len,
    idx,
    depth,
    i5_rc="Auto",
    i7_rc="Auto",
    base_bc_len=-1,
):
    if experiment.check_revcomp:
        Logger.info_logger("Start checking i5/i7 for reverse complement")

        bc_direction_counter = {
            "i5": Counter(fwd=0, rc=0, unmatched=0),
            "i7": Counter(fwd=0, rc=0, unmatched=0),
        }

        # Check barcode length to check
        bc_len = base_bc_len
        if bc_len == -1:  # If not specified in arguments
            bc_len = len(list(bcs)[0])  # Calculate from target barcodes

        with dnaio.open(r1_file, r2_file, mode="r") as reader:  # type: ignore
            for r1, r2 in reader:  # type: ignore
                if (
                    bc_direction_counter["i5"]["fwd"] + bc_direction_counter["i5"]["rc"]
                    >= depth  # noqa: W503
                    and bc_direction_counter["i7"]["fwd"]  # noqa: W503
                    + bc_direction_counter["i7"]["rc"]  # noqa: W503
                    >= depth  # noqa: W503
                ):
                    break
                bc_no_rc, umi = get_bc(
                    r1,
                    r2,
                    experiment,
                    bc_len,
                    umi_len,
                    hh1=None,
                    hh2=None,
                    idx=idx,
                    bcs_chip=bcs,
                    mismatch=0,
                )
                if bc_no_rc in bcs:
                    bc_direction_counter["i5"]["fwd"] += 1
                    bc_direction_counter["i7"]["fwd"] += 1
                else:
                    bc_i5_rc, umi = get_bc(
                        r1,
                        r2,
                        experiment,
                        bc_len,
                        umi_len,
                        hh1=None,
                        hh2=None,
                        idx=idx,
                        bcs_chip=bcs,
                        mismatch=0,
                        rev1=True,
                    )
                    bc_i7_rc, umi = get_bc(
                        r1,
                        r2,
                        experiment,
                        bc_len,
                        umi_len,
                        hh1=None,
                        hh2=None,
                        idx=idx,
                        bcs_chip=bcs,
                        mismatch=0,
                        rev2=True,
                    )
                    bc_both_rc, umi = get_bc(
                        r1,
                        r2,
                        experiment,
                        bc_len,
                        umi_len,
                        hh1=None,
                        hh2=None,
                        idx=idx,
                        bcs_chip=bcs,
                        mismatch=0,
                        rev1=True,
                        rev2=True,
                    )

                    if bc_both_rc in bcs:
                        bc_direction_counter["i5"]["rc"] += 1
                        bc_direction_counter["i7"]["rc"] += 1
                    elif bc_i5_rc in bcs:
                        bc_direction_counter["i5"]["rc"] += 1
                        bc_direction_counter["i7"]["fwd"] += 1
                    elif bc_i7_rc in bcs:
                        bc_direction_counter["i5"]["fwd"] += 1
                        bc_direction_counter["i7"]["rc"] += 1
                    else:
                        bc_direction_counter["i5"]["unmatched"] += 1
                        bc_direction_counter["i7"]["unmatched"] += 1

        i5_rc_ratio = bc_direction_counter["i5"]["rc"] / (
            bc_direction_counter["i5"]["fwd"] + bc_direction_counter["i5"]["rc"]
        )
        i7_rc_ratio = bc_direction_counter["i7"]["rc"] / (
            bc_direction_counter["i7"]["fwd"] + bc_direction_counter["i7"]["rc"]
        )

        if i5_rc != "Auto":
            Logger.info_logger(
                f"Reverse complement status for i5 index manually set to: {i5_rc}"
            )
            is_i5_rc = strbool(i5_rc)
        elif i5_rc_ratio > 0.5:
            Logger.info_logger(
                f"Evidence of reverse complementation for i5 index sequences ({round(100 * i5_rc_ratio, 1)}%). "
                "The i5 index sequences will be reverse complemented."
            )
            is_i5_rc = True
        else:
            is_i5_rc = False

        if i7_rc != "Auto":
            Logger.info_logger(
                f"Reverse complement status for i7 index manually set to: {i7_rc}"
            )
            is_i7_rc = strbool(i7_rc)
        elif i7_rc_ratio > 0.5:
            Logger.info_logger(
                f"Evidence of reverse complementation for i7 index sequences ({round(100 * i7_rc_ratio, 1)}%). "
                "The i7 index sequences will be reverse complemented."
            )
            is_i7_rc = True
        else:
            is_i7_rc = False

        return is_i5_rc, is_i7_rc
    else:
        return False, False


# ---------- fxn | check selected barcode length matches background barcodes ---------- #


def check_bcs(bcs, idx, bcs_chip, idx_chip):
    if int(idx_chip) >= 0:
        l1 = str(len(list(bcs)[0][0:idx]))
        l2 = str(len(list(bcs)[0][idx:]))
        l1_chip = str(len(list(bcs_chip)[0][0:idx_chip]))
        l2_chip = str(len(list(bcs_chip)[0][idx_chip:]))
        if not l1 == l1_chip or not l2 == l2_chip:
            raise CogentError(
                "Incorrect length of selected barcodes. Expected length: "
                + l1_chip  # noqa: W503
                + " (barcode 1) & "  # noqa: W503
                + l2_chip  # noqa: W503
                + " (barcode 2)",  # noqa: W503
                "check_bcs",
            )
    elif int(idx_chip) == -1:
        if not idx == idx_chip or not len(bcs[0]) == len(bcs_chip[0]):
            raise CogentError(
                "Length of input barcodes incorrect. Expected barcode length: "
                + str(len(bcs_chip[0])),  # noqa: W503
                "check_bcs",
            )


# ---------- fxns | set read buffer ---------- #


def set_read_buffer(gb):
    b = int(gb * 1073741824)
    return b


# ---------- fxns | set connections ---------- #


def set_connections(n_workers, n_writers):
    con = dict()
    con["reader_A"] = []
    con["reader_B"] = []
    con["writer_A"] = []
    con["writer_B"] = []
    for _ in range(n_workers):
        b, a = Pipe(duplex=False)
        con["reader_A"].append(a)
        con["reader_B"].append(b)
        out_a = []
        out_b = []
        for _ in range(n_writers):
            b, a = Pipe(duplex=False)
            out_a.append(a)
            out_b.append(b)
        con["writer_A"].append(out_a)
        con["writer_B"].append(out_b)
    return con


# ---------- fxn | set outfiles ---------- #


def set_outfiles(
    split_fastq, bcs: Set[str], sh, r1_keep, und_fq, out_dir, out_prefix, gzip: bool
) -> Dict[Any, Tuple]:
    outfiles = {}
    if split_fastq is True:
        # for i in range(len(bcs)):
        for barcode in bcs:
            if r1_keep:
                outfiles[barcode] = (
                    fq_bcf(
                        out_dir=out_dir,
                        out_prefix=out_prefix,
                        ext="R1.fastq",
                        bc=barcode,
                        sh=sh,
                        gzip=gzip,
                    ),
                    fq_bcf(
                        out_dir=out_dir,
                        out_prefix=out_prefix,
                        ext="R2.fastq",
                        bc=barcode,
                        sh=sh,
                        gzip=gzip,
                    ),
                )
            else:
                outfiles[barcode] = (
                    None,
                    fq_bcf(
                        out_dir=out_dir,
                        out_prefix=out_prefix,
                        ext="R2.fastq",
                        bc=barcode,
                        sh=sh,
                        gzip=gzip,
                    ),
                )
    else:
        if r1_keep:
            outfiles[0] = (
                fq_bcf(
                    out_dir=out_dir,
                    out_prefix=out_prefix,
                    ext="demuxed_R1.fastq",
                    gzip=gzip,
                ),
                fq_bcf(
                    out_dir=out_dir,
                    out_prefix=out_prefix,
                    ext="demuxed_R2.fastq",
                    gzip=gzip,
                ),
            )
        else:
            outfiles[0] = (
                None,
                fq_bcf(
                    out_dir=out_dir,
                    out_prefix=out_prefix,
                    ext="demuxed_R2.fastq",
                    gzip=gzip,
                ),
            )

    if und_fq is True:
        outfiles[KEYWORD_UNDETERMINED] = (
            fq_bcf(
                out_dir=out_dir,
                out_prefix=out_prefix,
                ext="undetermined_R1.fastq",
                gzip=gzip,
            ),
            fq_bcf(
                out_dir=out_dir,
                out_prefix=out_prefix,
                ext="undetermined_R2.fastq",
                gzip=gzip,
            ),
        )

    return outfiles


# ---------- fxn | demux main ---------- #


def demux_main(
    r1_file,
    r2_file,
    bcs: Set[str],
    bcs_chip: Set[str],
    experiment: Experiment,
    mismatch,
    split_fastq,
    umi_len,
    und_fq,
    sh,
    hh1,
    hh2,
    idx,
    rev1,
    rev2,
    read_buffer,
    out_dir,
    out_prefix,
    n_workers,
    n_writers,
    r1_keep,
    gzip: bool,
    prog,
    debug,
    hpc_mode: bool,
    base_bc_len: int,
):
    # set outfiles
    outfiles = set_outfiles(
        split_fastq, bcs, sh, r1_keep, und_fq, out_dir, out_prefix, gzip
    )

    # set work queue
    work_queue = Queue()

    # set connections
    con = set_connections(n_workers, n_writers)

    # create chunk of barcodes
    chunked_bcs = set_chunk(bcs, n_writers)
    bcs_chunk_index = {}  # Prepare reverse index for searching chunk index by barcode
    for i, barcodes in enumerate(chunked_bcs):
        for bc in barcodes:
            bcs_chunk_index[bc] = i

    # start reader
    reader = launch_reader(r1_file, r2_file, con, work_queue, read_buffer)

    # start workers
    workers = launch_workers(
        work_queue,
        n_workers,
        con,
        bcs,
        bcs_chip,
        experiment,
        mismatch,
        split_fastq,
        umi_len,
        hh1,
        hh2,
        idx,
        rev1,
        rev2,
        r1_keep,
        und_fq,
        bcs_chunk_index,
        n_writers,
        base_bc_len,
        debug,
    )

    # start writers
    writers, return_dict = launch_writers(
        outfiles,
        con,
        n_writers,
        bcs,
        sh,
        out_dir,
        out_prefix,
        prog,
        debug,
        gzip,
        hpc_mode,
        bcs_chunk_index,
    )

    # wait for processes to finish
    reader.join()

    for worker in workers:
        worker.join()

    for writer in writers:
        writer.join()

    for key, success in return_dict.items():
        if success is False:
            raise CogentError("Failed in subprocess", f"demux_main:{key}")

    # FIXME: Confirm if this strategy is OK. But should be changed to not generating unnecessary files
    # Remove Unnecessary files
    if experiment.read_mode != ReadMode.PAIRED:
        r = None
        if experiment.read_mode == ReadMode.READ1:  # Delete Read2 files
            r = re.compile(".+_R2\\.fastq.*")  # Catch both with/without .gz
        elif experiment.read_mode == ReadMode.READ2:  # Delete Read1 files
            r = re.compile(".+_R1\\.fastq.*")  # Catch both with/without .gz

        file_list = itertools.chain.from_iterable(outfiles.values())
        target_list = list(filter(r.match, file_list))  # type: ignore
        for f in target_list:
            if path.isfile(f):
                unlink(f)


# ---------- fxns | writer functions ---------- #

#
# launch_workers | initiate a worker process(es)
# writer_sub | signal open for data to work_queue | recv chunk index and data | run demux sub | stream to writers
#


def launch_workers(
    work_queue,
    n,
    con,
    bcs: Set[str],
    bcs_chip: Set[str],
    experiment: Experiment,
    mismatch,
    split_fastq,
    umi_len,
    hh1,
    hh2,
    idx,
    rev1,
    rev2,
    r1_keep,
    und_fq,
    bcs_chunk: Dict[str, int],
    chunk_num: int,
    base_bc_len: int,
    debug,
):
    workers = []
    for i in range(n):
        worker = Process(
            target=worker_sub,
            args=(
                i,
                work_queue,
                con,
                bcs,
                bcs_chip,
                experiment,
                mismatch,
                split_fastq,
                umi_len,
                hh1,
                hh2,
                idx,
                rev1,
                rev2,
                r1_keep,
                und_fq,
                bcs_chunk,
                chunk_num,
                base_bc_len,
                debug,
            ),
        )
        worker.daemon = True
        worker.start()
        workers.append(worker)
    return workers


def worker_sub(
    pid,
    work_queue,
    con,
    bcs: Set[str],
    bcs_chip: Set[str],
    experiment: Experiment,
    mismatch,
    split_fastq,
    umi_len,
    hh1,
    hh2,
    idx,
    rev1,
    rev2,
    r1_keep,
    und_fq,
    bcs_chunk: Dict[str, int],
    chunk_num: int,
    base_bc_len: int,
    debug=False,
):
    try:
        while True:
            work_queue.put(pid)
            chunk_index = con["reader_B"][pid].recv()
            if chunk_index == -1:
                for c in con["writer_A"][pid]:
                    c.send(-1)
                break
            elif chunk_index == -2:
                e, tb_str = con["reader_B"][pid].recv()
                Logger.error_logger("%s" % (tb_str))
                raise e
            if debug is True:
                if chunk_index % 100 == 0:
                    Logger.info_logger("Worker " + str(pid) + ": " + str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))  # type: ignore
            data1 = con["reader_B"][pid].recv_bytes()
            data2 = con["reader_B"][pid].recv_bytes()
            r1s, r2s, u1s, u2s, bc_cts = demux_sub(
                bcs,
                bcs_chip,
                data1,
                data2,
                experiment,
                mismatch,
                split_fastq,
                umi_len,
                r1_keep,
                und_fq,
                hh1,
                hh2,
                idx,
                rev1,
                rev2,
                base_bc_len,
            )
            for c in con["writer_A"][pid]:
                c.send(chunk_index)

            # Create chunk to send
            send_chunk = []
            for _ in range(chunk_num):
                send_chunk.append({})

            if split_fastq is True:
                for (
                    bc,
                    r2_data,
                ) in r2s.items():  # Loop based on read2 since read2 is always kept
                    target_chunk = bcs_chunk[bc]
                    if r1_keep is True:
                        send_chunk[target_chunk][bc] = (r1s[bc], r2_data)
                    else:
                        send_chunk[target_chunk][bc] = (None, r2_data)
            else:
                if r1_keep is True:
                    send_chunk[0][0] = (r1s[0], r2s[0])
                else:
                    send_chunk[0][0] = (None, r2s[0])

            if und_fq is True:  # Undetermined will be handled last chunk every time
                send_chunk[-1][KEYWORD_UNDETERMINED] = (u1s, u2s)

            for i, data in enumerate(send_chunk):
                c = con["writer_A"][pid][i]
                if i == 0:
                    c.send(bc_cts)

                c.send(data)

    except Exception as e:
        print("Exception has occured is worker " + str(pid), flush=True)
        for c in con["writer_A"][pid]:
            c.send(-2)
            c.send((e, traceback.format_exc()))


# ---------- fxns | writer functions ---------- #

#
# launch_writers | initiate a writer process(es) | return writer_pool
# writer_sub | wait for data from workers | when recieved send to editors to be written to file | editors save order
#   of input and save reads accordingly.
#


def launch_writers(
    outfiles: Dict[Any, Tuple],
    con,
    writer_count,
    bcs,
    sh,
    out_dir,
    out_prefix,
    prog,
    debug,
    gzip: bool,
    hpc_mode: bool,
    bcs_chunk: Dict[str, int],
):
    editors = []
    for _ in range(writer_count):
        editors.append({})

    for bc, files in outfiles.items():
        chunk_index = bcs_chunk[bc]
        editors[chunk_index][bc] = (
            Editor(files[0], hpc_mode=hpc_mode, gzip=gzip)
            if files[0] is not None
            else None,
            Editor(files[1], hpc_mode=hpc_mode, gzip=gzip),
        )

    writer_pool = []
    manager = Manager()
    return_dict = manager.dict()
    for i in range(writer_count):
        connections = [x[i] for x in con["writer_B"]]
        writer = Process(
            target=writer_sub,
            args=(
                i,
                editors[i],
                connections,
                bcs,
                sh,
                out_dir,
                out_prefix,
                return_dict,
                prog,
                debug,
            ),
        )
        writer.daemon = True
        writer.start()
        writer_pool.append(writer)

    return writer_pool, return_dict


def writer_sub(
    pid,
    editors: Dict[Any, Tuple],
    connections,
    bcs,
    sh,
    out_dir,
    out_prefix,
    return_dict,
    prog_inc=10000000,
    debug=False,
):
    # Initialize values
    bc_sum_cts = defaultdict(int)

    prog = prog_inc
    ct = 0

    success = True

    while connections:
        open_connections = cast(List[Connection], multiprocessing.connection.wait(connections))  # type: ignore
        for c in open_connections:
            chunk_index = c.recv()

            if chunk_index == -1:
                connections.remove(c)
                continue
            elif chunk_index == -2:
                e, tb_str = c.recv()
                Logger.error_logger("%s" % (tb_str))
                raise e

            if debug is True:
                if chunk_index % 100 == 0:
                    Logger.info_logger("Writer " + str(pid) + ": " + str(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss))  # type: ignore

            if pid == 0:
                bc_cts = c.recv()
                if sum(bc_cts.values()) > 0:
                    for bc, count in bc_cts.items():
                        bc_sum_cts[bc] += count

                ct = sum(bc_sum_cts.values())
                if ct > prog:
                    prog += prog_inc
                    Logger.info_logger(" ".join(["Processed", str(ct), "reads."]))

            # Receive output data and write it out
            outdata = c.recv()

            # check sent bc and editor bc
            for bc in outdata:
                if bc not in editors:
                    Logger.error_both(f"Mismatch barcode: {bc}")
                    raise CogentError(
                        "Found mismatch barcode between sent data and editors."
                    )

            for bc, editor in editors.items():
                if bc in outdata:  # When data exists in this chunk
                    if editor[0] is not None:  # Read1
                        editor[0].write(outdata[bc][0], chunk_index)

                    editor[1].write(outdata[bc][1], chunk_index)  # Read2
                else:
                    if editor[0] is not None:  # Read1
                        editor[0].write([], chunk_index)

                    editor[1].write([], chunk_index)  # Read2

    # close editor
    for bc, editor in editors.items():
        # Read1
        if editor[0] is not None:
            editor[0].close()
            if editor[0].done() is False:
                Logger.error_both(
                    f"Incomplete writing to file read1. [{bc}]. Please contact technical support."
                )
                success = False
        # Read2
        editor[1].close()
        if editor[1].done() is False:
            Logger.error_both(
                f"Incomplete writing to file read2. [{bc}]. Please contact technical support."
            )
            success = False

    if pid == 0:
        Logger.info_logger(" ".join(["Total | Processed", str(ct), "reads."]))
        write_bc_cts(bc_sum_cts, bcs, sh, out_dir, out_prefix)

    return_dict[f"Process-{str(pid)}"] = success


# ---------- fxns | reader functions ---------- #

#
# launch_reader | initiate a single reader process
# demux_reader | read through input files and send to available workers | send kill signal to all workers after data
#   is exhausted.
#


def launch_reader(r1_file, r2_file, con, work_queue, read_buffer):
    reader = Process(
        target=demux_reader, args=(r1_file, r2_file, con, work_queue, read_buffer)
    )
    reader.daemon = True
    reader.start()
    return reader


def demux_reader(r1_file, r2_file, con, work_queue, read_buffer):
    try:
        with xopen(r1_file, "rb") as r1:
            with xopen(r2_file, "rb") as r2:
                for i, (c1, c2) in enumerate(dnaio.read_paired_chunks(r1, r2, read_buffer)):  # type: ignore
                    pid = work_queue.get()
                    c = con["reader_A"][pid]
                    c.send(i)
                    c.send_bytes(c1)
                    c.send_bytes(c2)
        for _ in range(len(con["reader_A"])):
            pid = work_queue.get()
            con["reader_A"][pid].send(-1)
        Logger.info_logger("Reader finished processing FASTQ file(s).")
    except Exception as e:
        for pid in range(len(con["reader_A"])):
            con["reader_A"][pid].send(-2)
            con["reader_A"][pid].send((e, traceback.format_exc()))


# ---------- fxns | convert fq read(s) to bytes ---------- #


def read_converter(record):
    s = (
        "@"
        + record.name  # noqa: W503
        + "\n"  # noqa: W503
        + record.sequence  # noqa: W503
        + "\n+"  # noqa: W503
        + "\n"  # noqa: W503
        + record.qualities  # noqa: W503
        + "\n"  # noqa: W503
    ).encode("ascii")
    return s


def multiread_converter(records):
    out = bytearray()
    for record in records:
        s = (
            "@"
            + record.name  # noqa: W503
            + "\n"  # noqa: W503
            + record.sequence  # noqa: W503
            + "\n+"  # noqa: W503
            + "\n"  # noqa: W503
            + record.qualities  # noqa: W503
            + "\n"  # noqa: W503
        ).encode("ascii")
        out += s
    return out


# ---------- fxn | demux subroutine ---------- #


def demux_sub(
    bcs: Set[str],
    bcs_chip: Set[str],
    r1_inp,
    r2_inp,
    experiment: Experiment,
    mismatch,
    split_fastq,
    umi_len,
    r1_keep,
    und_fq,
    hh1=None,
    hh2=None,
    idx=-1,
    rev1=False,
    rev2=False,
    base_bc_len=-1,
):
    r1s = defaultdict(bytearray)
    r2s = defaultdict(bytearray)
    u1s = bytearray()
    u2s = bytearray()
    bc_counts = defaultdict(int)

    # Check barcode length to calculate
    bc_len = base_bc_len
    if bc_len == -1:
        bc_len = len(list(bcs)[0])

    with dnaio.open(io.BytesIO(r1_inp), io.BytesIO(r2_inp), mode="r") as reader:  # type: ignore
        for r1, r2 in reader:
            bc = None
            umi = None
            bc, umi = get_bc(
                r1,
                r2,
                experiment,
                bc_len,
                umi_len,
                hh1,
                hh2,
                idx,
                bcs_chip,
                mismatch,
                rev1,
                rev2,
            )

            if bc in bcs:
                bc_counts[bc] += 1
                experiment.process_read_on_demux(r1, r2, bc, bc_len, umi)
                if split_fastq is True:
                    if r1_keep is True:
                        r1s[bc].extend(read_converter(r1))
                    r2s[bc].extend(read_converter(r2))

                else:
                    if r1_keep is True:
                        r1s[0].extend(read_converter(r1))
                    r2s[0].extend(read_converter(r2))
            elif bc in bcs_chip:
                bc_counts[KEYWORD_UNSELECT] += 1
                if und_fq is True:
                    u1s.extend(read_converter(r1))
                    u2s.extend(read_converter(r2))
            elif bc == "short":
                bc_counts[KEYWORD_SHORT] += 1
            else:
                bc_counts[KEYWORD_UNDETERMINED] += 1
                if und_fq is True:
                    u1s.extend(read_converter(r1))
                    u2s.extend(read_converter(r2))

    return r1s, r2s, u1s, u2s, bc_counts


# ---------- fxn | extract barcode/umi from read ---------- #


def get_bc(
    read1,
    read2,
    experiment: Experiment,
    bc_len,
    umi_len,
    hh1,
    hh2,
    idx,
    bcs_chip: Set[str],
    mismatch,
    rev1=False,
    rev2=False,
):
    # strip umi & bc sequence
    bc, umi = experiment.get_barcode(read1, read2, bc_len, umi_len)

    # -----
    # reverse complement if necessary
    # The 'bc_len' is assumed as a length of barcode excluding internal barcode of SCI-seq
    # It is normally i5+i7. Or, internal barcode of ICELL8 3DE/5DE.
    if bc != "short":
        # Split the bc by the length
        base_bc = bc[0:bc_len]
        extra_bc = bc[bc_len:]

        # Calculate reverse complement of base_bc
        if rev1 is True:
            if experiment.dual_index_barcode:
                base_bc = base_bc[0:idx] + reverse_complement(base_bc[idx:])
            else:
                base_bc = reverse_complement(base_bc)
        if rev2 is True:
            if experiment.dual_index_barcode:
                base_bc = reverse_complement(base_bc[0:idx]) + base_bc[idx:]
            else:
                base_bc = reverse_complement(base_bc)

        # Concatenate back to bc
        bc = base_bc + extra_bc

    # check if exists | turn bcs_chip to hash for performance?
    if mismatch == 0 or bc in bcs_chip or bc == "short":
        pass
    else:
        if experiment.dual_index_barcode:
            h1 = ham_check(hh1, bc[0:idx])
            if len(h1) > 0:
                h2 = ham_check(hh2, bc[idx:])
                if len(h2) > 0:
                    bc = h1 + h2
        else:
            h1 = ham_check(hh1, bc)
            if len(h1) > 0:
                bc = h1

    return bc, umi


# ---------- fxns | handle barcode mismatch | generate hash of bcs with hamming distance <= 1 ---------- #


def ham_denovo(bc_map, idx):
    if idx > 0:
        hh1 = ham_hash(bc_list=list(OrderedSet([x[0:idx] for x in bc_map])))
        hh2 = ham_hash(bc_list=list(OrderedSet([x[idx:] for x in bc_map])))
    else:
        hh1 = ham_hash(bc_list=bc_map)
        hh2 = None
    return (hh1, hh2)


def ham_substr(txt, idx=0, rep=""):
    return "%s%s%s" % (txt[:idx], rep, txt[idx + 1 :])  # noqa: E203


DNA_COMPLEMENT_MAP = str.maketrans("ACTGactg", "TGACtgac")


def reverse_complement(dna_sequence: str) -> str:
    """Return the reverse complement of a DNA sequence."""
    valid_bases = "ACTGNactgn"
    if not set(dna_sequence) <= set(valid_bases):
        raise ValueError(
            f"DNA sequence '{dna_sequence}' contains unexpected characters. Valid bases are '{valid_bases}'."
        )
    if dna_sequence == "":
        raise ValueError("DNA sequence is empty.")
    return dna_sequence.translate(DNA_COMPLEMENT_MAP)[::-1]


def ham_check(hh, bc):
    try:
        return hh[bc]
    except KeyError:
        return ""


def ham_hash(bc_list=None, ham_map=None, nuc=None, rev=False, idx=0):
    if ham_map is None and bc_list is None:
        return None
    if nuc is None:
        nuc = ["A", "C", "T", "G", "N"]
    hh = {}
    if ham_map is None:
        drop = []
        if rev is True:
            bc_list = [x[0:idx] + reverse_complement(x[idx:]) for x in bc_list]  # type: ignore
        for bc in bc_list:  # type: ignore
            for i in range(0, len(bc)):
                for n in nuc:
                    p = ham_substr(bc, i, n)
                    if p in hh:
                        drop.append(p)
                    else:
                        hh[p] = bc
        drop = list(OrderedSet(drop))
        for p in drop:
            if p in hh and p not in bc_list:
                del hh[p]
    else:
        with open(ham_map) as f:
            for line in f:
                (p, bc) = re.split(r",+", line.rstrip(",\n"))
                if rev is True:
                    p = p[0:idx] + reverse_complement(p[idx:])
                    bc = bc[0:idx] + reverse_complement(bc[idx:])
                hh[p] = bc
    return hh


def ham_calc_dist(bc1, bc2):
    if not len(bc1) == len(bc2):
        return len(bc1)
    else:
        return sum(b1 != b2 for b1, b2 in zip(bc1, bc2))


# ---------- fxn | generate fastq barcode file name ---------- #


def fq_bcf(
    out_dir,
    out_prefix,
    gzip: bool,
    ext,
    r=None,
    bc=None,
    sh=None,
    n=None,
) -> str:
    if gzip is True:
        ext += ".gz"

    if r is None and bc is None:
        bcf = os.path.join(out_dir, "_".join([out_prefix, ext]))
    else:
        if r is not None and bc is None:
            bc = r.split("_")[1].split(" ")[0]
        bc_fq = bc
        if sh is not None:
            s = sh[bc]
            if not s == "":
                bc_fq = "_".join([s, bc])  # type: ignore
        if n is not None:
            bc_fq = "_".join([bc_fq, str(n)])  # type: ignore
        bcf = os.path.join(out_dir, "_".join([bc_fq, ext]))  # type: ignore
    return bcf


# ---------- fxn | write barcode counts file ---------- #


def write_bc_cts(bc_sum_cts: Dict[str, int], bcs, sh, out_dir, out_prefix):
    with open(os.path.join(out_dir, "demux_counts_all.csv"), "w", newline="") as f:
        w = csv.writer(f, delimiter=",")

        for bc, count in bc_sum_cts.items():
            if bc in [KEYWORD_SHORT, KEYWORD_UNSELECT, KEYWORD_UNDETERMINED]:
                continue

            w.writerow([bc, str(sh[bc]), str(count)])

        w.writerow([KEYWORD_SHORT, "Non_sample", str(bc_sum_cts[KEYWORD_SHORT])])
        w.writerow([KEYWORD_UNSELECT, "Non_sample", str(bc_sum_cts[KEYWORD_UNSELECT])])
        w.writerow(
            [KEYWORD_UNDETERMINED, "Non_sample", str(bc_sum_cts[KEYWORD_UNDETERMINED])]
        )


# -------------------- #


def set_chunk(s: Set[str], n: int) -> List[Set[str]]:
    num_in_chunk = [int(len(s) / n)] * n
    idx = [
        num_in_chunk[i] + 1 if i < len(s) % n else num_in_chunk[i]
        for i in range(len(num_in_chunk))
    ]
    out = []
    c = 0
    for i in idx:
        split = set(itertools.islice(s, c, c + i))
        c = c + i
        out.append(split)

    return out


# ---------- fxn | string to boolean ---------- #


def strbool(s):
    if s.lower() in ["true", "t"]:
        return True
    elif s.lower() in ["false", "f"]:
        return False
    else:
        return s


# ---------- fxn | compression ---------- #
def pigz(outfiles, n, compression_level, pigz: str) -> bool:
    for f in outfiles:
        command = [pigz, "-" + str(compression_level), "-p", str(n), str(f)]
        c = subprocess.run(command)
        if c.returncode != 0:
            Logger.error_both("Issue compressing output FASTQ files.")
            return False

    return True


def pigz_multi(
    outfiles: List[str],
    n_process: int,
    compression_level: int,
    pigz: str,
    pigz_n_cores: int,
) -> bool:
    num_pool = n_process // pigz_n_cores  # Calculate pool number
    pool = Pool(processes=num_pool)  # Create a pool

    Logger.info_logger(f"Compression level = {compression_level}")
    Logger.info_logger(
        f"Number of pools = {num_pool}. Cores for each process = {pigz_n_cores}"
    )

    manager = Manager()
    res_list = manager.list()

    for file in outfiles:
        pool.apply_async(
            pigz_sub, args=(file, pigz_n_cores, compression_level, pigz, res_list)
        )

    pool.close()
    pool.join()

    if any([x != 0 for x in res_list]):  # When error in any process
        Logger.error_both("Issue compressing output FASTQ files.")
        return False

    return True


def pigz_sub(
    file: str, n_cores: int, compression_level: int, pigz: str, res_list: List[int]
):
    res = subprocess.run([pigz, "-" + str(compression_level), "-p", str(n_cores), file])
    res_list.append(res.returncode)


# ---------- fxn | check if file exists ---------- #
def check_file(f, exp) -> bool:
    if os.path.isfile(f) is False:
        Logger.error_both(f + " " + exp)
        return False
    else:
        return True


# ---------- fxn | check all input requirements ---------- #
def check_requirements(
    user_args, barcode_reader: BarcodeReader, experiment: Experiment
) -> bool:
    res = True

    if (
        experiment.read_mode == ReadMode.PAIRED
        or experiment.read_mode == ReadMode.READ2  # noqa: W503
    ):
        if user_args.r2_file is None:
            Logger.error_both("Read2 is necessary for the experiment type.")
            return False
    elif experiment.read_mode == ReadMode.READ1:
        if user_args.r2_file is None:
            user_args.r2_file = user_args.r1_file  # Re-use r1 file as r2
        else:
            Logger.warning_logger(
                f'R2 file is specified for "{experiment.name}", but it will be ignored.'
            )
    else:
        Logger.error_both("Unrecognized read mode.")
        return False

    # Check if files exist
    for f in [user_args.r1_file, user_args.r2_file, user_args.bcs_file]:
        res = check_file(f, "does not exist!") and res

    # Check if background file exist
    if user_args.background_barcodes_file is not None:
        res = check_file(user_args.background_barcodes_file, "does not exist!") and res

    if not res:
        return False

    if (
        barcode_reader.judge_file_type(suppress_warning=True)
        is BarcodeFileType.NOT_DETECTED
    ):
        Logger.error_both("Unrecognized barcode file format")
        res = False

    # Check user input barcode files
    if user_args.barcode_maps is not None:
        # Check file exists
        for f in user_args.barcode_maps:
            if not path.isfile(f):
                res = check_file(f, "does not exist!") and res

        if not res:
            return False

        # Check file format
        for f in user_args.barcode_maps:
            map_reader = BarcodeMapReader(f)
            if not map_reader.is_formatted():
                Logger.error_both(
                    f"Unrecognized format of user input barcode map file: {f}."
                )
                res = False

    return res


def check_pigz_install(user_args, repository_path: str) -> Union[str, None]:
    pigz_locs = [
        user_args.pigz_loc,
        os.path.join(repository_path, "_".join([REPO_NAME, "tools"]), "bin", "pigz"),
        str(shutil.which("pigz")),
    ]

    # Check if pigz is installed
    pigz_loc = None
    for pl in pigz_locs:
        if os.path.isfile(pl) is True:
            pigz_loc = pl
            break

    if pigz_loc is None:
        Logger.error_both("Can't find pigz executable.")

    return pigz_loc


# -----------------------------------------------------------------------------
# region : Main Function
def run(
    user_args,
    experiment: Experiment,
    first_log: str,
    repo_path: str,
) -> bool:
    # ---------- setup | output directory ---------- #
    # if os.path.isdir(user_args.out_dir):
    #    print(
    #        f"Error: Analysis dir already exists: {user_args.out_dir}", file=sys.stderr
    #    )
    #    return False
    # else:
    try:
        os.makedirs(user_args.out_dir, exist_ok=True)
    except OSError:
        print(
            f"Error: Unable to create directory: {user_args.out_dir}",
            file=sys.stderr,
        )
        return False

    if user_args.out_dir.endswith("/"):
        user_args.out_dir = user_args.out_dir.rstrip("/")

    user_args.out_prefix = os.path.split(user_args.out_dir)[1]

    # ---------- setup | logger ---------- #
    Logger.initialize(
        SCRIPT_NAME,
        path.join(user_args.out_dir, f"demux_{SCRIPT_NAME}.log"),
    )
    Logger.info_logger(first_log)
    Logger.info_logger("Command name: " + SCRIPT_NAME)
    Logger.info_logger("Original call: " + " ".join(sys.argv))

    if user_args.hpc_mode:
        Logger.info_logger("Start working as hpc mode.")

    # ---------- setup | check input ---------- #
    barcode_reader = BarcodeReader(user_args.bcs_file)
    if not check_requirements(user_args, barcode_reader, experiment):
        return False

    # ---------- setup | check pigz install ---------- #
    pigz_loc = check_pigz_install(user_args, repo_path)
    if pigz_loc is None:
        return False

    # ---------- setup | read buffer ---------- #
    user_args.read_buffer = set_read_buffer(user_args.read_buffer)

    # ---------- setup | UMI length ---------- #
    effective_umi_length = experiment.umi_length
    if user_args.umi_len is not None:
        if experiment.umi_length is None:
            Logger.info_logger(
                f"UMI length is specified by option. But it is ignored for the experiment type: {experiment.name}"
            )
        else:
            effective_umi_length = user_args.umi_len

    if experiment.is_use_umi:
        Logger.info_logger(f"Effective UMI length is defined as {effective_umi_length}")

    # ---------- setup | z_type ---------- #
    # Internal use only
    if user_args.z_type is None:
        pass
    else:
        user_args.type_exp = user_args.z_type
        if user_args.type_exp not in ["solo_umi", "strnd_umi"]:
            Logger.error_both("Unrecognized z_type")
            return False

    # ---------- setup | multiprocess ---------- #
    available_processes = multiprocessing.cpu_count()
    n_processes = user_args.n_processes
    n_writers = user_args.n_writers
    # n_workers will be determined
    if available_processes < 3:
        Logger.error_both("Insufficient CPU cores.")
        return False
    if n_processes > available_processes:
        Logger.info_logger(
            f"Requested number of processes exceeds available CPUs. Resetting n_processes to {available_processes}"
        )
        n_processes = available_processes
    if n_writers > n_processes - 2:
        Logger.info_logger(
            f"Requested number of writers cannot exceed n_processes - 2. Resetting n_writers to {n_processes - 2}"
        )
        n_writers = n_processes - 2
    n_workers = n_processes - n_writers - 1
    if user_args.split_fastq is False:
        if user_args.und_fq is True and n_writers > 4:
            Logger.info_logger(
                "Based on settings only 4 writer processes required. Re-allocating extra processes to workers."
            )
            n_workers += n_writers - 4
            n_writers = 4
        if user_args.und_fq is False and n_writers > 2:
            Logger.info_logger(
                "Based on settings only 2 writer processes required. Re-allocating extra processes to workers."
            )
            n_workers += n_writers - 2
            n_writers = 2

    Logger.info_logger(
        str(multiprocessing.cpu_count())
        + " total cores detected | 1 (reading) | "  # noqa: W503
        + str(n_workers)  # noqa: W503
        + " (workers) | "  # noqa: W503
        + str(n_writers)  # noqa: W503
        + " (writing)"  # noqa: W503
    )

    # -----
    # Start processing
    try:
        # ---------- load | selected barcodes ---------- #
        if not barcode_reader.read():
            return False

        Logger.info_logger("Loaded input well-list / barcodes file")

        # ---------- load | extend barcodes if necessary (for SCI-seq) ---------- #
        Logger.info_logger("Check extending barcode list.")
        res = experiment.extend_barcode_list(barcode_reader, user_args.barcode_maps)
        if not res:
            return False

        Logger.info_both(
            "Final number of loaded barcodes: " + str(len(barcode_reader.barcode_set))
        )

        # ---------- check | i5/i7 for reverse complement ---------- #
        rev1, rev2 = check_rc(
            bcs=barcode_reader.barcode_set,
            idx=barcode_reader.separator_pos,
            experiment=experiment,
            r1_file=user_args.r1_file,
            r2_file=user_args.r2_file,
            umi_len=effective_umi_length,
            depth=10000,
            i5_rc=user_args.i5_rc,
            i7_rc=user_args.i7_rc,
            base_bc_len=barcode_reader.original_bc_len,
        )

        # ---------- load | background barcodes & hamming distance hashes ---------- #
        bcs_chip, idx_chip, hh1, hh2 = load_bg(
            barcode_reader.barcode_set,
            barcode_reader.separator_pos,
            experiment,
            repo_path,
            user_args.background_barcodes_file,
        )

        # ---------- Select barcodes to be processed ------------
        target_bcs = barcode_reader.barcode_set  # Set as all barcode to initialize
        selector = BarcodeSelector(
            user_args.use_bcs_num,
            user_args.check_reads_num,
            user_args.minimum_reads,
            experiment,
            effective_umi_length,
            hh1,
            hh2,
            barcode_reader.separator_pos,
            bcs_chip,
            user_args.mismatch,  # type: ignore
            barcode_reader.sample_hash,
            user_args.out_dir,
            user_args.out_prefix,
            "seqtk",
            get_bc,
            rev1,
            rev2,
            barcode_reader.original_bc_len,  # type: ignore
        )

        target_bcs = selector.select_barcodes(
            user_args.r1_file,
            user_args.r2_file,
            barcode_reader.barcode_set,
            user_args.rand_pick,
            user_args.dry_run,
        )

        if user_args.dry_run:
            Logger.info_logger("Finish command due to dry run.")
            return True

        if len(target_bcs) == 0:
            Logger.warning_both("No barcode was retained after selection.")
            return False

        # ---------- demultiplex | launch demux_sub thread(s) ---------- #
        Logger.info_logger("Start demultiplexing.")
        demux_main(
            r1_file=user_args.r1_file,
            r2_file=user_args.r2_file,
            bcs=target_bcs,
            bcs_chip=bcs_chip,
            experiment=experiment,
            mismatch=user_args.mismatch,
            split_fastq=user_args.split_fastq,
            umi_len=effective_umi_length,
            und_fq=user_args.und_fq,
            sh=barcode_reader.sample_hash,
            hh1=hh1,
            hh2=hh2,
            idx=barcode_reader.separator_pos,
            rev1=rev1,
            rev2=rev2,
            read_buffer=user_args.read_buffer,
            out_dir=user_args.out_dir,
            out_prefix=user_args.out_prefix,
            n_workers=n_workers,
            n_writers=n_writers,
            r1_keep=(
                experiment.read_mode == ReadMode.PAIRED
                or experiment.read_mode == ReadMode.READ1  # noqa: W503
            ),
            gzip=user_args.gzip,
            prog=user_args.prog,
            debug=user_args.debug,
            hpc_mode=user_args.hpc_mode,
            base_bc_len=barcode_reader.original_bc_len,
        )
        Logger.info_logger("Successfully completed demultiplexing.")

    except CogentError as e:
        if e.function is None:
            Logger.error_both(f"{e.message}")
        else:
            Logger.error_both(f"{e.message} (at {e.function})")

        return False

    return True


# endregion
# -----------------------------------------------------------------------------
