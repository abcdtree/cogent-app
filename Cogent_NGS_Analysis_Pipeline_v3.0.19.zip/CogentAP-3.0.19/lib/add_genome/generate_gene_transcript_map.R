########## Load Libraries ############################
message('Loading Libraries..')
library(dplyr)
library(reshape2)
library(optparse)
library(rtracklayer)
library(GenomicRanges)
######################################################

################# Set Arguments to be passed ############
message('Reaading Users arguments..')
option_list = list(
	make_option("--gtf", type="character", default=NULL, help="gtf with introns plus exons (hg38.final.withintrons.gtf)", metavar="character"),
  	make_option("--outPath", type="character", default=NULL, help="Path to folder to write gene-transcript Map", metavar="character"),
  	make_option("--outFile", type="character", default="gene_transcript_Map.txt", help="Gene-Transcript_Map for Gene Level Counts", metavar="character")
);  
opt_parser = OptionParser(option_list=option_list);
opt = parse_args(opt_parser);
#######################################################

####### check required files ######
if(is.null(opt$gtf)) {
	print_help(opt_parser)
  	stop("GTF is required")
}

if(is.null(opt$outPath)) {
	print_help(opt_parser)
  	stop("Path to file dest. is required")
}
#######################################

####### execution ############
message('Importing GTF')
gtf = rtracklayer::import(opt$gtf)
gtf = data.frame(gtf)
gtf_subset = gtf %>% dplyr::filter(type == "transcript")
gtf_subset_df = gtf_subset %>% dplyr::select(transcript_id, gene_id)
rownames(gtf_subset_df) = gtf_subset_df$transcript_id
message('Gene-Transcript map is ready!')
outfile = paste0(opt$outPath, "/", opt$outFile)
write.table(gtf_subset_df, outfile, quote = F, sep = "\t")
message('done!')
##############################