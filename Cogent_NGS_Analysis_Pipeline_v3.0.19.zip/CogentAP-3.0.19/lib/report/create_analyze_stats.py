#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to generate summary files and report from Cogent Analyze outputs
#
# -----------------------------------------------------------------------------
import argparse
import os
import re
from collections import defaultdict
import sys
import glob
import json
import pandas as pd
from pathlib import Path

DESCRIPTION = (
    """Generate summary matrix files and reports from Cogent Analyze outputs."""
)

###
# Script information
###

# script info
SCRIPT_NAME = "create_analyze_stats.py"
VERSION = "3.0.19"

###
# Parse and define arguments
###


def _parse_command_line_args(sys_argv):
    """Takes in command line parameters and parses them for use

    Args:
        sys_argv: command line input

    Returns:
        args (list) : input argument values
    """
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    required = parser.add_argument_group("required arguments")

    required.add_argument(
        "-i",
        "--input_dir",
        dest="input_dir",
        help="Full path to directory containing all the relevant logs.",
        required=True,
    )

    required.add_argument(
        "-n",
        "--num_gene_reads",
        dest="num_gene_reads",
        default=1.0,
        help="Minimum number of reads required to count a gene for a sample.",
        required=True,
    )

    required.add_argument(
        "-t",
        "--type_of_experiment",
        dest="type_of_exp",
        help="Experiment type",
        required=True,
    )

    args, unknown = parser.parse_known_args(sys_argv)
    return args


def get_barcode(sample_name, index_1, index_2):
    if re.match(r"(.*)[ACGTN]{12,16}(.*)", sample_name):
        if re.match(r".*_L00\d(_trimmed)?$", sample_name):
            curr_barcode = sample_name.split("_")[index_1]
        else:
            curr_barcode = sample_name.split("_")[index_2]
    else:
        curr_barcode = sample_name.replace("_trimmed", "")
    return curr_barcode


# ---------- main ---------- #
def main(sys_argv):
    args = _parse_command_line_args(sys_argv)

    master_dir = args.input_dir
    min_gene_count = args.num_gene_reads
    exp_type = args.type_of_exp

    stats_dict = defaultdict(dict)

    # parse through cutadapt logs
    cutadapt_log_files = os.path.join(master_dir, "*.cutadapt.json")

    cutadapt_log_list = glob.glob(cutadapt_log_files, recursive=True)

    for cutadapt_log in cutadapt_log_list:

        sample_name = cutadapt_log.split("/")[-1].replace(".cutadapt.json", "")
        if re.match(r"(.*)[ACGTN]{12,16}(.*)", sample_name):
            if re.match(r".*_L00\d(_trimmed)?$", sample_name):
                curr_barcode = sample_name.split("_")[-2]
            else:
                curr_barcode = sample_name.split("_")[-1]

            sample = sample_name.replace("_" + curr_barcode, "")
            stats_dict[curr_barcode]["Barcode"] = curr_barcode
        else:
            curr_barcode = sample_name
            sample = sample_name
            stats_dict[curr_barcode]["Barcode"] = "NA"

        with open(cutadapt_log) as c_log:

            data = json.load(c_log)

            stats_dict[curr_barcode]["Sample"] = sample
            stats_dict[curr_barcode]["Barcoded_Reads"] = data["read_counts"]["input"]
            stats_dict[curr_barcode]["Trimmed_Reads"] = data["read_counts"]["output"]

    # parse through star logs
    star_log_files = os.path.join(master_dir, "*_Log.final.out")

    if glob.glob(star_log_files, recursive=True):
        star_log_list = glob.glob(star_log_files, recursive=True)

        for star_log in star_log_list:

            sample_name = star_log.split("/")[-1].replace("_Log.final.out", "")
            curr_barcode = get_barcode(sample_name, -3, -2)

            unmapped_count = 0
            multimapped_count = 0
            with open(star_log) as log_file:
                for line in log_file:
                    if "Uniquely mapped reads number" in line:
                        line = line.strip()
                        stats_dict[curr_barcode]["Uniquely_Mapped_Reads"] = int(
                            line.split("\t")[-1]
                        )
                    if "Number of reads mapped to multiple loci" in line:
                        line = line.strip()
                        multimapped_count += int(line.split("\t")[-1])
                    if "Number of reads unmapped:" in line:
                        line = line.strip()
                        unmapped_count += int(line.split("\t")[-1])
                    if "Number of reads mapped to too many loci" in line:
                        line = line.strip()
                        multimapped_count += int(line.split("\t")[-1])
                    if "Number of chimeric reads" in line:
                        line = line.strip()
                        stats_dict[curr_barcode]["Chimeric_Reads"] = int(
                            line.split("\t")[-1]
                        )

            stats_dict[curr_barcode]["Unmapped_Reads"] = unmapped_count
            stats_dict[curr_barcode]["Multimapped_Reads"] = multimapped_count
            stats_dict[curr_barcode]["Mapped_Reads"] = (
                stats_dict[curr_barcode]["Uniquely_Mapped_Reads"]
                + stats_dict[curr_barcode]["Multimapped_Reads"]
            )
    # parse through reads per gene files from star
    rev_exp_list = [
        "stranded",
        "stranded_umi",
        "shasta_total_rna",
    ]

    unstranded_exp_list = [
        "smartseq_fla",
        "smartseq_fla_umi",
        "icell8_fla",
        "smartseq_pro",
    ]

    if exp_type in rev_exp_list:
        reads_per_gene = os.path.join(master_dir, "*ReadsPerGene.out.tab")

        if glob.glob(reads_per_gene, recursive=True):
            reads_file_list = glob.glob(reads_per_gene, recursive=True)

            for reads_file in reads_file_list:

                sample_name = reads_file.split("/")[-1].replace(
                    "_ReadsPerGene.out.tab", ""
                )
                curr_barcode = get_barcode(sample_name, -3, -2)

                fwd_count = 0
                rev_count = 0
                unstranded_count = 0

                with open(reads_file) as reads_log:
                    for _ in range(4):
                        next(reads_log)
                    for line in reads_log:
                        unstranded_count += int(line.split("\t")[1])
                        fwd_count += int(line.split("\t")[2])
                        rev_count += int(line.split("\t")[3])

                # take average of the counts - see here: https://groups.google.com/g/rna-star/c/gZRJx3ElRNo
                stats_dict[curr_barcode]["Strand_Specificity"] = round(
                    rev_count / ((rev_count + fwd_count + unstranded_count) / 2), 3
                )

                if stats_dict[curr_barcode]["Strand_Specificity"] > 1.0:
                    stats_dict[curr_barcode]["Strand_Specificity"] = 1.0

                header = [
                    "Barcode",
                    "Sample",
                    "Barcoded_Reads",
                    "Trimmed_Reads",
                    "Unmapped_Reads",
                    "Mapped_Reads",
                    "Uniquely_Mapped_Reads",
                    "Multimapped_Reads",
                    "Chimeric_Reads",
                    "Exon_Reads",
                    "Intron_Reads",
                    "Gene_Reads",
                    "Intergenic_Reads",
                    "No_of_Genes",
                    "No_of_Transcripts",
                    "Ribosomal_Reads",
                    "Mitochondrial_Reads",
                    "Strand_Specificity",
                ]

                if exp_type == "stranded_umi":
                    header = [
                        "Barcode",
                        "Sample",
                        "Barcoded_Reads",
                        "Trimmed_Reads",
                        "Unmapped_Reads",
                        "Mapped_Reads",
                        "Uniquely_Mapped_Reads",
                        "Multimapped_Reads",
                        "Chimeric_Reads",
                        "No_of_Reads_w_UMIs",
                        "Reads_After_Dedup_nUMIs_USSs",
                        "Exon_nUMIs_USSs",
                        "Intron_nUMIs_USSs",
                        "Gene_nUMIs_USSs",
                        "Intergenic_Reads",
                        "No_of_Genes_nUMIs_USSs",
                        "No_of_Transcripts_nUMIs_USSs",
                        "Ribosomal_Reads",
                        "Mitochondrial_Reads",
                        "Strand_Specificity",
                    ]

    elif exp_type in unstranded_exp_list:
        header = [
            "Barcode",
            "Sample",
            "Barcoded_Reads",
            "Trimmed_Reads",
            "Unmapped_Reads",
            "Mapped_Reads",
            "Uniquely_Mapped_Reads",
            "Multimapped_Reads",
            "Chimeric_Reads",
            "Exon_Reads",
            "Intron_Reads",
            "Gene_Reads",
            "Intergenic_Reads",
            "No_of_Genes",
            "No_of_Transcripts",
            "Ribosomal_Reads",
            "Mitochondrial_Reads",
        ]

    # parse through sortmerna logs
    sortmerna_log_files = os.path.join(master_dir, "*.sortmerna.log")

    if glob.glob(sortmerna_log_files, recursive=True):
        sortmerna_log_list = glob.glob(sortmerna_log_files, recursive=True)

        for sortmerna_log in sortmerna_log_list:

            sample_name = sortmerna_log.split("/")[-1].replace(".sortmerna.log", "")
            curr_barcode = get_barcode(sample_name, -3, -2)

            with open(sortmerna_log) as s_log:
                for line in s_log:
                    if "Total reads passing E-value" in line:
                        stats_dict[curr_barcode]["Ribosomal_Reads"] = int(
                            int(line.split(" ")[-2]) / 2
                        )

    else:
        for barcode in stats_dict:
            stats_dict[barcode]["Ribosomal_Reads"] = "NA"

    # read in mitochondrial gene files
    mito_genes_file = glob.glob(os.path.join(master_dir, "*_mito_genes.txt"))
    mito_genes = pd.read_csv(mito_genes_file[0], header=None)[0].tolist()

    # parse through genematrix
    try:
        gene_matrix_file = glob.glob(
            os.path.join(master_dir, "analyze_gene_matrix.csv")
        )
        gene_matrix = pd.read_csv(gene_matrix_file[0], sep=",")

        barcodes_list = gene_matrix.columns.tolist()
        del barcodes_list[0]

        for barcode in barcodes_list:
            temp_df = gene_matrix[["GeneID", barcode]]
            gene_list = temp_df["GeneID"].str.split("\\.").str[0].tolist()
            stats_dict[barcode]["Exon_Reads"] = round(sum(temp_df[barcode]))
            mito_subset = set(gene_list).intersection(mito_genes)
            mito_indices = [gene_list.index(x) for x in mito_subset]
            stats_dict[barcode]["Mitochondrial_Reads"] = round(
                sum(temp_df.loc[mito_indices, barcode])
            )

            stats_dict[barcode]["No_of_Genes"] = len(
                temp_df.loc[temp_df[barcode] >= float(min_gene_count)]
            )

        del gene_matrix

    except IOError:
        print("Genematrix file does not exist.")
        sys.exit(1)

    # parse through intron matrix
    intron_matrix_files = os.path.join(
        master_dir, "analyze_incl_introns_genematrix.csv"
    )

    if glob.glob(intron_matrix_files, recursive=True):
        intron_matrix_file = glob.glob(intron_matrix_files, recursive=True)

        intron_matrix = pd.read_csv(intron_matrix_file[0], sep=",")

        barcodes_list = intron_matrix.columns.tolist()
        del barcodes_list[0]

        for barcode in barcodes_list:
            temp_df = intron_matrix[["GeneID", barcode]]
            stats_dict[barcode]["Gene_Reads"] = round(sum(temp_df[barcode]))
            stats_dict[barcode]["Intron_Reads"] = (
                stats_dict[barcode]["Gene_Reads"] - stats_dict[barcode]["Exon_Reads"]
            )
            stats_dict[barcode]["Intergenic_Reads"] = (
                stats_dict[barcode]["Mapped_Reads"] - stats_dict[barcode]["Gene_Reads"]
            )
        del intron_matrix

    else:
        for barcode in stats_dict:
            stats_dict[barcode]["Intron_Reads"] = "NA"
            stats_dict[barcode]["Gene_Reads"] = "NA"

    try:
        transcript_matrix_file = glob.glob(
            os.path.join(master_dir, "*transcript*matrix.csv")
        )
        transcript_matrix = pd.read_csv(transcript_matrix_file[0], sep=",")

        barcodes_list = transcript_matrix.columns.tolist()
        del barcodes_list[0]

        for barcode in barcodes_list:
            temp_df = transcript_matrix[["TranscriptID", barcode]]
            # stats_dict[barcode]["Exon_Reads"] = round(sum(temp_df[barcode]))
            stats_dict[barcode]["No_of_Transcripts"] = len(
                temp_df.loc[temp_df[barcode] >= float(min_gene_count)]
            )

        del transcript_matrix

    except IOError:
        print("Transcript matrix file does not exist.")
        sys.exit(1)

    # parse umitools log
    if exp_type == "smartseq_fla_umi" or exp_type == "stranded_umi":
        umitools_log_files = os.path.join(master_dir, "*umitools.log")
        read_count = ""
        if glob.glob(umitools_log_files, recursive=True):

            umitools_log_list = glob.glob(umitools_log_files, recursive=True)
            for umitools_log in umitools_log_list:

                sample_name = umitools_log.split("/")[-1].replace("_umitools.log", "")
                curr_barcode = get_barcode(sample_name, -3, -2)

                with open(umitools_log) as u_log:
                    for line in u_log:
                        if "Number of reads out:" in line:
                            stats_dict[curr_barcode]["Reads_After_Dedup_nUMIs_USSs"] = (
                                int(line.split(" ")[-1])
                            )
                        if "INFO Reads: Input Reads:" in line:
                            if exp_type == "stranded_umi":
                                read_count = line.split(" ")[6]
                                stats_dict[curr_barcode]["No_of_Reads_w_UMIs"] = int(
                                    read_count.replace(",", "")
                                )
                            else:
                                read_count = line.split(" ")[-1]
                                stats_dict[curr_barcode]["No_of_Reads_w_UMIs"] = int(
                                    read_count
                                )

    # special case for smartseq_fla_umi kits, needs additional stats file with umis alone
    if exp_type == "smartseq_fla_umi":
        # parse through genematrix
        try:
            gene_matrix_file = glob.glob(
                os.path.join(master_dir, "analyze_gene_matrix_umis.csv")
            )
            gene_matrix = pd.read_csv(gene_matrix_file[0], sep=",")

            barcodes_list = gene_matrix.columns.tolist()
            del barcodes_list[0]

            for barcode in barcodes_list:
                temp_df = gene_matrix[["GeneID", barcode]]
                gene_list = temp_df["GeneID"].str.split("\\.").str[0].tolist()
                stats_dict[barcode]["Exon_nUMIs_USSs"] = round(sum(temp_df[barcode]))

                stats_dict[barcode]["No_of_Genes_nUMIs_USSs"] = len(
                    temp_df.loc[temp_df[barcode] >= float(min_gene_count)]
                )

            del gene_matrix

        except IOError:
            print("Genematrix with UMIs file does not exist.")
            sys.exit(1)

        # parse through intron matrix
        intron_matrix_files = os.path.join(
            master_dir, "analyze_incl_introns_genematrix_umis.csv"
        )

        if glob.glob(intron_matrix_files, recursive=True):
            intron_matrix_file = glob.glob(intron_matrix_files, recursive=True)

            intron_matrix = pd.read_csv(intron_matrix_file[0], sep=",")

            barcodes_list = intron_matrix.columns.tolist()
            del barcodes_list[0]

            for barcode in barcodes_list:
                temp_df = intron_matrix[["GeneID", barcode]]
                stats_dict[barcode]["Gene_nUMIs_USSs"] = round(sum(temp_df[barcode]))
                stats_dict[barcode]["Intron_nUMIs_USSs"] = (
                    stats_dict[barcode]["Gene_nUMIs_USSs"]
                    - stats_dict[barcode]["Exon_nUMIs_USSs"]
                )
            del intron_matrix

        else:
            for barcode in stats_dict:
                stats_dict[barcode]["Intron_nUMIs_USSs"] = "NA"
                stats_dict[barcode]["Gene_nUMIs_USSs"] = "NA"

        try:
            transcript_matrix_file = glob.glob(
                os.path.join(master_dir, "*transcript*matrix_umis.csv")
            )
            transcript_matrix = pd.read_csv(transcript_matrix_file[0], sep=",")

            barcodes_list = transcript_matrix.columns.tolist()
            del barcodes_list[0]

            for barcode in barcodes_list:
                temp_df = transcript_matrix[["TranscriptID", barcode]]
                stats_dict[barcode]["No_of_Transcripts_nUMIs_USSs"] = len(
                    temp_df.loc[temp_df[barcode] >= float(min_gene_count)]
                )

            del transcript_matrix

        except IOError:
            print("Transcript UMI matrix file does not exist.")
            sys.exit(1)

        umi_header = [
            "Barcode",
            "Sample",
            "Barcoded_Reads",
            "Trimmed_Reads",
            "Unmapped_Reads",
            "Mapped_Reads",
            "Uniquely_Mapped_Reads",
            "Multimapped_Reads",
            "Chimeric_Reads",
            "No_of_Reads_w_UMIs",
            "Reads_After_Dedup_nUMIs_USSs",
            "Exon_nUMIs_USSs",
            "Intron_nUMIs_USSs",
            "Gene_nUMIs_USSs",
            "Intergenic_Reads",
            "No_of_Genes_nUMIs_USSs",
            "No_of_Transcripts_nUMIs_USSs",
            "Ribosomal_Reads",
            "Mitochondrial_Reads",
        ]

        with open("analyze_stats_5pUMI_stats.csv", "a") as f:
            print(",".join(umi_header), file=f)
            for barcode in stats_dict:
                print(stats_dict[barcode]["Barcode"], end=",", file=f)
                print(stats_dict[barcode]["Sample"], end=",", file=f)
                print(stats_dict[barcode]["Barcoded_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Trimmed_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Unmapped_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Mapped_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Uniquely_Mapped_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Multimapped_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Chimeric_Reads"], end=",", file=f)
                print(stats_dict[barcode]["No_of_Reads_w_UMIs"], end=",", file=f)
                print(
                    stats_dict[barcode]["Reads_After_Dedup_nUMIs_USSs"], end=",", file=f
                )
                print(stats_dict[barcode]["Exon_nUMIs_USSs"], end=",", file=f)
                print(stats_dict[barcode]["Intron_nUMIs_USSs"], end=",", file=f)
                print(stats_dict[barcode]["Gene_nUMIs_USSs"], end=",", file=f)
                print(stats_dict[barcode]["Intergenic_Reads"], end=",", file=f)
                print(stats_dict[barcode]["No_of_Genes_nUMIs_USSs"], end=",", file=f)
                print(
                    stats_dict[barcode]["No_of_Transcripts_nUMIs_USSs"], end=",", file=f
                )
                print(stats_dict[barcode]["Ribosomal_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Mitochondrial_Reads"], end="\n", file=f)

    # write out the stats file

    output_file = "analyze_stats.csv"

    with open(output_file, "a") as f:
        print(",".join(header), file=f)
        for barcode in stats_dict:
            print(stats_dict[barcode]["Barcode"], end=",", file=f)
            print(stats_dict[barcode]["Sample"], end=",", file=f)
            print(stats_dict[barcode]["Barcoded_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Trimmed_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Unmapped_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Mapped_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Uniquely_Mapped_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Multimapped_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Chimeric_Reads"], end=",", file=f)
            if exp_type == "stranded_umi":
                print(stats_dict[barcode]["No_of_Reads_w_UMIs"], end=",", file=f)
                print(
                    stats_dict[barcode]["Reads_After_Dedup_nUMIs_USSs"], end=",", file=f
                )
            print(stats_dict[barcode]["Exon_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Intron_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Gene_Reads"], end=",", file=f)
            print(stats_dict[barcode]["Intergenic_Reads"], end=",", file=f)
            print(stats_dict[barcode]["No_of_Genes"], end=",", file=f)
            print(stats_dict[barcode]["No_of_Transcripts"], end=",", file=f)
            print(stats_dict[barcode]["Ribosomal_Reads"], end=",", file=f)

            if "Strand_Specificity" in header:
                print(stats_dict[barcode]["Mitochondrial_Reads"], end=",", file=f)
                print(stats_dict[barcode]["Strand_Specificity"], end="\n", file=f)
            else:
                print(stats_dict[barcode]["Mitochondrial_Reads"], end="\n", file=f)


if __name__ == "__main__":
    main(sys.argv[1:])
