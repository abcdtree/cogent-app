#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Functions to define arguments for all sub commands.
#

import argparse
from typing import List


# -----
# Global arguments
def prepare_cogent(parser):
    parser.add_argument(
        "-v",
        "--version",
        dest="show_version",
        action="store_true",
        help="Show version number",
        default=False,
    )


# -----
# For demux command
def prepare_demux(required, optional, experiment_names: List[str]):
    # add required arguments
    required.add_argument(
        "-i",
        "--input_fastq",
        dest="r1_file",
        help="Input Read1 (R1) FASTQ file.",
        required=True,
    )

    required.add_argument(
        "-b",
        "--barcodes_file",
        dest="bcs_file",
        help="Well List file from Takara's CellSelect Software (Recommended), or custom Barcodes "
        "File (see User Manual @ https://takarabiousa.github.io for details).",
        required=True,
    )

    required.add_argument(
        "-t",
        "--type_of_experiment",
        dest="type_exp",
        help="Experimental protocol used.",
        choices=experiment_names,
        required=True,
    )

    required.add_argument(
        "-o",
        "--output_dir",
        dest="out_dir",
        help="Name of output directory to store results.",
        required=True,
    )

    # add optional arguments
    required.add_argument(
        "-p",
        "--paired_fastq",
        dest="r2_file",
        help="Input Read2 (R2) FASTQ file.",
        default=None,
    )

    optional.add_argument(
        "--no_split_fastqs",
        dest="split_fastq",
        action="store_false",
        default=True,
        help="Output merged FASTQ file(s). Barcodes are written into read names and merged into large FASTQ file. By default output into barcode-level FASTQ files.",
    )

    optional.add_argument(
        "-m",
        "--mismatch",
        dest="mismatch",
        help="Number of allowed mismatched bases per barcode [Default: 1].",
        choices=[0, 1],
        default=1,
        type=int,
    )

    optional.add_argument(
        "-w",
        "--all_well_barcodes_file",
        dest="background_barcodes_file",
        help="Barcodes file used to calculate background contamination from unselected barcodes. "
        "This file is built-in for standard protocols (defined by option `-t`), but can be "
        "customized for rare cases where a custom chip or barcode set is used.",
        default=None,
    )

    optional.add_argument(
        "-u",
        "--umi_length",
        dest="umi_len",
        help="Overwrite UMI length. Default length is automatically detected by experiment type. [Default: None].",
        default=None,
        type=int,
    )

    optional.add_argument(
        "-n",
        "--n_processes",
        dest="n_processes",
        help="Number of demultiplexing processes to spawn during execution [Default: 15].",
        default=15,
        type=int,
    )

    optional.add_argument(
        "--n_writers",
        dest="n_writers",
        help="Number of writing processes to spawn during execution [Default: 8].",
        default=8,
        type=int,
    )

    optional.add_argument(
        "--no_gz",
        dest="gzip",
        action="store_false",
        default=True,
        help="Do not compress (gzip) output FASTQ files.",
    )

    optional.add_argument(
        "--undetermined_fq",
        dest="und_fq",
        action="store_true",
        default=False,
        help="Save Undetermined/Unselected/Short reads to Undetermined FASTQ files.",
    )

    optional.add_argument(
        "--i7_rc",
        dest="i7_rc",
        help='Reverse-complement I7 Index (Full Length protocol only). Enter "Auto" to detect and '
        "auto-correct the reverse complementation of I5/I7 indices by certain Illumina "
        'sequencers. Otherwise manually override with "True" or "False" [Default: "Auto"].',
        choices=["Auto", "True", "False"],
        default="Auto",
    )

    optional.add_argument(
        "--i5_rc",
        dest="i5_rc",
        help="See help section for `--i7_rc`.",
        choices=["Auto", "True", "False"],
        default="Auto",
    )

    optional.add_argument(
        "--read_buffer",
        dest="read_buffer",
        help="Buffer size of data sent to each demultiplexing (worker) process in GB [Default: 0.1].",
        default=0.1,
        type=float,
    )

    optional.add_argument(
        "--hpc",
        dest="hpc_mode",
        action="store_true",
        help="Work as high performance computing mode. To use this option, changing file descriptors (ulimit -n) as unlimited is recommended.",
        default=False,
    )

    optional.add_argument(
        "--prog",
        dest="prog",
        type=int,
        help="Number of reads to process before updating status in log file [Default 10,000,000].",
        default=10000000,
    )

    optional.add_argument(
        "-z",
        "--z_type_internal_use_only",
        dest="z_type",
        help=argparse.SUPPRESS,
        default=None,
    )

    optional.add_argument(
        "--debug",
        dest="debug",
        action="store_true",
        help=argparse.SUPPRESS,
        default=None,
    )

    optional.add_argument(
        "--pigz_loc", dest="pigz_loc", help=argparse.SUPPRESS, default=""
    )

    optional.add_argument(
        "--use_barcodes",
        dest="use_bcs_num",
        help="... [Default: 10000].",
        default=10000,
        type=int,
    )

    optional.add_argument(
        "--check_reads",
        dest="check_reads_num",
        help="... [Default: 10000000].",
        default=10000000,
        type=int,
    )

    optional.add_argument(
        "--min_reads",
        dest="minimum_reads",
        help="... [Default: 1000].",
        default=10000,
        type=int,
    )

    optional.add_argument(
        "--random_pick",
        dest="rand_pick",
        action="store_true",
        help="Use seqtk for random picking when selecting barcodes.",
        default=False,
    )

    optional.add_argument(
        "--dry_run",
        dest="dry_run",
        action="store_true",
        help="Output only estimated counts result of all barcodes.",
        default=False,
    )

    optional.add_argument(
        "--bcs_map",
        dest="barcode_maps",
        nargs="*",
        help="(Internal) barcodes map files.",
        default=None,
        type=str,
    )

    # For select_barcode command


def prepare_select_barcode(required, optional):
    # Add the required arguments
    required.add_argument(
        "-i",
        "--input",
        dest="input_dir",
        help="Directory contains results from demux command. The directory must contain FASTQ files after demultiplexing.",
        required=True,
    )

    required.add_argument(
        "-r",
        "--results",
        dest="results_dir",
        help="Folder name to create for storing results",
        required=True,
    )

    optional.add_argument(
        "-n",
        "--n_cores",
        dest="cores_num",
        help="Number of cores used during merging [Default: 8].",
        default=8,
        type=int,
    )
