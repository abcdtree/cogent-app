#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to handle original errors.
#

class CogentError(Exception):
	def __init__(self, message: str, function: str = None):
		self.message = message
		self.function = function

	def __str__(self):
		if self.function is None:
			return f'Error: {self.message}'
		else:
			return f'Error on {self.function}: {self.message}'