#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to specify ICELL8 Full length analysis
#
# Required:
# 	-

from os import path
from typing import Dict, List, Tuple, Union, cast, Set

from common.experiment.experiment import Experiment
from common.util.const import (
    AnalysisType,
    DebugMode,
    NormalizeMethod,
    ReadMode,
    StrandedMode,
    UssMode,
)
from demux.barcode_reader import BarcodeReader


class SMARTSeqFLAUMI(Experiment):
    # ---------------------------------
    # region : Constants
    UMI_READ_TAG = "ATTGCGCAATG"  # Tag for 5pUMI. This is appeared from start on read1.
    # endregion
    # ---------------------------------

    def __init__(self) -> None:
        super().__init__()

        self.__5pUMI_tag_map = []  # Initialize tag map to be loaded.

    # ---------------------------------
    # region: Property
    @property
    def name(self) -> str:
        return "smartseq_fla_umi"

    @property
    def read_mode(self) -> ReadMode:
        return ReadMode.PAIRED

    @property
    def check_revcomp(self) -> bool:
        return True

    @property
    def dual_index_barcode(self) -> bool:
        return True

    @property
    def umi_length(self) -> Union[int, None]:
        return 8

    @property
    def stranded_mode(self) -> StrandedMode:
        return StrandedMode.NONE

    @property
    def is_use_uss(self) -> bool:
        return False

    @property
    def uss_mode(self) -> UssMode:
        return UssMode.READ1

    @property
    def norm_method(self) -> NormalizeMethod:
        return NormalizeMethod.CPM

    @property
    def support_analysis(self) -> List[AnalysisType]:
        return [
            AnalysisType.GENE,
            AnalysisType.TRANSCRIPT,
            AnalysisType.FUSION,
            AnalysisType.IMMUNE,
        ]

    @property
    def main_result_prefix(self) -> Union[str, None]:
        return "_all"

    # @property
    # def cogent_ds_files(self) -> Union[Dict[str, Tuple[str, str]], None]:
    # 	return {
    # 		'all': ("_all_genematrix.csv", "_all_stats.csv"),
    # 		'5pUMI': ("_5pUMI_umi_genematrix.csv", "_5pUMI_stats.csv")
    # 		}

    # endregion: Property
    # ---------------------------------

    # ---------------------------------
    # region: Methods
    def initialize(self, config_dir: str):
        # Load tag map into this class
        with open(
            path.join(config_dir, "recognition_tag_map_5pUMI_with_N.csv"), "r"
        ) as f:
            self.__5pUMI_tag_map = [v.strip() for v in f.readlines()]

    def get_background_info(
        self, repository_path: str, input_bcs: Set[str], input_index_pos: int
    ) -> Tuple[Set[str], Union[str, None], Union[str, None], int]:
        return (
            input_bcs,
            None,
            None,
            input_index_pos,
        )  # No map file, calculate from denovo

    def extend_barcode_list(
        self, barcode_reader: BarcodeReader, user_map_files: Union[List[str], None]
    ) -> bool:
        return True  # Do nothing

    def get_barcode(
        self, read1, read2, barcode_length: int, umi_length: int
    ) -> Tuple[str, str]:
        # read1 should be passed
        barcode = "".join(
            filter(str.isalpha, read1.name.split()[1].split(":")[-1])
        )  # Fetch index1 and index 2 from read tag
        umi = None

        # Check if this read is originated from 5pUMI or Internal
        tag_length = len(self.UMI_READ_TAG)
        recognition_tag = read1.sequence[0:tag_length]

        # Pattern3: HD2 with N
        if recognition_tag in self.__5pUMI_tag_map:
            # 5pUMI reads
            umi = read1.sequence[
                tag_length : tag_length + umi_length
            ]  # Fetch bases following UMI tag
            if "N" in umi:  # Ignore this reads if UMI has N in it
                barcode = "short"
        else:
            # Internal reads
            # barcode = 'short'
            umi = "N" * umi_length  # Create all N umi as dummy

        # # Pattern1: Perfect Match
        # if recognition_tag == self.UMI_READ_TAG:
        # 	# 5pUMI
        # 	# barcode = 'short'
        # 	umi = read1.sequence[tag_length:tag_length+umi_length]		# Fetch bases following UMI tag
        # 	if 'N' in umi:
        # 		barcode = 'short'
        # else:
        # 	# Internal
        # 	# barcode = 'short'
        # 	umi = 'N' * umi_length									# Create all N umi as dummy

        # # Pattern2: HD2 without N
        # if 'N' in recognition_tag:
        # 	barcode = 'short'
        # 	umi = read1.sequence[tag_length:tag_length+umi_length]
        # elif recognition_tag in self.__5pUMI_tag_map:
        # 	# 5pUMI
        # 	# barcode = 'short'
        # 	umi = read1.sequence[tag_length:tag_length+umi_length]		# Fetch bases following UMI tag
        # 	if 'N' in umi:
        # 		barcode = 'short'
        # else:
        # 	# Internal
        # 	umi = 'N' * umi_length									# Create all N umi as dummy

        return (barcode, umi)

    def process_read_on_demux(
        self, read1, read2, barcode: str, barcode_length: int, umi: str
    ):
        tmp = read1.name.split()
        tmp[0] += "_" + barcode + "_" + umi
        read1.name = " ".join(tmp)

        tmp = read2.name.split()
        tmp[0] += "_" + barcode + "_" + umi
        read2.name = " ".join(tmp)

        # trim r1 to remove tag and umi from 5' end
        # further trim to remove 4base following UMI (removing GGGG)
        if read1.sequence.startswith(self.UMI_READ_TAG):
            cut_out_length = len(self.UMI_READ_TAG) + len(umi) + 4
            read1.sequence = read1.sequence[cut_out_length:]
            read1.qualities = read1.qualities[cut_out_length:]

    # endregion: Methods
    # ---------------------------------
