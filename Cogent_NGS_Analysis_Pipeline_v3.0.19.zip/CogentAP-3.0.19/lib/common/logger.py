#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Class to handle log messages to both std and files.
# This class assume to be used without instance.
# All work handled with class method and class values.
#
# 5/15/2020: This class keep compatibilty with previous version of logging method.
#            The function would be merged to new function in near future.
#

import logging
import sys
import codecs

from enum import Enum
from datetime import datetime

import traceback


# ----------
# Enumerations
class LogType(Enum):
	STD = 1
	LOGGER = 2
	BOTH = 3

class MessageType(Enum):
	NORMAL = 1
	ERROR = 2
	WARNING = 3

class Logger:
	"""
	Handle logging. It makes log flexible and easy.
	This class assume to be used without instance.
	All work handled with class method and class values.
	"""
	# --- constatns ---
	# LOG_FORMAT = '[%(asctime)s] %(levelname)s - %(name)s: %(message)s'
	LOG_FORMAT = '[%(asctime)s] %(levelname)s: %(message)s'
	LOG_FORMAT_ARG_DATE = "%Y-%m-%d %H:%M:%S"

	# --- internal variables (class variables) ---
	# __logger = None				# logger from logging
	# __stdout = {}
	# __stderr = {}

	__keep_names = set()
	__main_namespace = None
	__initialized = False

	# --- methods ---
	@classmethod
	def initialize(cls, log_name: str, log_file: str):
		"""Initializing method to create logger automatically. This method will be default in next version.

		Arguments:
			log_name {str} -- Namespace for log
			log_file {str} -- Output log file
		"""
		logger = logging.getLogger(log_name)
		logger.setLevel(logging.INFO)
		fh = logging.FileHandler(log_file, mode="w")

		formatter = logging.Formatter(cls.LOG_FORMAT, datefmt=cls.LOG_FORMAT_ARG_DATE)
		fh.setFormatter(formatter)
		logger.addHandler(fh)

		cls.__main_namespace = log_name			# keep main name
		cls.__keep_names.add(log_name)

		# initialize standard output/error
		cls.__stdout = {}
		cls.__stdout[log_name] = sys.stdout

		cls.__stderr = {}
		cls.__stderr[log_name] = sys.stderr

		cls.__initialized = True

	@classmethod
	def old_initialize(cls, logger):
		"""Initializing function to keep comatibility. This function will be deprecated.

		Arguments:
			logger {[type]} -- [description]
		"""
		cls.__logger = logger

		# # initialize standard output/error
		# cls.__stdout = sys.stdout
		# cls.__stderr = sys.stderr

	@classmethod
	def add_logger(cls, namespace: str, log_file: str):
		"""Add a logger with new name space

		Keyword Arguments:
			namespace {str} -- name space for a new logger
		"""

		logger = logging.getLogger(namespace)
		logger.setLevel(logging.INFO)
		fh = logging.FileHandler(log_file, mode="w")

		formatter = logging.Formatter(cls.LOG_FORMAT, datefmt=cls.LOG_FORMAT_ARG_DATE)
		fh.setFormatter(formatter)
		logger.addHandler(fh)

		cls.__keep_names.add(namespace)

		# initialize standard output/error
		cls.__stdout[namespace] = sys.stdout
		cls.__stderr[namespace] = sys.stderr

	@classmethod
	def set_std_files(cls, namespace: str = None, stdout_file: str = None, stderr_file: str = None):
		"""Set standard output/error to indicated files

		Keyword Arguments:
			stdout_file {str} -- file for standard output (default: {None})
			stderr_file {str} -- file for standard error (default: {None})
		"""

		key = cls.__main_namespace
		if not namespace is None:
			key = namespace

		if stdout_file is not None:
			cls.__stdout[key] = codecs.open(stdout_file, 'w', 'utf-8')

		if stderr_file is not None:
			cls.__stderr[key] = codecs.open(stderr_file, 'w', 'utf-8')

	@classmethod
	def close_std_files(cls, namespace: str = None):
		"""Close current stream, and reset to standards.
		"""

		key = cls.__main_namespace
		if not namespace is None:
			key = namespace

		if cls.__stdout[key] is not None and cls.__stdout[key] is not sys.stdout:
			cls.__stdout[key].close()
			cls.__stdout[key] = sys.stdout

		if cls.__stderr[key] is not None and cls.__stderr[key] is not sys.stderr:
			cls.__stderr[key].close()
			cls.__stderr[key] = sys.stderr

	# output log message
	@classmethod
	def write_log(cls, message: str, use_time: bool = True, log_type: LogType = LogType.STD, msg_type = MessageType.NORMAL, namespace: str = None):
		"""Write messages.

		Arguments:
			message {str} -- Message to be output

		Keyword Arguments:
			use_time {bool} -- Flag to print time, or not. (default: {True})
			log_type {LogType} -- Type of logging (default: {LogType.STD})
			msg_type {[type]} -- Type of message (default: {MessageType.NORMAL})
		"""

		key = cls.__main_namespace
		if not namespace is None:
			key = namespace

		if not key in cls.__keep_names:
			print(f'Error: Logger is not initialized for namespace: {key}', file=sys.stderr)
			return

		# if cls.__logger is None and (log_type == LogType.BOTH or log_type == LogType.LOGGER):
		# 	print('Error: Logger is not initialized', file=sys.stderr)
		# 	return

		logger = logging.getLogger(key)

		# First, branch for logger
		if log_type == LogType.LOGGER or log_type == LogType.BOTH:
			if msg_type == MessageType.NORMAL:
				logger.info(message)
			elif msg_type == MessageType.ERROR:
				logger.error(message)
			elif msg_type == MessageType.WARNING:
				logger.warning(message)
			else:
				logger.error('Unknown message type: ' + str(msg_type))	# show error if unexpected type came

		# Add prefix if Error
		if msg_type == MessageType.ERROR:
			message = 'Error: ' + message
		elif msg_type == MessageType.WARNING:
			message = 'Warning: ' + message

		# Customize message if time string is required
		if use_time:
			message = cls.timed_message(message)

		# Second, branch for stdout/stderror
		if log_type == LogType.STD or log_type == LogType.BOTH:
			if msg_type == MessageType.NORMAL or msg_type == MessageType.WARNING:
				print(message, file=cls.__stdout[key])
			elif msg_type == MessageType.ERROR:
				print(message, file=cls.__stderr[key])
			else:
				print('Unknown message type: ' + str(msg_type), file=cls.__stderr[key])

	@classmethod
	def timed_message(cls, message: str):
		return '[%s] %s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), message)

	# accessor
	@classmethod
	def get_current_stdout(cls, namespace: str = None):
		key = cls.__main_namespace
		if not namespace is None:
			key = namespace

		return cls.__stdout[key]

	@classmethod
	def get_current_stderr(cls, namespace: str = None):
		key = cls.__main_namespace
		if not namespace is None:
			key = namespace

		return cls.__stderr[key]

	# shorten methods for logging
	@classmethod
	def info_std(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.STD, msg_type=MessageType.NORMAL, namespace=namespace)

	@classmethod
	def info_logger(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.LOGGER, msg_type=MessageType.NORMAL, namespace=namespace)

	@classmethod
	def info_both(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.BOTH, msg_type=MessageType.NORMAL, namespace=namespace)

	@classmethod
	def error_std(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.STD, msg_type=MessageType.ERROR, namespace=namespace)

	@classmethod
	def error_logger(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.LOGGER, msg_type=MessageType.ERROR, namespace=namespace)

	@classmethod
	def error_both(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.BOTH, msg_type=MessageType.ERROR, namespace=namespace)

	@classmethod
	def warning_std(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.STD, msg_type=MessageType.WARNING, namespace=namespace)

	@classmethod
	def warning_logger(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.LOGGER, msg_type=MessageType.WARNING, namespace=namespace)

	@classmethod
	def warning_both(cls, message: str, namespace: str = None):
		cls.write_log(message, log_type=LogType.BOTH, msg_type=MessageType.WARNING, namespace=namespace)

	@classmethod
	def initialized(cls) -> bool:
		# return not cls.__logger is None
		return cls.__initialized

