#!/usr/bin/env python3

#
# Author: Bioinformatics group, Takara Bio USA, Inc.
#
# Script to modify star fusion junction file to work with gencode
# This script receives the output folder from STAR fusion as input
#
# -----------------------------------------------------------------------------
import argparse
import os
import sys

DESCRIPTION = """Modify STAR fusion output to work with GENCODE reference."""

###
# Script information
###

# script info
SCRIPT_NAME = "modify_fusion_results.py"
VERSION = "3.0.19"

###
# Parse and define arguments
###


def _parse_command_line_args(sys_argv):
    """Takes in command line parameters and parses them for use

    Args:
        sys_argv: command line input

    Returns:
        args (list) : input argument values
    """
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    required = parser.add_argument_group("required arguments")

    required.add_argument(
        "-i",
        "--input_file",
        dest="input_file",
        help="Junction file from STAR",
        required=True,
    )

    required.add_argument(
        "-o",
        "--output_file",
        dest="output_file",
        help="Modified junction file input to STAR Fusion",
        required=True,
    )

    args, unknown = parser.parse_known_args(sys_argv)
    return args


# ---------- main ---------- #
def main(sys_argv):
    args = _parse_command_line_args(sys_argv)

    input_junction = args.input_file
    output_junction = args.output_file

    try:
        with open(input_junction) as inp, open(output_junction, "w") as out:
            counter = 0
            check = "Nreads 0"
            for line in inp:
                counter = counter + 1
                if counter == 1:
                    out.write(line)
                elif counter > 1:
                    if line.startswith("#"):
                        if check in line:
                            temp = "# Nreads 1	NreadsUnique 0	NreadsMulti 0"
                            out.write(temp)
                        else:
                            out.write(line)
                    else:
                        (
                            chr_donorA,
                            brkpt_donorA,
                            strand_donorA,
                            chr_acceptorB,
                            brkpt_acceptorB,
                            strand_acceptorB,
                            junction_type,
                            repeat_left_lenA,
                            repeat_right_lenB,
                            read_name,
                            start_alnA,
                            cigar_alnA,
                            start_alnB,
                            cigar_alnB,
                            num_chim_aln,
                            max_poss_aln_score,
                            non_chim_aln_score,
                            this_chim_aln_score,
                            bestall_chim_aln_score,
                            PEmerged_bool,
                            readgrp,
                        ) = [item.strip() for item in line.split("\t")]

                        if chr_donorA == "MT":
                            chr_donorA = "chrM"
                        elif chr_donorA.isdigit() or chr_donorA == "X" or chr_donorA == "Y":
                            chr_donorA = "chr" + chr_donorA

                        if chr_acceptorB == "MT":
                            chr_acceptorB = "chrM"
                        elif chr_acceptorB.isdigit() or chr_acceptorB == "X" or chr_acceptorB == "Y":
                            chr_acceptorB = "chr" + chr_acceptorB

                        outline = [
                            chr_donorA,
                            brkpt_donorA,
                            strand_donorA,
                            chr_acceptorB,
                            brkpt_acceptorB,
                            strand_acceptorB,
                            junction_type,
                            repeat_left_lenA,
                            repeat_right_lenB,
                            read_name,
                            start_alnA,
                            cigar_alnA,
                            start_alnB,
                            cigar_alnB,
                            num_chim_aln,
                            max_poss_aln_score,
                            non_chim_aln_score,
                            this_chim_aln_score,
                            bestall_chim_aln_score,
                            PEmerged_bool,
                            readgrp,
                        ]

                        outline = "\t".join(outline) + "\n"
                        out.write(outline)

    except IOError:
        print("Chimeric file does not exist.")
        sys.exit(1)


if __name__ == "__main__":
    main(sys.argv[1:])
